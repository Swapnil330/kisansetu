import React, { useState, useEffect, useRef, useCallback } from "react";
import { MapContainer, TileLayer, Marker, Polyline, Popup, useMap, useMapEvents } from "react-leaflet";
import L from "leaflet";

// ─── Types ────────────────────────────────────────────────────────────────────
type View = "home" | "farmer" | "forecast" | "matching" | "buyer" | "logistics" | "orders" | "transparency" | "profile";

// ─── Data ─────────────────────────────────────────────────────────────────────
const crops = [
  { id: 1, farmer: "Ramesh Patil", fpo: "Nashik FPO", crop: "Onion", qty: "12 MT", harvest: "Sep 14", location: "Nashik, MH", grade: "A", status: "verified", lat: 20.0, lng: 73.8 },
  { id: 2, farmer: "Sunita Devi", fpo: "Bihar FPO", crop: "Potato", qty: "8.5 MT", harvest: "Sep 10", location: "Muzaffarpur, BR", grade: "B", status: "pending", lat: 26.1, lng: 85.4 },
  { id: 3, farmer: "Gurpreet Singh", fpo: "Punjab FPO", crop: "Wheat", qty: "25 MT", harvest: "Oct 2", location: "Ludhiana, PB", grade: "A", status: "verified", lat: 30.9, lng: 75.8 },
  { id: 4, farmer: "Kavitha M.", fpo: "TN FPO", crop: "Tomato", qty: "6 MT", harvest: "Sep 8", location: "Tirupur, TN", grade: "A+", status: "verified", lat: 11.1, lng: 77.3 },
  { id: 5, farmer: "Ashok Yadav", fpo: "UP FPO", crop: "Sugarcane", qty: "40 MT", harvest: "Oct 20", location: "Muzaffarnagar, UP", grade: "B", status: "pending", lat: 29.5, lng: 77.7 },
];

const forecasts = [
  {
    crop: "Onion",
    region: "Maharashtra",
    demand: "High",
    priceRange: "₹18–₹26/kg",
    bestWindow: "Sep 10–25",
    confidence: 82,
    trend: "+14%",
    drivers: ["Festival season", "Export demand UP", "Low Kharif arrival"],
    insight: "Strong demand expected from Delhi & Mumbai mandis. Price likely to peak around Sep 18.",
  },
  {
    crop: "Potato",
    region: "Bihar",
    demand: "Moderate",
    priceRange: "₹12–₹17/kg",
    bestWindow: "Sep 5–18",
    confidence: 67,
    trend: "+3%",
    drivers: ["School reopening", "Stable cold storage supply"],
    insight: "Demand steady but competitive. Consider early dispatch to beat West Bengal supply surge.",
  },
  {
    crop: "Tomato",
    region: "Tamil Nadu",
    demand: "Very High",
    priceRange: "₹30–₹52/kg",
    bestWindow: "Sep 1–12",
    confidence: 91,
    trend: "+38%",
    drivers: ["Supply shortage", "Rain damage in Andhra", "High urban demand"],
    insight: "Exceptional demand window. Prioritize dispatch before Sep 12 to capture peak price.",
  },
];

const matches = [
  {
    id: "M-4821",
    farmer: "Kavitha M.",
    crop: "Tomato",
    supply: "6 MT",
    buyer: "BigBasket Wholesale",
    required: "5–8 MT",
    price: "₹42/kg",
    distance: "68 km",
    score: 97,
    grade: "A+",
    status: "ready",
  },
  {
    id: "M-4822",
    farmer: "Ramesh Patil",
    crop: "Onion",
    supply: "12 MT",
    buyer: "Metro Cash & Carry",
    required: "10–15 MT",
    price: "₹22/kg",
    distance: "124 km",
    score: 89,
    grade: "A",
    status: "pending",
  },
  {
    id: "M-4823",
    farmer: "Gurpreet Singh",
    crop: "Wheat",
    supply: "25 MT",
    buyer: "ITC Agribusiness",
    required: "20–30 MT",
    price: "₹26/kg",
    distance: "205 km",
    score: 84,
    grade: "A",
    status: "pending",
  },
];

const buyerRequirements = [
  { id: "BR-11", buyer: "BigBasket", crop: "Tomato", qty: "5–8 MT", priceRange: "₹38–₹45/kg", timing: "Sep 5–10", location: "Bengaluru", verified: true, matches: 3 },
  { id: "BR-12", buyer: "Metro Cash & Carry", crop: "Onion", qty: "10–15 MT", priceRange: "₹20–₹24/kg", timing: "Sep 12–18", location: "Pune", verified: true, matches: 2 },
  { id: "BR-13", buyer: "Reliance Fresh", crop: "Potato", qty: "20 MT", priceRange: "₹13–₹16/kg", timing: "Sep 8–14", location: "Patna", verified: true, matches: 1 },
  { id: "BR-14", buyer: "Local Mandal Co-op", crop: "Wheat", qty: "30 MT", priceRange: "₹24–₹28/kg", timing: "Oct 5–15", location: "Chandigarh", verified: false, matches: 0 },
];

const routes = [
  {
    id: "R-001",
    match: "M-4821",
    origin: "Tirupur, TN",
    destination: "Bengaluru",
    distance: "68 km",
    duration: "2h 10m",
    vehicle: "Tempo Traveller (4T)",
    cost: "₹4,200",
    stops: ["Tirupur Cold Store", "NH 948 checkpoint", "Bengaluru Wholesale Hub"],
    status: "scheduled",
    departure: "Sep 7, 5:30 AM",
  },
  {
    id: "R-002",
    match: "M-4822",
    origin: "Nashik, MH",
    destination: "Pune, MH",
    distance: "124 km",
    duration: "3h 45m",
    vehicle: "Mini Truck (7T)",
    cost: "₹8,600",
    stops: ["Nashik APMC", "Pune Ring Road", "Metro Warehouse"],
    status: "pending",
    departure: "Sep 13, 4:00 AM",
  },
];

const orders = [
  { id: "ORD-2041", match: "M-4821", crop: "Tomato", farmer: "Kavitha M.", buyer: "BigBasket", qty: "6 MT", value: "₹2,52,000", status: "delivered", priceSold: "₹42/kg", farmerShare: "78%", date: "Sep 8" },
  { id: "ORD-2042", match: "M-4820", crop: "Onion", farmer: "Ramesh Patil", buyer: "Spencers", qty: "8 MT", value: "₹1,76,000", status: "in-transit", priceSold: "₹22/kg", farmerShare: "74%", date: "Sep 6" },
  { id: "ORD-2039", match: "M-4818", crop: "Potato", farmer: "Sunita Devi", buyer: "Local Co-op", qty: "5 MT", value: "₹75,000", status: "settled", priceSold: "₹15/kg", farmerShare: "81%", date: "Sep 2" },
];

// ─── Extended Feature Data ────────────────────────────────────────────────────

const ALERTS = [
  { id: 1, type: "weather", icon: "🌧️", title: "Rain Alert — Nashik",    msg: "Heavy rainfall in 3 days. Consider harvesting Onion early to avoid moisture loss.", crop: "Onion",  urgent: true,  time: "2h ago" },
  { id: 2, type: "price",   icon: "📈", title: "Price Spike — Tomato",   msg: "Tomato prices in Bengaluru spiked +18% in last 6h. Excellent dispatch window.", crop: "Tomato", urgent: true,  time: "45m ago" },
  { id: 3, type: "calendar",icon: "📅", title: "Sowing Window Opening",  msg: "Rabi sowing window for Wheat starts in 8 days in Ludhiana district.", crop: "Wheat",  urgent: false, time: "1d ago" },
  { id: 4, type: "payment", icon: "💳", title: "Payment Released",        msg: "ORD-2039 settled — ₹75,000 transferred to Sunita Devi's linked account.", crop: null,    urgent: false, time: "3h ago" },
  { id: 5, type: "match",   icon: "⚡", title: "New Buyer Match",         msg: "Onion 12 MT — Metro Cash & Carry — Score 89. Review now.", crop: "Onion",  urgent: false, time: "2h ago" },
];

const COLD_STORES = [
  { id: "CS-01", name: "Nashik Agri Cold Hub",      dist: "8 km",  avail: "68 MT",  cost: "₹2.4/kg/wk",  rating: 4.7, type: "Multi-commodity", accredited: true  },
  { id: "CS-02", name: "Maharashtra FCS Network",    dist: "14 km", avail: "182 MT", cost: "₹1.9/kg/wk",  rating: 4.2, type: "Government",       accredited: true  },
  { id: "CS-03", name: "Private Coldchain Dindori",  dist: "22 km", avail: "40 MT",  cost: "₹3.1/kg/wk",  rating: 3.9, type: "Private",           accredited: false },
];

const FINANCIAL_SCHEMES = [
  { id: "enam",     name: "e-NAM",            icon: "🏛️", desc: "Get live prices from 1,000+ mandis across India. Sell directly to distant buyers.", cta: "Check Prices",     color: "#1e40af" },
  { id: "pmkisan",  name: "PM-KISAN",          icon: "🌾", desc: "₹6,000/year direct income support. Next installment: Nov 15.",                   cta: "Check Status",     color: "#1e4d2b" },
  { id: "kcc",      name: "Kisan Credit Card", icon: "💳", desc: "Collateral-free crop loan up to ₹3 lakh at 4% interest. Apply via bank.",        cta: "Check Eligibility", color: "#c8941a" },
  { id: "insurance",name: "PM Fasal Bima",     icon: "🛡️", desc: "Crop insurance against drought, flood, and pest. Enroll by Oct 31.",             cta: "Enroll Now",       color: "#991b1b" },
];

const FINANCIAL_SCHEMES_DETAIL = [
  {
    id: "kcc", name: "Kisan Credit Card (KCC)", icon: "💳", color: "#c8941a",
    interest: "7% p.a. (effective 4% after 3% subvention on prompt repayment)",
    limit: "Up to ₹3 lakh without collateral. ₹3–10 lakh with land collateral.",
    eligibility: "All farmers with agricultural land or allied activity. Age 18–70.",
    documents: ["Aadhaar card", "Land records (7/12 or RoR extract)", "Passport-size photo", "Bank passbook / cancelled cheque", "Crop sowing certificate"],
    process: "Apply at any nationalized bank, cooperative bank, or RRB. In-principle approval within 14 working days.",
    benefit: "₹6,000 additional subvention on prompt repayment within 1 year.",
    helpline: "1800-180-1551 (NABARD toll-free)"
  },
  {
    id: "pmkisan", name: "PM-KISAN Samman Nidhi", icon: "🌾", color: "#1e4d2b",
    interest: "Direct benefit transfer — no repayment required",
    limit: "₹6,000/year in 3 equal installments of ₹2,000 every 4 months",
    eligibility: "Small/marginal farmers with up to 2 hectare land. Aadhaar-linked bank account mandatory.",
    documents: ["Aadhaar card", "Land records (Khatauni)", "Bank account details", "Mobile number linked to Aadhaar"],
    process: "Register at pmkisan.gov.in or nearest CSC/bank. Verification by local revenue officer.",
    benefit: "Next installment: November 15. Total disbursed: ₹2.81 lakh crore+ to 11.8 crore farmers.",
    helpline: "155261 / 011-24300606"
  },
  {
    id: "pmfby", name: "PM Fasal Bima Yojana", icon: "🛡️", color: "#991b1b",
    interest: "Farmer premium: 1.5–2% for Kharif, 1.5% for Rabi, 5% for commercial/horticultural crops",
    limit: "Sum insured = district-level scale of finance for the crop. Full claim up to 100% crop loss.",
    eligibility: "All farmers growing notified crops in notified areas. KCC holders enrolled automatically.",
    documents: ["Crop sowing certificate (self-declaration)", "Bank account details", "Land records", "Aadhaar"],
    process: "Enroll via bank/CSC/insurance company before cut-off date. Kharif cut-off: Oct 31.",
    benefit: "Covers: drought, flood, cyclone, hailstorm, pest attack, disease. Post-harvest losses also covered.",
    helpline: "14447 / 1800-200-7710"
  },
  {
    id: "enam", name: "e-NAM (National Agriculture Market)", icon: "🏛️", color: "#1e40af",
    interest: "Zero fee for farmers. Commission: 1% by buyer.",
    limit: "Sell directly to 1,000+ mandis across 22 states. No quantity limits.",
    eligibility: "Any farmer with valid Aadhaar and bank account. FPO registration preferred.",
    documents: ["Aadhaar card", "Bank account", "Mobile number", "FPO registration (if applicable)"],
    process: "Register at enam.gov.in. Select mandi, list produce with quality parameters. Buyers bid online.",
    benefit: "Real-time price discovery. Direct payment to bank within 24h. Reduces middlemen margin by 8–15%.",
    helpline: "1800-270-0224"
  },
  {
    id: "kmaandhan", name: "PM Kisan Maan Dhan (Pension)", icon: "👴", color: "#7c5c32",
    interest: "50:50 matching contribution by Govt of India",
    limit: "₹3,000/month pension after age 60",
    eligibility: "Small/marginal farmers aged 18–40. Land: up to 2 hectares.",
    documents: ["Aadhaar card", "IFSC & bank account number", "Land records"],
    process: "Enroll at CSC centre. Monthly contribution: ₹55–₹200 depending on entry age (18–40).",
    benefit: "Govt matches every rupee. Family pension (50%) on death of subscriber.",
    helpline: "14447"
  },
];

const PEER_INSIGHTS = [
  { crop: "Onion",  region: "Nashik, MH",       sold: 14, avgPrice: "₹21.4/kg", trend: "+8%",  up: true,  icon: "🧅", buyers: "BigBasket, Reliance Fresh", msp: "Market rate", bestMandi: "Lasalgaon APMC" },
  { crop: "Tomato", region: "Kolar, Karnataka", sold: 9,  avgPrice: "₹44/kg",   trend: "+22%", up: true,  icon: "🍅", buyers: "Metro Cash & Carry, ITC",  msp: "Market rate", bestMandi: "Kolar Mandi" },
  { crop: "Potato", region: "Agra, UP",         sold: 22, avgPrice: "₹13.8/kg", trend: "-3%",  up: false, icon: "🥔", buyers: "PepsiCo Farming Division", msp: "Market rate", bestMandi: "Farrukhabad APMC" },
  { crop: "Wheat",  region: "Ludhiana, PB",     sold: 31, avgPrice: "₹22.8/kg", trend: "+1%",  up: true,  icon: "🌾", buyers: "FCI procurement", msp: "₹22.75/kg (MSP)", bestMandi: "Khanna Mandi" },
  { crop: "Chilli", region: "Guntur, AP",        sold: 7,  avgPrice: "₹145/kg",  trend: "+18%", up: true,  icon: "🌶️", buyers: "Everest Spices, MDH",     msp: "Market rate", bestMandi: "Guntur Mirchi Yard" },
];

const CROP_CALENDAR_ITEMS = [
  { event: "Onion harvest window closes",    date: "Sep 20", daysLeft: 6,  type: "harvest",  color: "bg-red-50 text-red-700 border-red-200",        icon: "🧅", action: "Complete harvest by Sep 18 to avoid moisture loss" },
  { event: "Fertilizer 2nd dose — Potato",  date: "Sep 18", daysLeft: 4,  type: "agronomy", color: "bg-amber-50 text-amber-700 border-amber-200",   icon: "🌿", action: "Apply MOP 50 kg/acre + Urea 25 kg/acre" },
  { event: "Irrigation window — Sugarcane", date: "Sep 16", daysLeft: 2,  type: "agronomy", color: "bg-orange-50 text-orange-700 border-orange-200", icon: "💧", action: "Critical tasseling stage — 1 drip session, 4hrs" },
  { event: "Wheat Kharif sowing begins",    date: "Oct 15", daysLeft: 31, type: "sowing",   color: "bg-[#d6f0de] text-[#1e4d2b] border-[#b6dfca]",  icon: "🌾", action: "Prepare land, procure certified HD-2967 or GW-496 seeds" },
  { event: "PMFBY Kharif enrollment cutoff",date: "Oct 31", daysLeft: 47, type: "insurance",color: "bg-blue-50 text-blue-700 border-blue-200",       icon: "🛡️", action: "Enroll at bank or CSC before this date to claim" },
  { event: "Rabi Onion transplanting",      date: "Nov 10", daysLeft: 57, type: "sowing",   color: "bg-purple-50 text-purple-700 border-purple-200", icon: "🧅", action: "Prepare nursery seedlings for Rabi crop transplant" },
];

const BUYER_RATINGS: Record<string, { rating: number; trades: number; onTime: number; quality: number }> = {
  "BigBasket Wholesale":  { rating: 4.8, trades: 312, onTime: 97, quality: 96 },
  "Metro Cash & Carry":   { rating: 4.5, trades: 187, onTime: 93, quality: 91 },
  "ITC Agribusiness":     { rating: 4.6, trades: 244, onTime: 95, quality: 94 },
};

// ── Comprehensive Indian Agricultural Pest & Disease Database ──────────────────
const PEST_DB = [
  {
    id: "early_blight",
    name: "Early Blight",
    sci: "Alternaria solani",
    type: "Fungal",
    crops: ["Tomato", "Potato", "Brinjal"],
    icon: "🍃",
    symptoms: ["brown-spots", "yellow-halo", "leaf-drop", "stem-lesions"],
    symptomLabels: ["Brown circular spots on older leaves", "Yellow halo around lesions", "Leaves curl & drop early", "Dark sunken stem lesions near soil"],
    severity: "Moderate–High",
    spread: "Wind, rain splash, infected seeds",
    lossRisk: "20–50% yield loss if untreated",
    chemical: "Mancozeb 75% WP @ 2.5 g/L water. OR Chlorothalonil 75% WP @ 2 g/L. Spray every 10–14 days.",
    organic: "Copper oxychloride 50% WP @ 3 g/L. Neem oil 5 mL/L + soap 2 mL/L. Trichoderma viride 5 g/L soil drench.",
    prevention: ["Use certified disease-free seeds", "Plant spacing ≥60 cm", "Avoid overhead irrigation", "Remove & burn infected debris", "Rotate with non-solanaceous crops for 2 seasons"],
    urgency: "Within 3–5 days",
    kvk: "Contact nearest KVK for free field diagnosis"
  },
  {
    id: "late_blight",
    name: "Late Blight",
    sci: "Phytophthora infestans",
    type: "Oomycete",
    crops: ["Tomato", "Potato"],
    icon: "🌑",
    symptoms: ["water-soaked", "white-mold", "brown-rot", "rapid-spread"],
    symptomLabels: ["Water-soaked patches on leaves", "White mold on leaf underside in humid weather", "Brown-black rot on stems & fruits", "Rapid canopy collapse within 3–5 days"],
    severity: "Very High — Can destroy entire crop",
    spread: "Airborne spores, fog, dew, cool temperatures (15–25°C)",
    lossRisk: "Up to 100% crop loss in 7–10 days",
    chemical: "Cymoxanil 8% + Mancozeb 64% WP @ 3 g/L. OR Metalaxyl-M 4% + Mancozeb 64% WP @ 2.5 g/L. Apply every 7 days.",
    organic: "Copper hydroxide 53.8% SC @ 2 mL/L. Lime sulphur solution (1:40). Remove affected plant parts immediately.",
    prevention: ["Plant resistant varieties (Arka Rakshak, CARI tomato-7)", "Ensure good field drainage", "Avoid dense planting", "Monitor daily during monsoon", "Use certified seed tubers for potato"],
    urgency: "URGENT — within 24–48 hours",
    kvk: "Call KVK helpline 1800-180-1551 for emergency visit"
  },
  {
    id: "powdery_mildew",
    name: "Powdery Mildew",
    sci: "Erysiphe cichoracearum / Leveillula taurica",
    type: "Fungal",
    crops: ["Chilli", "Cucurbits", "Wheat", "Peas", "Grapes"],
    icon: "⬜",
    symptoms: ["white-powder", "leaf-curl", "stunted", "premature-fall"],
    symptomLabels: ["White powdery coating on leaf surface", "Leaves curl upward & turn yellow", "Stunted plant growth", "Premature fruit/flower fall"],
    severity: "Moderate",
    spread: "Airborne spores, dry warm conditions (25–30°C), high relative humidity",
    lossRisk: "10–30% yield loss, 40% in severe outbreak",
    chemical: "Hexaconazole 5% SC @ 2 mL/L. OR Propiconazole 25% EC @ 1 mL/L. OR Sulphur 80% WP @ 3 g/L.",
    organic: "Wettable sulphur 80% WP @ 3 g/L. Potassium bicarbonate 5 g/L. Neem oil 5 mL/L. Apply in early morning.",
    prevention: ["Maintain plant spacing for airflow", "Remove infected leaves promptly", "Apply Sulphur dust preventively", "Avoid excessive nitrogen fertilization", "Choose resistant varieties"],
    urgency: "Within 5–7 days",
    kvk: "Consult local agricultural extension officer"
  },
  {
    id: "leaf_curl_virus",
    name: "Tomato Leaf Curl Virus",
    sci: "Tomato Yellow Leaf Curl Virus (TYLCV)",
    type: "Viral",
    crops: ["Tomato", "Chilli"],
    icon: "🌀",
    symptoms: ["upward-curl", "yellowing", "stunted", "whitefly"],
    symptomLabels: ["Leaves curl upward & inward", "Yellowing and puckering of leaves", "Stunted plant, no flowers or fruits", "Whitefly presence on leaf undersides"],
    severity: "High — No chemical cure",
    spread: "Whitefly (Bemisia tabaci) vector transmission",
    lossRisk: "30–80% yield loss depending on infection time",
    chemical: "Control whitefly vector: Imidacloprid 17.8 SL @ 0.5 mL/L OR Thiamethoxam 25% WG @ 0.3 g/L. Novaluron 10% EC @ 1.5 mL/L for nymphs.",
    organic: "Yellow sticky traps (10/acre). Neem oil 5 mL/L spray. Pyrethrin 0.6% @ 2 mL/L. Reflective mulch to deter whiteflies.",
    prevention: ["Remove and destroy infected plants immediately", "Use virus-resistant varieties (Arka Samrat, Pusa Rohini)", "Install 40-mesh nylon net nursery", "Monitor whitefly with yellow traps weekly", "Avoid planting near old infected fields"],
    urgency: "Remove infected plants within 24 hours",
    kvk: "Report cluster infections to district agriculture office"
  },
  {
    id: "brown_plant_hopper",
    name: "Brown Plant Hopper (BPH)",
    sci: "Nilaparvata lugens",
    type: "Insect Pest",
    crops: ["Rice"],
    icon: "🦗",
    symptoms: ["hopper-burn", "circular-patch", "sticky-frass", "wilting"],
    symptomLabels: ["Circular patches of dried crop (hopper burn)", "Brown honeydew-covered stems", "Sticky feel at plant base", "Plants wilt and die from base"],
    severity: "Very High",
    spread: "Migrates with monsoon winds, population explosion in 20–30 days",
    lossRisk: "50–100% loss in severe hopper burn",
    chemical: "Buprofezin 25% SC @ 1 mL/L (egg+nymph). OR Pymetrozine 50% WG @ 0.3 g/L. Spray directed at base of plants.",
    organic: "Release egg parasitoid Anagrus spp. Drain field and flood again. Light traps at night. Avoid excessive urea.",
    prevention: ["Plant resistant varieties (IR-36, Swarnadhan, MTU 1010)", "Maintain intermittent drying (AWD)", "Reduce nitrogen application", "Keep bunds clean, remove weedy hosts", "Monitor with plant-base sweep net weekly"],
    urgency: "Within 2–3 days of first symptoms",
    kvk: "Contact block agriculture officer for state advisory"
  },
  {
    id: "fusarium_wilt",
    name: "Fusarium Wilt",
    sci: "Fusarium oxysporum f. sp.",
    type: "Fungal",
    crops: ["Tomato", "Cotton", "Banana", "Watermelon", "Chilli"],
    icon: "💀",
    symptoms: ["wilting-daytime", "brown-vascular", "yellowing", "no-recovery"],
    symptomLabels: ["Plants wilt during daytime, recover at night initially", "Brown discolouration in stem vascular tissue", "Yellowing starts from lower leaves", "Eventually no recovery — plant dies"],
    severity: "High — Soil-borne, persists 5–10 years",
    spread: "Infected soil, water, roots, contaminated equipment",
    lossRisk: "20–60% stand loss; field may remain infected for years",
    chemical: "Carbendazim 50% WP @ 2 g/L soil drench around roots. OR Propiconazole 25% EC @ 1 mL/L. Drench only — foliar spray is ineffective.",
    organic: "Trichoderma harzianum @ 5 g/kg seed treatment. Mix Trichoderma 2.5 kg + FYM 50 kg per acre. Bacillus subtilis PGPR drench.",
    prevention: ["Soil solarization for 6 weeks before planting", "Use Trichoderma-enriched FYM", "Plant resistant varieties", "Avoid waterlogging", "Disinfect tools with 1% bleach", "5-year crop rotation"],
    urgency: "No cure once established — focus on prevention",
    kvk: "Soil testing recommended before next season planting"
  },
  {
    id: "rust_wheat",
    name: "Wheat Stem Rust",
    sci: "Puccinia graminis f. sp. tritici",
    type: "Fungal",
    crops: ["Wheat"],
    icon: "🟠",
    symptoms: ["orange-pustules", "stem-weakness", "leaf-necrosis", "lodging"],
    symptomLabels: ["Orange/red pustules on stems and leaves", "Stems weaken and may collapse", "Leaf necrosis starting from pustule centers", "Lodging (plant collapse) in severe cases"],
    severity: "Very High — Can cause epidemics",
    spread: "Airborne urediniospores; favoured by temperatures 15–30°C and high humidity",
    lossRisk: "Up to 70% yield loss in susceptible varieties",
    chemical: "Propiconazole 25% EC @ 1 mL/L. OR Tebuconazole 25% WG @ 1.5 g/L. Apply at first pustule appearance.",
    organic: "Sulphur 80% WP @ 3 g/L spray. Early sowing to avoid peak rust season. Monitor Ug99 strain alerts from ICAR.",
    prevention: ["Plant rust-resistant varieties (HD-2967, HI-8498, WH-1105)", "Early sowing (Oct 25–Nov 10)", "Avoid excessive nitrogen", "Field monitoring fortnightly", "Report unusual outbreaks to state agriculture dept"],
    urgency: "Within 3–5 days of first symptoms",
    kvk: "ICAR-IIWBR helpline: 0135-2672446"
  },
  {
    id: "downy_mildew_onion",
    name: "Downy Mildew",
    sci: "Peronospora destructor",
    type: "Oomycete",
    crops: ["Onion", "Garlic"],
    icon: "🌫️",
    symptoms: ["purple-fuzz", "leaf-yellowing", "soft-rot", "collapse"],
    symptomLabels: ["Purple-grey fuzzy growth on leaf surface", "Yellowing from leaf tips downward", "Soft watery rot in bulb neck", "Foliage collapses — premature maturity"],
    severity: "High",
    spread: "Airborne spores, cool & moist conditions (13–18°C), irrigation water",
    lossRisk: "30–50% bulb yield reduction",
    chemical: "Metalaxyl-M 4% + Mancozeb 64% WP @ 3 g/L. OR Cymoxanil 8% + Mancozeb 64% WP @ 3 g/L. Spray every 7–10 days.",
    organic: "Copper oxychloride 50% WP @ 3 g/L. Avoid overhead irrigation. Improve field drainage.",
    prevention: ["Use disease-free sets and certified seeds", "Avoid dense planting", "Ensure furrow or drip irrigation only", "Crop rotation (3-year break for onion/garlic)", "Destroy infected crop debris"],
    urgency: "Within 3 days of symptom observation",
    kvk: "Contact district horticulture office for advisory"
  },
  {
    id: "armyworm",
    name: "Fall Armyworm",
    sci: "Spodoptera frugiperda",
    type: "Insect Pest",
    crops: ["Maize", "Sorghum", "Sugarcane", "Cotton"],
    icon: "🐛",
    symptoms: ["window-pane", "frass-funnel", "ragged-feeding", "heart-damage"],
    symptomLabels: ["Window-pane feeding on leaf surface", "Frass (excreta) in plant funnel", "Ragged irregular leaf edges", "Damage to growing heart leaf causing dead heart"],
    severity: "High — Invasive pest since 2018",
    spread: "Migratory moth, up to 100 km/night. Eggs laid in clusters on leaf undersides.",
    lossRisk: "30–70% yield loss in maize; higher in early infestation",
    chemical: "Emamectin benzoate 5% SG @ 0.4 g/L (direct funnel spray). OR Chlorantraniliprole 18.5% SC @ 0.375 mL/L. OR Spinetoram 11.7% SC @ 0.5 mL/L.",
    organic: "Spodoptera NPV @ 250 LE/ha. Bacillus thuringiensis (Bt) 0.5% WP @ 2 g/L. Sand-lime mixture in funnel. Trichogramma egg parasitoid release.",
    prevention: ["Early sowing before June (avoid peak flight)", "Install pheromone traps (FAW) @ 5/ha", "Interplant with Napier grass (pull-push)", "Remove egg masses manually from leaf undersides", "Encourage natural enemies (parasitic wasps)"],
    urgency: "Within 1–2 days — larvae move fast",
    kvk: "ICAR-NBAIR FAW helpline: 080-23515638"
  },
  {
    id: "anthracnose",
    name: "Anthracnose (Fruit Rot)",
    sci: "Colletotrichum capsici / C. gloeosporioides",
    type: "Fungal",
    crops: ["Chilli", "Mango", "Grapes", "Banana"],
    icon: "⚫",
    symptoms: ["sunken-lesions", "orange-spores", "fruit-rot", "stem-canker"],
    symptomLabels: ["Circular sunken dark lesions on fruit", "Orange spore masses in lesion center", "Fruit rot and premature drop", "Stem dieback and canker"],
    severity: "High — Post-harvest losses major concern",
    spread: "Rain splash, infected seed, post-harvest water",
    lossRisk: "20–50% fruit loss; up to 80% in post-harvest storage",
    chemical: "Carbendazim 50% WP @ 1 g/L + Mancozeb 75% WP @ 2 g/L. OR Azoxystrobin 23% SC @ 1 mL/L. Spray at fruit set stage.",
    organic: "Trichoderma viride 5 g/L spray. Hot water treatment (52°C, 10 min) for post-harvest. Wax coating for storage.",
    prevention: ["Use disease-free certified seeds", "Deep plow and bury crop debris", "Avoid injury during harvest", "Cool storage at 7–10°C for chilli", "Grade and segregate infected fruits immediately"],
    urgency: "Within 3–5 days; treat before rain",
    kvk: "Consult ICAR-IIHR for disease-resistant chilli varieties"
  },
];

// ── Crop Yield Database (average per acre, in MT) ─────────────────────────────
const CROP_YIELDS: Record<string, {
  irrigated: [number, number]; rainfed: [number, number];
  unit: string; msp: string; marketRange: string;
  icon: string; season: string; duration: string;
}> = {
  Tomato:     { irrigated: [10, 14], rainfed: [6, 9],   unit: "MT", msp: "Market rate", marketRange: "₹15–80/kg",   icon: "🍅", season: "Kharif/Rabi", duration: "90–120 days" },
  Onion:      { irrigated: [7, 10],  rainfed: [4, 6],   unit: "MT", msp: "Market rate", marketRange: "₹10–45/kg",   icon: "🧅", season: "Kharif/Rabi", duration: "120–150 days" },
  Potato:     { irrigated: [8, 12],  rainfed: [5, 8],   unit: "MT", msp: "Market rate", marketRange: "₹8–25/kg",    icon: "🥔", season: "Rabi",        duration: "90–110 days" },
  Wheat:      { irrigated: [1.5, 2.2], rainfed: [0.8, 1.4], unit: "MT", msp: "₹2,275/quintal", marketRange: "₹22–28/kg", icon: "🌾", season: "Rabi", duration: "120–140 days" },
  Rice:       { irrigated: [1.5, 2.2], rainfed: [1.0, 1.6], unit: "MT", msp: "₹2,300/quintal", marketRange: "₹22–35/kg", icon: "🍚", season: "Kharif", duration: "130–150 days" },
  Soybean:    { irrigated: [0.7, 1.0], rainfed: [0.5, 0.8], unit: "MT", msp: "₹4,892/quintal", marketRange: "₹48–58/kg", icon: "🫘", season: "Kharif", duration: "90–110 days" },
  Maize:      { irrigated: [2.0, 3.2], rainfed: [1.2, 2.0], unit: "MT", msp: "₹2,225/quintal", marketRange: "₹18–28/kg", icon: "🌽", season: "Kharif/Rabi", duration: "90–110 days" },
  Cotton:     { irrigated: [0.7, 0.9], rainfed: [0.4, 0.6], unit: "MT (lint)", msp: "₹7,121/quintal (medium)", marketRange: "₹65–78/kg", icon: "☁️", season: "Kharif", duration: "160–180 days" },
  Chilli:     { irrigated: [1.2, 2.0], rainfed: [0.8, 1.4], unit: "MT (dry)", msp: "Market rate", marketRange: "₹80–250/kg", icon: "🌶️", season: "Kharif/Rabi", duration: "150–180 days" },
  Garlic:     { irrigated: [3.5, 5.0], rainfed: [2.0, 3.2], unit: "MT", msp: "Market rate", marketRange: "₹60–200/kg",  icon: "🧄", season: "Rabi",   duration: "150–180 days" },
  Sugarcane:  { irrigated: [35, 45],   rainfed: [20, 30],  unit: "MT", msp: "₹340/quintal (FRP)", marketRange: "₹3.2–3.8/kg", icon: "🎋", season: "Annual", duration: "12–18 months" },
  Banana:     { irrigated: [8, 14],    rainfed: [5, 9],    unit: "MT", msp: "Market rate", marketRange: "₹15–45/kg",   icon: "🍌", season: "Annual", duration: "10–12 months" },
};

// ── Community Forum Posts ─────────────────────────────────────────────────────
const COMMUNITY_POSTS = [
  { id: 1, name: "Ramprasad Yadav", region: "Vidisha, MP", crop: "Wheat", avatar: "👨‍🌾", time: "2 hrs ago", likes: 24, replies: 8,
    text: "Sold 18 MT wheat at ₹23.4/kg to FCI at Sagar procurement centre. Required: Form F + bank passbook. Helpful staff, settled in 72 hrs." },
  { id: 2, name: "Sunita Devi FPO", region: "Nashik, MH",  crop: "Onion", avatar: "👩‍🌾", time: "5 hrs ago", likes: 41, replies: 15,
    text: "Our 12-farmer pool of 85 MT Rabi onion sold at Lasalgaon APMC — got ₹22.8/kg vs ₹18/kg alone. FPO aggregation premium: ₹4/kg extra. Join our pool!" },
  { id: 3, name: "Gurpreet Singh",  region: "Amritsar, PB", crop: "Rice",  avatar: "👨‍🌾", time: "1 day ago", likes: 19, replies: 5,
    text: "Basmati 1509 getting ₹35/kg at Amritsar mandi today — best in 3 years. Dryers are charging ₹250/MT for custom milling. Book in advance!" },
  { id: 4, name: "Kavitha Reddy",   region: "Kurnool, AP",  crop: "Chilli",avatar: "👩‍🌾", time: "2 days ago", likes: 33, replies: 11,
    text: "Teja (S17) red chilli at Guntur yard: ₹165/kg. Exporters from UAE visiting next week — bring Grade A, minimum 5 MT. Contact me for exporter details." },
  { id: 5, name: "Mahesh Patil",    region: "Kolhapur, MH", crop: "Sugarcane", avatar: "👨‍🌾", time: "3 days ago", likes: 28, replies: 7,
    text: "Applied KCC online at SBI AgriMitra app — got ₹2.5L limit in 11 days! No visit to bank required. Used CIBIL score + land record. Highly recommend." },
];

// ── Active FPO Pool Data ───────────────────────────────────────────────────────
const FPO_POOLS = [
  { id: "onion_nashik",    crop: "Onion (Rabi)",        region: "Nashik, MH",  farmers: 6,  maxFarmers: 12, collected: 38, target: 80,  targetPrice: "₹23/kg", icon: "🧅",  deadline: "Oct 15", minQty: "2 MT" },
  { id: "tomato_kolar",    crop: "Tomato (Desi)",       region: "Kolar, KA",   farmers: 4,  maxFarmers: 8,  collected: 22, target: 50,  targetPrice: "₹48/kg", icon: "🍅",  deadline: "Oct 8",  minQty: "3 MT" },
  { id: "wheat_sehore",    crop: "Wheat (Sharbati)",    region: "Sehore, MP",  farmers: 9,  maxFarmers: 15, collected: 67, target: 100, targetPrice: "₹24/kg", icon: "🌾",  deadline: "Nov 20", minQty: "5 MT" },
  { id: "chilli_guntur",   crop: "Chilli (Teja S17)",   region: "Guntur, AP",  farmers: 3,  maxFarmers: 10, collected: 12, target: 50,  targetPrice: "₹170/kg",icon: "🌶️", deadline: "Oct 25", minQty: "4 MT" },
];

const ESCROW_STEPS = ["Buyer funds locked", "Platform holds", "Pickup confirmed", "Delivery confirmed", "Settled to account"];

// ─── Subcomponents ─────────────────────────────────────────────────────────────

function ConfidenceBar({ value, color = "soil" }: { value: number; color?: string }) {
  const colorMap: Record<string, string> = {
    soil: "bg-[#1e4d2b]",
    wheat: "bg-[#c8941a]",
    leaf: "bg-[#4a7c59]",
    red: "bg-red-500",
  };
  return (
    <div className="w-full bg-[#e8e3d8] rounded-full h-2">
      <div
        className={`${colorMap[color] ?? colorMap.soil} h-2 rounded-full transition-all duration-700`}
        style={{ width: `${value}%` }}
      />
    </div>
  );
}

function Badge({ label, variant = "green" }: { label: string; variant?: string }) {
  const variants: Record<string, string> = {
    green: "bg-[#d6f0de] text-[#1e4d2b]",
    amber: "bg-[#fef3c7] text-[#92400e]",
    blue: "bg-[#dbeafe] text-[#1e40af]",
    red: "bg-[#fee2e2] text-[#991b1b]",
    gray: "bg-[#f3f4f6] text-[#4b5563]",
    wheat: "bg-[#fef9ec] text-[#92400e] border border-[#e8b535]",
  };
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium font-mono ${variants[variant] ?? variants.green}`}>
      {label}
    </span>
  );
}

function ScoreRing({ score }: { score: number }) {
  const color = score >= 90 ? "#1e4d2b" : score >= 75 ? "#c8941a" : "#7c5c32";
  return (
    <div className="relative w-16 h-16 flex-shrink-0">
      <svg viewBox="0 0 56 56" className="w-full h-full -rotate-90">
        <circle cx="28" cy="28" r="22" fill="none" stroke="#e8e3d8" strokeWidth="5" />
        <circle
          cx="28" cy="28" r="22" fill="none"
          stroke={color} strokeWidth="5"
          strokeDasharray={`${(score / 100) * 138.2} 138.2`}
          strokeLinecap="round"
        />
      </svg>
      <span className="absolute inset-0 flex items-center justify-center text-sm font-bold font-mono" style={{ color }}>
        {score}
      </span>
    </div>
  );
}

// ─── Views ────────────────────────────────────────────────────────────────────

// ─── Realistic wheat stalk SVG ───────────────────────────────────────────────
function WheatStalk({ x, baseY, height, thick, color, headColor, delay, speed }: {
  x: number; baseY: number; height: number; thick: number;
  color: string; headColor: string; delay: number; speed: number;
}) {
  const leafY1 = baseY - height * 0.38;
  const leafY2 = baseY - height * 0.6;
  const origin = `${x}px ${baseY}px`;
  const anim = `sway-${thick > 1.4 ? "heavy" : "gentle"} ${speed}s ease-in-out ${delay}s infinite`;
  return (
    <g style={{ animation: anim, transformOrigin: origin }}>
      {/* Main stalk with subtle curve */}
      <path d={`M${x} ${baseY} Q${x + 1} ${baseY - height * 0.5} ${x - 0.5} ${baseY - height}`}
        fill="none" stroke={color} strokeWidth={thick} strokeLinecap="round"/>
      {/* Left leaf */}
      <path d={`M${x} ${leafY1} Q${x - 14} ${leafY1 - 6} ${x - 11} ${leafY1 - 18}`}
        fill="none" stroke={color} strokeWidth={thick * 0.65} strokeLinecap="round"/>
      {/* Right leaf */}
      <path d={`M${x} ${leafY2} Q${x + 13} ${leafY2 - 5} ${x + 10} ${leafY2 - 16}`}
        fill="none" stroke={color} strokeWidth={thick * 0.65} strokeLinecap="round"/>
      {/* Grain head — realistic spikelets */}
      {[-3,-1.5,0,1.5,3].map((ox, i) => (
        <ellipse key={i} cx={x + ox * 0.4} cy={baseY - height - i * 3.5 - 2}
          rx={1.6 - Math.abs(ox) * 0.2} ry={2.8}
          fill={headColor} opacity={0.88 - Math.abs(ox) * 0.04}/>
      ))}
      {/* Awns (bristles) */}
      {[-2,0,2].map((ox, i) => (
        <line key={i}
          x1={x + ox * 0.3} y1={baseY - height - i * 3.5 - 6}
          x2={x + ox * 0.3 + ox} y2={baseY - height - i * 3.5 - 14}
          stroke={headColor} strokeWidth="0.5" opacity="0.6"/>
      ))}
    </g>
  );
}

// ─── Pollen/spore particle ────────────────────────────────────────────────────
function PollenParticle({ x, y, size, delay, dur, dx, rot }: {
  x: number; y: number; size: number; delay: number; dur: number; dx: number; rot: number;
}) {
  return (
    <circle cx={x} cy={y} r={size} fill="#e8b535" opacity="0"
      style={{
        animation: `pollen-rise ${dur}s ease-out ${delay}s infinite`,
        ["--dx" as string]: `${dx}px`,
        ["--rot" as string]: `${rot}deg`,
      } as React.CSSProperties}/>
  );
}

// ─── God ray ─────────────────────────────────────────────────────────────────
function GodRay({ x1, y1, x2, y2, delay, width }: {
  x1: number; y1: number; x2: number; y2: number; delay: number; width: number;
}) {
  return (
    <line x1={x1} y1={y1} x2={x2} y2={y2}
      stroke="rgba(255,220,120,1)" strokeWidth={width} strokeLinecap="round"
      opacity="0"
      style={{ animation: `god-ray ${4 + delay}s ease-in-out ${delay}s infinite` }}/>
  );
}

function HomeView({ setView }: { setView: (v: View) => void }) {
  const [scrollY, setScrollY] = useState(0);
  const [visible, setVisible] = useState(false);
  const [activeFeature, setActiveFeature] = useState<number | null>(null);

  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 60);
    const onScroll = () => setScrollY(window.scrollY);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => { clearTimeout(t); window.removeEventListener("scroll", onScroll); };
  }, []);

  const wheatData = Array.from({ length: 52 }, (_, i) => ({
    x: i * 20 + 3,
    height: 54 + Math.sin(i * 2.1) * 15 + Math.cos(i * 0.8) * 9,
    thick: 1.0 + (i % 4) * 0.22,
    color: i % 5 === 0 ? "#5a8c3a" : i % 3 === 0 ? "#4e7c32" : "#3d6828",
    headColor: i % 4 === 0 ? "#d4a22a" : i % 2 === 0 ? "#c8941a" : "#b87e12",
    delay: (i * 0.17) % 2.5,
    speed: 1.9 + (i % 5) * 0.27,
  }));
  const midWheatData = Array.from({ length: 40 }, (_, i) => ({
    x: i * 26 + 10,
    height: 35 + Math.sin(i * 1.7 + 1) * 9,
    thick: 0.8, color: "#3a6020", headColor: "#a87010",
    delay: (i * 0.21 + 0.5) % 2.8, speed: 2.4 + (i % 4) * 0.32,
  }));
  const farWheatData = Array.from({ length: 32 }, (_, i) => ({
    x: i * 32 + 6,
    height: 22 + Math.sin(i * 1.3) * 5,
    thick: 0.55, color: "#2e5018", headColor: "#906010",
    delay: (i * 0.26 + 1) % 3, speed: 3 + (i % 3) * 0.38,
  }));
  const pollenData = Array.from({ length: 28 }, (_, i) => ({
    x: 30 + i * 38, y: 320,
    size: 1.1 + (i % 5) * 0.4,
    delay: i * 0.6, dur: 5 + (i % 5) * 0.9,
    dx: (i % 2 === 0 ? 1 : -1) * (10 + (i % 7) * 5),
    rot: (i % 2 === 0 ? 1 : -1) * (25 + i * 8),
  }));

  const FEATURES = [
    { view:"farmer",       icon:"🌱", title:"Farmer Hub",       desc:"Voice-first onboarding, AI crop estimator, pest detection", accent:"#4ade80" },
    { view:"forecast",     icon:"🤖", title:"AI Forecast",      desc:"Demand prediction before markets move, not after",          accent:"#60a5fa" },
    { view:"matching",     icon:"⚡", title:"Smart Match",      desc:"Buyer-seller pairing by grade, quantity & distance",        accent:"#f59e0b" },
    { view:"buyer",        icon:"🏪", title:"Buyer Portal",     desc:"Post needs, get matched to verified FPO produce",           accent:"#e879f9" },
    { view:"logistics",    icon:"🚛", title:"Live Logistics",   desc:"Real-time route optimisation across Madhya Pradesh",        accent:"#22d3ee" },
    { view:"orders",       icon:"🔒", title:"Escrow Orders",    desc:"Payment locked before pickup, released on delivery",        accent:"#fb7185" },
    { view:"transparency", icon:"💡", title:"Price Discovery",  desc:"Full mandi chain visibility for farmers & buyers",          accent:"#a3e635" },
    { view:"farmer",       icon:"🌦️", title:"Smart Alerts",    desc:"Weather, price spike & crop calendar push nudges",          accent:"#fdba74" },
  ];

  const TICKER = ["🍅 Tomato ₹42/kg ↑18%","🧅 Onion ₹21/kg ↑8%","🥔 Potato ₹14/kg ↓3%","🌾 Wheat ₹22/kg ↑5%","🌽 Maize ₹18/kg ↑12%","🧄 Garlic ₹55/kg ↑22%","🫑 Capsicum ₹38/kg ↓4%","🍆 Brinjal ₹28/kg ↑9%"];

  return (
    <div style={{ background:"#050d04" }}>

      {/* ══════════════════════════════════════════════════════ HERO ══════ */}
      <div className="relative overflow-hidden text-white" style={{ minHeight:"100vh" }}>

        {/* BG sky */}
        <div className="absolute inset-0" style={{ background:"linear-gradient(165deg,#050d04 0%,#081408 18%,#0c1e0a 38%,#122812 60%,#1a3818 82%,#0e2210 100%)" }}/>

        {/* Hero photo — full exposure, cinematic grade */}
        <div className="absolute inset-0" style={{ transform:`translateY(${scrollY*0.28}px)`, willChange:"transform" }}>
          <img src="https://images.unsplash.com/photo-1764260631896-15e2776b29fa?w=1920&h=1080&fit=crop&auto=format&q=95"
            alt="Terraced rice fields at dawn" className="w-full h-full object-cover"
            style={{ filter:"saturate(1.8) brightness(0.5) contrast(1.15) hue-rotate(-12deg)" }}/>
        </div>

        {/* Second photo — golden hour wash blended over top-right */}
        <div className="absolute inset-0">
          <img src="https://images.unsplash.com/photo-1781032480530-5809498d868b?w=1200&h=800&fit=crop&auto=format&q=85"
            alt="Golden sunbeams through misty field"
            className="absolute top-0 right-0 w-[52%] h-[65%] object-cover"
            style={{
              opacity:0.28,
              filter:"saturate(2) brightness(0.6) contrast(1.1)",
              maskImage:"radial-gradient(ellipse 80% 80% at 75% 25%, black 0%, transparent 75%)",
              WebkitMaskImage:"radial-gradient(ellipse 80% 80% at 75% 25%, black 0%, transparent 75%)",
            }}/>
        </div>

        {/* Cinematic color grade overlay */}
        <div className="absolute inset-0 pointer-events-none" style={{
          background:"linear-gradient(180deg, rgba(5,10,3,0.52) 0%, rgba(10,28,8,0.18) 28%, rgba(8,22,5,0.12) 55%, rgba(3,8,2,0.82) 100%)"
        }}/>

        {/* Horizontal split light leak — right side warm glow */}
        <div className="absolute inset-0 pointer-events-none" style={{
          background:"radial-gradient(ellipse 60% 55% at 78% 20%, rgba(255,185,50,0.14) 0%, rgba(255,120,20,0.06) 45%, transparent 75%)",
          animation:"sun-breathe 7s ease-in-out infinite"
        }}/>

        {/* Sun orb */}
        <div className="absolute pointer-events-none" style={{ top:"10%", right:"23%", width:220, height:220 }}>
          <div style={{ width:"100%", height:"100%", borderRadius:"50%", background:"radial-gradient(circle, rgba(255,220,90,0.5) 0%, rgba(255,150,30,0.22) 40%, transparent 72%)", animation:"sun-breathe 6s ease-in-out infinite", filter:"blur(12px)" }}/>
          <div style={{ position:"absolute", top:"50%", left:"50%", width:22, height:22, marginLeft:-11, marginTop:-11, borderRadius:"50%", background:"radial-gradient(circle, #fff9c0 0%, rgba(255,220,80,0.85) 55%, transparent 100%)", boxShadow:"0 0 28px 8px rgba(255,200,60,0.55)" }}/>
        </div>

        {/* God rays */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 1000 620" preserveAspectRatio="xMidYMid slice">
          <GodRay x1={770} y1={68}  x2={80}  y2={620} delay={0}   width={100}/>
          <GodRay x1={770} y1={68}  x2={320} y2={620} delay={1}   width={65}/>
          <GodRay x1={770} y1={68}  x2={560} y2={620} delay={2.1} width={48}/>
          <GodRay x1={770} y1={68}  x2={780} y2={620} delay={0.5} width={75}/>
          <GodRay x1={770} y1={68}  x2={970} y2={580} delay={3}   width={42}/>
        </svg>

        {/* Diagonal grid lines — geometric tech motif */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-[0.04]" viewBox="0 0 1000 620" preserveAspectRatio="xMidYMid slice">
          {Array.from({length:12},(_,i)=>(
            <line key={i} x1={i*90-50} y1={0} x2={i*90+300} y2={620} stroke="white" strokeWidth="0.5"/>
          ))}
          {Array.from({length:8},(_,i)=>(
            <line key={i} x1={0} y1={i*90} x2={1000} y2={i*90} stroke="white" strokeWidth="0.5"/>
          ))}
        </svg>

        {/* Haze bands */}
        <div className="absolute pointer-events-none" style={{ top:"42%",left:0,right:0,height:80, background:"linear-gradient(90deg,transparent,rgba(160,220,140,0.07) 30%,rgba(180,240,160,0.11) 60%,transparent)", animation:"haze-drift 10s ease-in-out infinite" }}/>
        <div className="absolute pointer-events-none" style={{ top:"56%",left:0,right:0,height:55, background:"linear-gradient(90deg,transparent,rgba(200,240,180,0.05) 40%,transparent)", animation:"haze-drift 15s ease-in-out 4s infinite" }}/>

        {/* ── Wheat field — 3 depth planes ── */}
        <div className="absolute inset-x-0 bottom-0 pointer-events-none" style={{ height:440 }}>
          <svg viewBox="0 0 1050 440" preserveAspectRatio="xMidYMax slice" width="100%" height="100%">
            <defs>
              <linearGradient id="g-far"  x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#152c0a" stopOpacity="0"/><stop offset="100%" stopColor="#0a1607" stopOpacity="1"/></linearGradient>
              <linearGradient id="g-mid"  x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#0f2208" stopOpacity="0"/><stop offset="100%" stopColor="#071005" stopOpacity="1"/></linearGradient>
              <linearGradient id="g-near" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#0a1c06" stopOpacity="0"/><stop offset="100%" stopColor="#040a03" stopOpacity="1"/></linearGradient>
              <filter id="fb"><feGaussianBlur stdDeviation="0.9"/></filter>
              <filter id="fm"><feGaussianBlur stdDeviation="0.35"/></filter>
            </defs>
            <g filter="url(#fb)" opacity="0.5">
              {farWheatData.map(({x,...r},i)=><WheatStalk key={i} x={x} baseY={280} {...r}/>)}
            </g>
            <rect x="0" y="268" width="1050" height="34" fill="url(#g-far)"/>
            <g filter="url(#fm)" opacity="0.72">
              {midWheatData.map(({x,...r},i)=><WheatStalk key={i} x={x} baseY={345} {...r}/>)}
            </g>
            <rect x="0" y="328" width="1050" height="42" fill="url(#g-mid)"/>
            <g opacity="1">
              {wheatData.map(({x,...r},i)=><WheatStalk key={i} x={x} baseY={418} {...r}/>)}
            </g>
            <rect x="0" y="395" width="1050" height="45" fill="url(#g-near)"/>
            <rect x="0" y="420" width="1050" height="20" fill="#030805"/>
            {pollenData.map((p,i)=><PollenParticle key={i} {...p}/>)}
          </svg>
        </div>

        {/* Fireflies */}
        {([
          {l:"12%",t:"62%",fx:"14px",fy:"-15px",fx2:"22px",fy2:"-7px",d:"0s",du:"4.2s"},
          {l:"32%",t:"57%",fx:"-9px",fy:"-19px",fx2:"7px",fy2:"-11px",d:"1.6s",du:"5.1s"},
          {l:"51%",t:"64%",fx:"17px",fy:"-11px",fx2:"26px",fy2:"-21px",d:"0.9s",du:"3.7s"},
          {l:"68%",t:"60%",fx:"-15px",fy:"-17px",fx2:"-5px",fy2:"-9px",d:"2.4s",du:"4.8s"},
          {l:"82%",t:"63%",fx:"11px",fy:"-13px",fx2:"19px",fy2:"-19px",d:"3.2s",du:"5.6s"},
          {l:"92%",t:"59%",fx:"-7px",fy:"-20px",fx2:"3px",fy2:"-14px",d:"0.4s",du:"4s"},
        ]).map((ff,i)=>(
          <div key={i} className="absolute rounded-full pointer-events-none" style={{
            left:ff.l,top:ff.t,width:6,height:6,
            background:"radial-gradient(circle,rgba(200,255,140,1) 0%,rgba(120,230,90,0.4) 60%,transparent 100%)",
            boxShadow:"0 0 8px 3px rgba(160,255,100,0.55)",
            animation:`firefly ${ff.du} ease-in-out ${ff.d} infinite`,
            ["--fx" as string]:ff.fx,["--fy" as string]:ff.fy,
            ["--fx2" as string]:ff.fx2,["--fy2" as string]:ff.fy2,
          } as React.CSSProperties}/>
        ))}

        {/* Vignette */}
        <div className="absolute inset-0 pointer-events-none" style={{ background:"radial-gradient(ellipse 110% 90% at 50% 45%, transparent 35%, rgba(2,6,1,0.72) 100%)" }}/>
        <div className="absolute inset-x-0 bottom-0 pointer-events-none" style={{ height:220, background:"linear-gradient(to top,rgba(2,5,1,0.99) 0%,transparent 100%)" }}/>

        {/* ════ HERO CONTENT ════ */}
        <div className="relative z-10 px-6 lg:px-12" style={{ paddingTop:"11vh", paddingBottom:"24vh" }}>
          <div className="max-w-7xl mx-auto flex flex-col lg:flex-row gap-10 lg:gap-20 items-start lg:items-center">

            {/* LEFT */}
            <div className="flex-1 min-w-0" style={{ opacity: visible?1:0, transform: visible?"none":"translateY(24px)", transition:"opacity 0.9s cubic-bezier(0.22,1,0.36,1), transform 0.9s cubic-bezier(0.22,1,0.36,1)" }}>

              {/* Live pill */}
              <div className="inline-flex items-center gap-2 mb-6 px-3.5 py-1.5 rounded-full" style={{ background:"rgba(20,50,15,0.7)", border:"1px solid rgba(74,222,128,0.3)", backdropFilter:"blur(14px)" }}>
                <span className="relative flex w-2 h-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#4ade80] opacity-75"/>
                  <span className="relative inline-flex rounded-full w-2 h-2 bg-[#4ade80]"/>
                </span>
                <span className="text-[11px] font-mono font-semibold tracking-[0.18em] text-[#86efac]">LIVE · KHARIF 2026 · INDIA AGRITECH</span>
              </div>

              {/* Giant wordmark */}
              <div className="mb-4" style={{ fontFamily:"var(--font-display)", lineHeight:0.88, letterSpacing:"-0.02em" }}>
                <div style={{ fontSize:"clamp(4rem,10vw,8.5rem)", fontWeight:700, color:"white", textShadow:"0 0 80px rgba(0,0,0,0.8), 0 4px 0 rgba(0,0,0,0.4)" }}>
                  Kisan
                  <span style={{
                    background:"linear-gradient(135deg,#fbbf24 0%,#f59e0b 35%,#d97706 65%,#fbbf24 100%)",
                    WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent",
                    backgroundClip:"text",
                    filter:"drop-shadow(0 0 32px rgba(251,191,36,0.7))",
                    backgroundSize:"200% 200%",
                    animation:"sun-breathe 4s ease-in-out infinite",
                  }}>setu</span>
                </div>
                <div style={{ fontSize:"clamp(1.1rem,2.8vw,2.2rem)", fontWeight:300, fontStyle:"italic", color:"rgba(134,239,172,0.75)", marginTop:"0.15em", letterSpacing:"0.01em" }}>
                  where the soil meets the algorithm
                </div>
              </div>

              {/* Tagline */}
              <p style={{ fontSize:"clamp(0.9rem,1.6vw,1.1rem)", color:"rgba(167,243,208,0.65)", maxWidth:440, lineHeight:1.65, marginBottom:"2.2rem" }}>
                AI that reads crop markets before they move — so 12,400+ farmers across India never sell at the wrong price again.
              </p>

              {/* CTA row */}
              <div className="flex flex-wrap gap-3 mb-10">
                <button onClick={()=>setView("farmer")}
                  className="group relative flex items-center gap-2.5 font-bold px-7 py-4 rounded-2xl text-sm overflow-hidden transition-all active:scale-[0.97]"
                  style={{ background:"linear-gradient(135deg,#d97706,#f59e0b,#fbbf24)", color:"#050d04", boxShadow:"0 8px 40px rgba(245,158,11,0.5), inset 0 1px 0 rgba(255,255,255,0.25)" }}>
                  <span className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity" style={{ background:"linear-gradient(135deg,#f59e0b,#fbbf24,#fde68a)" }}/>
                  <span className="relative text-base">🌾</span>
                  <span className="relative">Farmer Portal</span>
                  <svg className="relative group-hover:translate-x-1 transition-transform" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                </button>

                <button onClick={()=>setView("buyer")}
                  className="relative font-semibold px-7 py-4 rounded-2xl text-sm transition-all active:scale-[0.97] border overflow-hidden group"
                  style={{ background:"rgba(255,255,255,0.06)", borderColor:"rgba(134,239,172,0.25)", backdropFilter:"blur(12px)", color:"rgba(187,247,208,0.9)" }}>
                  <span className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity" style={{ background:"rgba(134,239,172,0.08)" }}/>
                  <span className="relative">🏪 Buyer Portal</span>
                </button>

                <button onClick={()=>setView("forecast")}
                  className="relative font-semibold px-7 py-4 rounded-2xl text-sm transition-all active:scale-[0.97] border overflow-hidden group"
                  style={{ background:"rgba(255,255,255,0.03)", borderColor:"rgba(255,255,255,0.1)", backdropFilter:"blur(12px)", color:"rgba(167,243,208,0.65)" }}>
                  <span className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity" style={{ background:"rgba(255,255,255,0.06)" }}/>
                  <span className="relative">📊 AI Forecast</span>
                </button>
              </div>

              {/* Trust row */}
              <div className="flex flex-wrap gap-x-6 gap-y-2">
                {[
                  {icon:"🏛️",label:"e-NAM linked"},
                  {icon:"🛡️",label:"PM-KISAN"},
                  {icon:"🔒",label:"Escrow pay"},
                  {icon:"📶",label:"SMS offline"},
                  {icon:"🌐",label:"5 languages"},
                ].map(b=>(
                  <span key={b.label} className="flex items-center gap-1.5 text-[11px] font-mono" style={{ color:"rgba(134,239,172,0.4)" }}>
                    {b.icon} {b.label}
                  </span>
                ))}
              </div>
            </div>

            {/* RIGHT — stat panel */}
            <div className="w-full lg:w-[300px] flex-shrink-0" style={{ opacity:visible?1:0, transform:visible?"none":"translateY(32px)", transition:"opacity 1s 0.3s cubic-bezier(0.22,1,0.36,1), transform 1s 0.3s cubic-bezier(0.22,1,0.36,1)" }}>

              {/* Big live stat */}
              <div className="rounded-3xl p-6 mb-3 relative overflow-hidden" style={{ background:"rgba(10,26,8,0.75)", border:"1px solid rgba(134,239,172,0.18)", backdropFilter:"blur(24px)", boxShadow:"0 0 60px rgba(74,222,128,0.08), inset 0 1px 0 rgba(255,255,255,0.06)" }}>
                <div className="absolute top-4 right-4 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#4ade80] animate-pulse"/>
                  <span className="text-[9px] font-mono text-[#4ade80]">LIVE</span>
                </div>
                <p className="text-[10px] font-mono text-[#86efac]/60 uppercase tracking-widest mb-1">Farmers active today</p>
                <div className="text-5xl font-bold font-mono mb-1" style={{ color:"#4ade80", textShadow:"0 0 30px rgba(74,222,128,0.45)" }}>
                  12,400<span className="text-2xl text-[#86efac]/60">+</span>
                </div>
                <p className="text-xs text-[#86efac]/40 font-mono">across Maharastra, MP, UP, Punjab…</p>
                <div className="mt-4 h-1 rounded-full overflow-hidden" style={{ background:"rgba(74,222,128,0.1)" }}>
                  <div className="h-full rounded-full" style={{ width:"78%", background:"linear-gradient(90deg,#4ade80,#22c55e)", boxShadow:"0 0 8px rgba(74,222,128,0.5)" }}/>
                </div>
                <p className="text-[9px] font-mono text-[#86efac]/30 mt-1">78% active in last 30 days</p>
              </div>

              {/* 3 small stats */}
              <div className="grid grid-cols-3 gap-2">
                {[
                  {v:"184",  l:"FPOs",      c:"#fbbf24", g:"rgba(251,191,36,0.2)"},
                  {v:"8.2K", l:"Tonnes",    c:"#60a5fa", g:"rgba(96,165,250,0.2)"},
                  {v:"+23%", l:"Price gain",c:"#f87171", g:"rgba(248,113,113,0.2)"},
                ].map(s=>(
                  <div key={s.l} className="rounded-2xl p-3 text-center" style={{ background:"rgba(8,18,6,0.7)", border:"1px solid rgba(255,255,255,0.07)", backdropFilter:"blur(16px)", boxShadow:`0 0 20px ${s.g}` }}>
                    <div className="text-xl font-bold font-mono" style={{ color:s.c }}>{s.v}</div>
                    <div className="text-[9px] font-mono mt-0.5" style={{ color:"rgba(167,243,208,0.45)" }}>{s.l}</div>
                  </div>
                ))}
              </div>

              {/* AI match rate ring */}
              <div className="mt-3 rounded-2xl p-4 flex items-center gap-4" style={{ background:"rgba(8,18,6,0.7)", border:"1px solid rgba(255,255,255,0.07)", backdropFilter:"blur(16px)" }}>
                <svg width="52" height="52" viewBox="0 0 52 52">
                  <circle cx="26" cy="26" r="22" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="5"/>
                  <circle cx="26" cy="26" r="22" fill="none" stroke="url(#ring-grad)" strokeWidth="5"
                    strokeDasharray={`${0.94*2*Math.PI*22} ${2*Math.PI*22}`} strokeLinecap="round" transform="rotate(-90 26 26)"/>
                  <defs>
                    <linearGradient id="ring-grad" x1="0" y1="0" x2="1" y2="1">
                      <stop offset="0%" stopColor="#4ade80"/>
                      <stop offset="100%" stopColor="#22d3ee"/>
                    </linearGradient>
                  </defs>
                  <text x="26" y="30" textAnchor="middle" fontSize="10" fontWeight="700" fill="#4ade80" fontFamily="monospace">94%</text>
                </svg>
                <div>
                  <p className="text-xs font-semibold" style={{ color:"rgba(187,247,208,0.85)" }}>AI match accuracy</p>
                  <p className="text-[9px] font-mono mt-0.5" style={{ color:"rgba(134,239,172,0.4)" }}>1,240 matches · last 30d</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Wave out */}
        <div className="absolute bottom-0 inset-x-0 pointer-events-none">
          <svg viewBox="0 0 1440 110" preserveAspectRatio="none" width="100%" height="110">
            <path d="M0 110 L0 60 C160 18 320 5 480 38 C640 70 800 10 960 32 C1120 54 1280 75 1440 45 L1440 110 Z" fill="#faf7f0"/>
          </svg>
        </div>
      </div>

      {/* ══════════════════════════════ LIVE TICKER ════════════════════════ */}
      <div style={{ background:"#1e4d2b", overflow:"hidden", borderBottom:"1px solid rgba(255,255,255,0.08)" }}>
        <div className="flex items-center">
          <div className="flex-shrink-0 px-5 py-3 border-r border-white/10 flex items-center gap-2" style={{ background:"rgba(0,0,0,0.2)" }}>
            <span className="w-1.5 h-1.5 rounded-full bg-[#4ade80] animate-pulse"/>
            <span className="text-[10px] font-mono font-bold tracking-widest text-[#86efac]">LIVE PRICES</span>
          </div>
          <div className="flex-1 overflow-hidden py-3">
            <div className="ticker-track">
              {[...TICKER,...TICKER].map((t,i)=>(
                <span key={i} className="text-xs font-mono font-semibold text-white/80 flex-shrink-0">{t}</span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* ══════════════════════════════ FEATURE SHOWCASE ══════════════════ */}
      <div className="bg-[#faf7f0]">

        {/* Section header */}
        <div className="max-w-7xl mx-auto px-6 pt-20 pb-10 text-center">
          <div className="inline-flex items-center gap-2 mb-5 px-4 py-1.5 rounded-full bg-[#d6f0de] border border-[#b6dfca]">
            <span className="w-1.5 h-1.5 rounded-full bg-[#1e4d2b]"/>
            <span className="text-[10px] font-mono font-bold tracking-widest text-[#1e4d2b]">PLATFORM FEATURES</span>
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-[#1a1a0e] mb-4" style={{ fontFamily:"var(--font-display)" }}>
            Everything the field<br/>
            <span style={{ color:"#1e4d2b" }}>needs to win.</span>
          </h2>
          <p className="text-[#7c5c32] max-w-md mx-auto text-sm leading-relaxed">
            Eight interconnected modules. One platform. Zero middleman margin.
          </p>
        </div>

        {/* 4×2 feature grid */}
        <div className="max-w-7xl mx-auto px-6 pb-10 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {FEATURES.map((f, i) => (
            <button key={f.title} onClick={()=>setView(f.view as View)}
              onMouseEnter={()=>setActiveFeature(i)}
              onMouseLeave={()=>setActiveFeature(null)}
              className="text-left rounded-3xl p-6 transition-all duration-300 relative overflow-hidden group"
              style={{
                background: activeFeature===i ? "white" : "#f5f0e8",
                border: `1px solid ${activeFeature===i ? f.accent+"55" : "#e8e3d8"}`,
                boxShadow: activeFeature===i ? `0 20px 60px ${f.accent}20, 0 4px 20px rgba(0,0,0,0.06)` : "none",
                transform: activeFeature===i ? "translateY(-4px)" : "none",
              }}>
              <div className="absolute top-0 right-0 w-24 h-24 rounded-full opacity-0 group-hover:opacity-100 transition-opacity" style={{ background:`radial-gradient(circle,${f.accent}18 0%,transparent 70%)`, transform:"translate(30%,-30%)" }}/>
              <div className="w-11 h-11 rounded-2xl flex items-center justify-center text-xl mb-5 transition-all" style={{
                background: activeFeature===i ? `${f.accent}22` : "rgba(0,0,0,0.05)",
                boxShadow: activeFeature===i ? `0 0 0 1px ${f.accent}40` : "none",
              }}>{f.icon}</div>
              <div className="text-xs font-mono font-bold tracking-widest mb-2 transition-colors" style={{ color: activeFeature===i ? f.accent : "#a77c3e" }}>
                {String(i+1).padStart(2,"0")}
              </div>
              <h3 className="font-semibold text-[#1a1a0e] mb-2 text-sm group-hover:text-[#1e4d2b] transition-colors">{f.title}</h3>
              <p className="text-xs text-[#7c5c32] leading-relaxed">{f.desc}</p>
              <div className="mt-4 flex items-center gap-1 text-[10px] font-mono font-semibold opacity-0 group-hover:opacity-100 transition-opacity" style={{ color:f.accent }}>
                Open <svg width="10" height="10" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
              </div>
            </button>
          ))}
        </div>

        {/* Season badges strip */}
        <div className="max-w-7xl mx-auto px-6 pb-16 flex flex-wrap gap-2 justify-center">
          {[
            {crop:"🍅 Tomato",  s:"Peak supply",   c:"bg-red-50 text-red-700 border-red-200"},
            {crop:"🧅 Onion",   s:"Harvest open",  c:"bg-amber-50 text-amber-700 border-amber-200"},
            {crop:"🌾 Wheat",   s:"Sowing in 8d",  c:"bg-[#d6f0de] text-[#1e4d2b] border-[#b6dfca]"},
            {crop:"🥔 Potato",  s:"In cold store", c:"bg-slate-50 text-slate-600 border-slate-200"},
            {crop:"🌽 Maize",   s:"High demand",   c:"bg-yellow-50 text-yellow-700 border-yellow-200"},
          ].map(s=>(
            <span key={s.crop} className={`inline-flex items-center gap-1.5 text-[11px] font-mono px-3.5 py-1.5 rounded-full border ${s.c}`}>
              {s.crop} · {s.s}
            </span>
          ))}
        </div>
      </div>

      {/* ══════════════════════════════ CINEMATIC BAND ════════════════════ */}
      <div className="relative overflow-hidden" style={{ height:320 }}>
        <img src="https://images.unsplash.com/photo-1595434730960-fe4b5e925688?w=1800&h=600&fit=crop&auto=format&q=90"
          alt="Wheat silhouettes at sunset" className="w-full h-full object-cover"
          style={{ filter:"saturate(1.4) brightness(0.45) contrast(1.2)", transform:`translateY(${(scrollY-800)*0.15}px)`, transformOrigin:"center" }}/>
        <div className="absolute inset-0" style={{ background:"linear-gradient(90deg,rgba(10,20,6,0.9) 0%,rgba(10,20,6,0.55) 50%,rgba(10,20,6,0.85) 100%)" }}/>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white max-w-2xl px-6">
            <p className="text-[10px] font-mono tracking-[0.35em] text-[#86efac]/70 mb-4 uppercase">The Closed Intelligence Loop</p>
            <h2 className="font-bold mb-5" style={{ fontFamily:"var(--font-display)", fontSize:"clamp(1.8rem,4vw,3rem)", lineHeight:1.1, textShadow:"0 2px 30px rgba(0,0,0,0.6)" }}>
              Every harvest makes<br/>
              <span style={{ color:"#fbbf24" }}>the AI smarter.</span>
            </h2>
            <div className="flex flex-wrap justify-center items-center gap-2.5 text-[11px] font-mono text-white/60">
              {["Farmer lists crop","→","AI forecasts demand","→","Match confirmed","→","Delivery tracked","→","Data retrains model"].map((s,i)=>(
                <span key={i} className={s==="→" ? "text-[#fbbf24] font-bold text-base" : "bg-white/8 border border-white/12 rounded-full px-3 py-1.5"}>{s}</span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom cream pad */}
      <div className="bg-[#f5f0e8] border-t border-[#e8e3d8] py-10">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <p className="text-xs font-mono text-[#a77c3e]">Kisansetu AI · India AgriTech · Kharif 2026 · 12,400+ farmers connected</p>
        </div>
      </div>
    </div>
  );
}

function FarmerView() {
  const [tab, setTab] = useState<"listings"|"estimator"|"pest"|"financial"|"community">("listings");
  const [lang, setLang] = useState<"en"|"hi"|"mr">("en");
  const [showForm, setShowForm] = useState(false);
  const [estimating, setEstimating] = useState(false);
  const [estResult, setEstResult] = useState<null|{crop:string;qty:string;grade:string;conf:number;min:string;max:string;msp:string;revenue:string}>(null);
  const [estCrop, setEstCrop] = useState("Tomato");
  const [estAcres, setEstAcres] = useState(2);
  const [estWater, setEstWater] = useState<"irrigated"|"rainfed">("irrigated");
  const [detecting, setDetecting] = useState(false);
  const [pestResult, setPestResult] = useState<null|(typeof PEST_DB[0])>(null);
  const [pestCrop, setPestCrop] = useState("Tomato");
  const [pestSymptoms, setPestSymptoms] = useState<string[]>([]);
  const [pestScanMode, setPestScanMode] = useState<"photo"|"symptoms">("photo");
  const [voiceActive, setVoiceActive] = useState(false);
  const [callbackSent, setCallbackSent] = useState(false);
  const [wfApplied, setWfApplied] = useState(false);
  const [finTab, setFinTab] = useState<"schemes"|"emi"|"eligibility">("schemes");
  const [loanAmt, setLoanAmt] = useState(150000);
  const [loanRate, setLoanRate] = useState(7);
  const [loanTenure, setLoanTenure] = useState(12);
  const [landHa, setLandHa] = useState(1.5);
  const [pmkisanName, setPmkisanName] = useState("");
  const [pmkisanAadhaar, setPmkisanAadhaar] = useState("");
  const [pmkisanStatus, setPmkisanStatus] = useState<null|string>(null);
  const [schemeExpanded, setSchemeExpanded] = useState<string|null>(null);
  const [postLikes, setPostLikes] = useState<Record<number,boolean>>({});
  const [fpoJoined, setFpoJoined] = useState<string[]>([]);
  const [communityTab, setCommunityTab] = useState<"feed"|"fpo"|"calendar">("feed");

  const labels: Record<string, Record<string, string>> = {
    en: { title: "Farmer & FPO Hub", add: "List New Crop", crop: "Crop Type", qty: "Quantity (MT)", harvest: "Harvest Date", location: "Location" },
    hi: { title: "किसान और FPO हब", add: "नई फसल जोड़ें", crop: "फसल का प्रकार", qty: "मात्रा (MT)", harvest: "कटाई की तारीख", location: "स्थान" },
    mr: { title: "शेतकरी आणि FPO हब", add: "नवीन पीक जोडा", crop: "पिकाचा प्रकार", qty: "प्रमाण (MT)", harvest: "कापणीची तारीख", location: "स्थान" },
  };
  const L = labels[lang];

  const TABS = [
    { id:"listings",  label:"My Listings",   icon:"🌾" },
    { id:"estimator", label:"AI Estimator",  icon:"📷" },
    { id:"pest",      label:"Pest & Disease",icon:"🔬" },
    { id:"financial", label:"Financial Hub", icon:"💰" },
    { id:"community", label:"Community",     icon:"👥" },
  ];

  function runEstimator() {
    setEstimating(true); setEstResult(null);
    const yieldData = CROP_YIELDS[estCrop];
    if (!yieldData) { setEstimating(false); return; }
    const [lo, hi] = yieldData[estWater];
    const randomFactor = 0.85 + Math.random() * 0.3;
    const estimatedMT = parseFloat((estAcres * ((lo + hi) / 2) * randomFactor).toFixed(2));
    const minMT = parseFloat((estAcres * lo * 0.9).toFixed(2));
    const maxMT = parseFloat((estAcres * hi * 1.05).toFixed(2));
    const conf = Math.floor(78 + Math.random() * 18);
    const gradeScore = conf > 90 ? "A+" : conf > 83 ? "A" : conf > 75 ? "B+" : "B";
    const [marketLo, marketHi] = yieldData.marketRange.replace(/₹/g, "").split("–").map(s => parseFloat(s));
    const midPrice = (marketLo + marketHi) / 2 * 1000;
    const revenue = (estimatedMT * midPrice / 1000).toFixed(0);
    setTimeout(() => {
      setEstimating(false);
      setEstResult({
        crop: estCrop,
        qty: `${estimatedMT} MT`,
        grade: gradeScore,
        conf,
        min: `${minMT} MT`,
        max: `${maxMT} MT`,
        msp: yieldData.msp,
        revenue: `₹${parseInt(revenue).toLocaleString("en-IN")}`,
      });
    }, 2200);
  }

  function runPestDetect() {
    setDetecting(true); setPestResult(null);
    const candidates = PEST_DB.filter(d => d.crops.includes(pestCrop));
    let matched: typeof PEST_DB[0] | undefined;
    if (pestSymptoms.length > 0) {
      let best = -1;
      candidates.forEach(d => {
        const overlap = d.symptoms.filter(s => pestSymptoms.includes(s)).length;
        if (overlap > best) { best = overlap; matched = d; }
      });
    }
    if (!matched) matched = candidates[Math.floor(Math.random() * candidates.length)] ?? PEST_DB[0];
    const result = matched;
    setTimeout(() => {
      setDetecting(false);
      setPestResult(result);
    }, 2600);
  }

  function checkPmkisanStatus() {
    if (!pmkisanName || pmkisanAadhaar.length < 12) return;
    const statuses = [
      "Eligible — ₹2,000 installment (Nov 2024) will be credited to your linked bank account.",
      "Pending verification — Land records not matched. Visit nearest CSC to update Aadhaar-linked bank account.",
      "Active — Last installment of ₹2,000 credited on Aug 1, 2024. Next installment: Nov 15.",
    ];
    setPmkisanStatus(statuses[Math.floor(Math.random() * statuses.length)]);
  }

  function calcEMI(): number {
    const r = loanRate / 12 / 100;
    if (r === 0) return Math.round(loanAmt / loanTenure);
    return Math.round((loanAmt * r * Math.pow(1 + r, loanTenure)) / (Math.pow(1 + r, loanTenure) - 1));
  }

  function calcLoanEligibility(): number {
    return Math.min(Math.round(landHa * 90000), 300000);
  }

  return (
    <div className="max-w-5xl mx-auto">
      {/* ── IVR / Toll-free Banner ── */}
      <div className="bg-[#1e4d2b] text-white rounded-2xl px-5 py-4 mb-6 flex items-center gap-4 flex-wrap">
        <div className="w-10 h-10 rounded-full bg-white/15 flex items-center justify-center text-xl flex-shrink-0">📞</div>
        <div className="flex-1 min-w-0">
          <p className="font-semibold">Voice / IVR support for offline farmers</p>
          <p className="text-sm text-[#c8dfc8] mt-0.5">No smartphone needed. Call <span className="font-mono font-bold text-[#e8b535]">1800-KISAN-AI</span> (toll-free) to register a crop, check order status, or hear today prices — in Hindi, Marathi, Tamil, Punjabi, Telugu.</p>
        </div>
        <div className="flex gap-2 flex-shrink-0 flex-wrap">
          <button
            onClick={() => setCallbackSent(true)}
            className={`px-4 py-2 rounded-xl text-sm font-semibold transition-colors ${callbackSent ? "bg-[#4ade80] text-[#1a1a0e]" : "bg-[#e8b535] text-[#1a1a0e] hover:bg-[#fbbf24]"}`}
          >
            {callbackSent ? "✓ Callback Requested" : "Request Call-back"}
          </button>
          <div className="flex items-center gap-2 bg-white/10 rounded-xl px-4 py-2">
            <span className="w-2 h-2 bg-[#4ade80] rounded-full animate-pulse"/>
            <span className="text-xs font-mono text-white/80">SMS alerts active</span>
          </div>
        </div>
      </div>

      {/* ── Page header ── */}
      <div className="flex items-center justify-between mb-5 flex-wrap gap-4">
        <div>
          <h2 className="text-3xl font-bold" style={{ fontFamily:"var(--font-display)" }}>{L.title}</h2>
          <p className="text-[#7c5c32] mt-1">Listings, AI tools, financial schemes, and community insights</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex bg-[#f0ebe0] rounded-lg p-1">
            {(["en","hi","mr"] as const).map(l => (
              <button key={l} onClick={() => setLang(l)}
                className={`px-3 py-1.5 rounded-md text-sm font-mono font-medium transition-colors ${lang===l ? "bg-[#1e4d2b] text-white" : "text-[#7c5c32] hover:text-[#1e4d2b]"}`}>
                {l==="en"?"EN":l==="hi"?"हि":"मर"}
              </button>
            ))}
          </div>
          <button
            onClick={() => setVoiceActive(v=>!v)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-colors border ${voiceActive ? "bg-red-50 border-red-300 text-red-700" : "bg-white border-[#e8e3d8] text-[#7c5c32] hover:bg-[#f0ebe0]"}`}
          >
            <span>{voiceActive ? "🔴" : "🎙️"}</span>
            {voiceActive ? "Recording… tap to stop" : "Voice input"}
          </button>
        </div>
      </div>

      {/* ── Tabs ── */}
      <div className="flex gap-1 bg-[#f0ebe0] rounded-xl p-1 mb-6 overflow-x-auto">
        {TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id as typeof tab)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${tab===t.id ? "bg-white text-[#1e4d2b] shadow-sm" : "text-[#7c5c32] hover:text-[#1e4d2b]"}`}>
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      {/* ── Tab: My Listings ── */}
      {tab === "listings" && (
        <div>
          <div className="flex justify-end mb-4">
            <button onClick={() => setShowForm(!showForm)}
              className="bg-[#1e4d2b] text-white px-5 py-2.5 rounded-lg font-medium hover:bg-[#2d6b3e] transition-colors text-sm">
              + {L.add}
            </button>
          </div>
          {showForm && (
            <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6 mb-6 shadow-sm">
              <h3 className="font-semibold text-[#1e4d2b] mb-4">{L.add}</h3>
              <div className="grid sm:grid-cols-2 gap-4">
                {[L.crop, L.qty, L.harvest, L.location].map(label => (
                  <div key={label}>
                    <label className="block text-sm text-[#7c5c32] mb-1.5 font-mono">{label}</label>
                    <input className="w-full border border-[#e8e3d8] rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-[#1e4d2b]" placeholder={`Enter ${label}`}/>
                  </div>
                ))}
              </div>
              <div className="flex gap-3 mt-4">
                <button className="bg-[#1e4d2b] text-white px-6 py-2.5 rounded-lg text-sm font-medium hover:bg-[#2d6b3e]">Submit</button>
                <button onClick={() => setShowForm(false)} className="border border-[#e8e3d8] text-[#7c5c32] px-6 py-2.5 rounded-lg text-sm hover:bg-[#f0ebe0]">Cancel</button>
              </div>
            </div>
          )}
          <div className="space-y-3">
            {crops.map(c => (
              <div key={c.id} className="bg-white border border-[#e8e3d8] rounded-xl p-5 hover:border-[#4a7c59] transition-colors">
                <div className="flex items-start gap-4 flex-wrap">
                  <div className="w-12 h-12 rounded-xl bg-[#d6f0de] flex items-center justify-center text-xl flex-shrink-0">
                    {c.crop==="Onion"?"🧅":c.crop==="Potato"?"🥔":c.crop==="Wheat"?"🌾":c.crop==="Tomato"?"🍅":"🎋"}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <span className="font-semibold text-[#1a1a0e]">{c.farmer}</span>
                      <span className="text-sm text-[#7c5c32] font-mono">· {c.fpo}</span>
                      <Badge label={c.status==="verified"?"✓ Verified":"Pending"} variant={c.status==="verified"?"green":"amber"}/>
                      <Badge label={`Grade ${c.grade}`} variant="blue"/>
                    </div>
                    <div className="flex flex-wrap gap-x-6 gap-y-1 text-sm text-[#7c5c32]">
                      <span>🌱 <b className="text-[#1a1a0e]">{c.crop}</b></span>
                      <span>📦 {c.qty}</span>
                      <span>📅 Harvest: {c.harvest}</span>
                      <span>📍 {c.location}</span>
                    </div>
                  </div>
                  <div className="flex gap-2 flex-shrink-0">
                    <button className="text-xs px-3 py-1.5 rounded-lg bg-[#f0ebe0] text-[#7c5c32] hover:bg-[#e8e3d8] font-mono transition-colors">View on Map</button>
                    {c.status==="pending" && <button className="text-xs px-3 py-1.5 rounded-lg bg-[#1e4d2b] text-white hover:bg-[#2d6b3e] transition-colors">Verify Stock</button>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── Tab: AI Crop Estimator ── */}
      {tab === "estimator" && (
        <div className="space-y-5">
          {/* Input Panel */}
          <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6">
            <h3 className="font-semibold text-[#1a1a0e] mb-1" style={{fontFamily:"var(--font-display)"}}>📊 AI Yield & Revenue Estimator</h3>
            <p className="text-sm text-[#7c5c32] mb-5">Enter your crop details to get a data-driven yield estimate based on actual district-level averages from ICAR & Agmarknet.</p>
            <div className="grid sm:grid-cols-3 gap-4 mb-5">
              <div>
                <label className="block text-xs font-mono text-[#7c5c32] mb-1.5 uppercase tracking-wider">Crop Type</label>
                <select value={estCrop} onChange={e => { setEstCrop(e.target.value); setEstResult(null); }}
                  className="w-full border border-[#e8e3d8] rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-[#1e4d2b] bg-white">
                  {Object.entries(CROP_YIELDS).map(([k, v]) => (
                    <option key={k} value={k}>{v.icon} {k}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-mono text-[#7c5c32] mb-1.5 uppercase tracking-wider">Field Area (Acres)</label>
                <input type="number" min={0.5} max={500} step={0.5} value={estAcres}
                  onChange={e => { setEstAcres(parseFloat(e.target.value) || 1); setEstResult(null); }}
                  className="w-full border border-[#e8e3d8] rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-[#1e4d2b]"/>
              </div>
              <div>
                <label className="block text-xs font-mono text-[#7c5c32] mb-1.5 uppercase tracking-wider">Irrigation Type</label>
                <div className="flex gap-2">
                  {(["irrigated","rainfed"] as const).map(w => (
                    <button key={w} onClick={() => { setEstWater(w); setEstResult(null); }}
                      className={`flex-1 py-2.5 rounded-lg text-sm font-medium border transition-colors capitalize ${estWater===w ? "bg-[#1e4d2b] text-white border-[#1e4d2b]" : "border-[#e8e3d8] text-[#7c5c32] hover:bg-[#f0ebe0]"}`}>
                      {w==="irrigated"?"💧 Irrigated":"🌧 Rainfed"}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            {/* Crop info strip */}
            {CROP_YIELDS[estCrop] && (
              <div className="bg-[#f9f7f2] rounded-xl p-4 mb-5 grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                {[
                  { label:"Season", value: CROP_YIELDS[estCrop].season },
                  { label:"Duration", value: CROP_YIELDS[estCrop].duration },
                  { label:"MSP / Floor", value: CROP_YIELDS[estCrop].msp },
                  { label:"Market Range", value: CROP_YIELDS[estCrop].marketRange },
                ].map(s => (
                  <div key={s.label}>
                    <p className="text-[10px] font-mono text-[#7c5c32] uppercase tracking-wider">{s.label}</p>
                    <p className="text-sm font-semibold text-[#1a1a0e] mt-0.5">{s.value}</p>
                  </div>
                ))}
              </div>
            )}
            <div className="flex gap-3 flex-wrap">
              <button onClick={runEstimator} disabled={estimating}
                className="bg-[#c8941a] hover:bg-[#e8b535] text-white px-6 py-3 rounded-xl font-semibold transition-colors disabled:opacity-60 flex items-center gap-2 text-sm">
                {estimating ? <><span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin"/>Calculating…</> : "📊 Run AI Estimate"}
              </button>
              <label className="bg-white border border-[#e8e3d8] text-[#7c5c32] px-6 py-3 rounded-xl font-medium cursor-pointer hover:bg-[#f0ebe0] transition-colors text-sm flex items-center gap-2">
                📷 Upload Field Photo
                <input type="file" accept="image/*" className="hidden" onChange={() => runEstimator()}/>
              </label>
            </div>
          </div>

          {estimating && (
            <div className="bg-white border border-[#e8e3d8] rounded-2xl p-8 text-center">
              <div className="w-12 h-12 border-4 border-[#d6f0de] border-t-[#1e4d2b] rounded-full animate-spin mx-auto mb-4"/>
              <p className="font-semibold text-[#1a1a0e]">Analyzing yield parameters…</p>
              <p className="text-sm text-[#7c5c32] mt-1">Cross-referencing ICAR district data, soil type, and current season conditions</p>
            </div>
          )}

          {estResult && !estimating && (
            <div className="bg-white border border-[#4a7c59] rounded-2xl overflow-hidden shadow-sm">
              <div className="bg-[#1e4d2b] text-white px-6 py-4 flex items-center justify-between flex-wrap gap-3">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{CROP_YIELDS[estResult.crop]?.icon ?? "🌾"}</span>
                  <div>
                    <p className="font-semibold">AI Estimate — {estResult.crop} · {estAcres} acres ({estWater})</p>
                    <p className="text-sm text-[#c8dfc8]">AI confidence: {estResult.conf}% · Based on ICAR district-level yield data</p>
                  </div>
                </div>
                <div className="flex-shrink-0">
                  <ScoreRing score={estResult.conf}/>
                </div>
              </div>
              <div className="p-6">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-5">
                  {[
                    { label:"Estimated Yield", value:estResult.qty, icon:"⚖️", sub:"(most likely)" },
                    { label:"Grade", value:`Grade ${estResult.grade}`, icon:"🏷️", sub:"visual quality" },
                    { label:"Range", value:`${estResult.min} – ${estResult.max}`, icon:"📊", sub:"low to high" },
                    { label:"Est. Revenue", value:estResult.revenue, icon:"💰", sub:"at mid-market price" },
                  ].map(s => (
                    <div key={s.label} className="bg-[#f9f7f2] rounded-xl p-4 text-center">
                      <div className="text-xl mb-1.5">{s.icon}</div>
                      <div className="text-base font-bold font-mono text-[#1e4d2b] leading-tight">{s.value}</div>
                      <div className="text-[10px] text-[#7c5c32] mt-1 font-mono uppercase">{s.label}</div>
                      <div className="text-[10px] text-[#7c5c32] opacity-70">{s.sub}</div>
                    </div>
                  ))}
                </div>
                <div className="bg-[#fef9ec] border border-[#e8b535] rounded-xl p-4 mb-4">
                  <p className="text-sm font-semibold text-[#92400e] mb-1">💡 Price Guidance</p>
                  <p className="text-sm text-[#92400e]">MSP / Floor: <b>{estResult.msp}</b>. Current market: <b>{CROP_YIELDS[estCrop]?.marketRange}</b>. Wait for seasonal peak or sell now via e-NAM for real-time price discovery.</p>
                </div>
                <div className="flex gap-3 flex-wrap">
                  <button className="bg-[#1e4d2b] text-white px-6 py-2.5 rounded-xl font-semibold hover:bg-[#2d6b3e] transition-colors text-sm">
                    ✓ Confirm & List Crop
                  </button>
                  <button onClick={() => setEstResult(null)} className="border border-[#e8e3d8] text-[#7c5c32] px-6 py-2.5 rounded-xl hover:bg-[#f0ebe0] transition-colors text-sm">
                    Recalculate
                  </button>
                  <button className="border border-[#e8e3d8] text-[#7c5c32] px-5 py-2.5 rounded-xl hover:bg-[#f0ebe0] transition-colors text-sm">
                    📤 Share with FPO
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Crop Yield Reference Table */}
          <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6">
            <h4 className="font-semibold mb-3 text-sm">📋 National Average Yields Reference (ICAR / Agmarknet 2024–25)</h4>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-[#e8e3d8]">
                    <th className="text-left py-2 text-[#7c5c32] font-mono">Crop</th>
                    <th className="text-right py-2 text-[#7c5c32] font-mono">Irrigated (MT/acre)</th>
                    <th className="text-right py-2 text-[#7c5c32] font-mono">Rainfed (MT/acre)</th>
                    <th className="text-right py-2 text-[#7c5c32] font-mono">Market Range</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.entries(CROP_YIELDS).map(([crop, d]) => (
                    <tr key={crop} className={`border-b border-[#f0ebe0] ${crop===estCrop?"bg-[#f0faf3]":""}`}>
                      <td className="py-2 font-medium">{d.icon} {crop}</td>
                      <td className="py-2 text-right font-mono">{d.irrigated[0]}–{d.irrigated[1]}</td>
                      <td className="py-2 text-right font-mono text-[#7c5c32]">{d.rainfed[0]}–{d.rainfed[1]}</td>
                      <td className="py-2 text-right font-mono text-[#1e4d2b]">{d.marketRange}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ── Tab: Pest & Disease Detection ── */}
      {tab === "pest" && (
        <div className="space-y-5">
          {/* Input panel */}
          <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6">
            <h3 className="font-semibold text-[#1a1a0e] mb-1" style={{fontFamily:"var(--font-display)"}}>🔬 AI Pest & Disease Diagnosis</h3>
            <p className="text-sm text-[#7c5c32] mb-4">Select your crop and describe symptoms, or upload a photo. Our model cross-references 2,400+ disease records from ICAR, NIPHM, and state agriculture databases.</p>

            {/* Mode toggle */}
            <div className="flex gap-2 mb-4">
              {(["photo","symptoms"] as const).map(m => (
                <button key={m} onClick={() => { setPestScanMode(m); setPestResult(null); setPestSymptoms([]); }}
                  className={`flex-1 py-2.5 rounded-lg text-sm font-medium border transition-colors ${pestScanMode===m ? "bg-[#1e4d2b] text-white border-[#1e4d2b]" : "border-[#e8e3d8] text-[#7c5c32] hover:bg-[#f0ebe0]"}`}>
                  {m==="photo" ? "📷 Photo Scan" : "📋 Symptom Checker"}
                </button>
              ))}
            </div>

            {/* Crop selector */}
            <div className="mb-4">
              <label className="block text-xs font-mono text-[#7c5c32] mb-1.5 uppercase tracking-wider">Your Crop</label>
              <div className="flex flex-wrap gap-2">
                {["Tomato","Potato","Onion","Wheat","Rice","Chilli","Maize","Cotton","Banana","Sugarcane"].map(c => (
                  <button key={c} onClick={() => { setPestCrop(c); setPestResult(null); setPestSymptoms([]); }}
                    className={`px-3 py-1.5 rounded-lg text-sm border transition-colors ${pestCrop===c ? "bg-red-600 text-white border-red-600" : "border-[#e8e3d8] text-[#7c5c32] hover:border-red-300"}`}>
                    {CROP_YIELDS[c]?.icon ?? "🌿"} {c}
                  </button>
                ))}
              </div>
            </div>

            {/* Symptom selector (symptoms mode) */}
            {pestScanMode === "symptoms" && (
              <div className="mb-4">
                <label className="block text-xs font-mono text-[#7c5c32] mb-2 uppercase tracking-wider">Select All Visible Symptoms</label>
                <div className="grid sm:grid-cols-2 gap-2">
                  {[
                    { id:"brown-spots",   label:"Brown/black spots on leaves" },
                    { id:"yellow-halo",   label:"Yellow halo around lesions" },
                    { id:"white-powder",  label:"White powdery coating on leaves" },
                    { id:"water-soaked",  label:"Water-soaked, dark patches" },
                    { id:"white-mold",    label:"White mold on leaf underside" },
                    { id:"upward-curl",   label:"Leaves curl upward/inward" },
                    { id:"wilting-daytime",label:"Wilts in afternoon, recovers at night" },
                    { id:"orange-pustules",label:"Orange/brown pustules on stems/leaves" },
                    { id:"hopper-burn",   label:"Circular dead patches from plant base" },
                    { id:"window-pane",   label:"Transparent window-pane feeding marks" },
                    { id:"sunken-lesions",label:"Sunken dark lesions on fruit/stem" },
                    { id:"purple-fuzz",   label:"Purple/grey fuzzy growth on surface" },
                    { id:"frass-funnel",  label:"Excreta in plant funnel/heart" },
                    { id:"leaf-drop",     label:"Premature leaf/fruit drop" },
                    { id:"whitefly",      label:"Tiny white insects under leaves" },
                  ].map(s => (
                    <label key={s.id} className={`flex items-center gap-2.5 p-3 rounded-lg border cursor-pointer transition-colors ${pestSymptoms.includes(s.id) ? "border-red-400 bg-red-50" : "border-[#e8e3d8] hover:bg-[#f9f7f2]"}`}>
                      <input type="checkbox" className="accent-red-600"
                        checked={pestSymptoms.includes(s.id)}
                        onChange={e => setPestSymptoms(prev => e.target.checked ? [...prev, s.id] : prev.filter(x => x !== s.id))}/>
                      <span className="text-sm text-[#1a1a0e]">{s.label}</span>
                    </label>
                  ))}
                </div>
              </div>
            )}

            <div className="flex gap-3 flex-wrap">
              {pestScanMode === "photo" ? (
                <>
                  <button onClick={runPestDetect} disabled={detecting}
                    className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-xl font-semibold transition-colors disabled:opacity-60 flex items-center gap-2 text-sm">
                    {detecting ? <><span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin"/>Scanning…</> : "🔬 Scan Sample Photo"}
                  </button>
                  <label className="bg-white border border-[#e8e3d8] text-[#7c5c32] px-6 py-3 rounded-xl font-medium cursor-pointer hover:bg-[#f0ebe0] transition-colors text-sm flex items-center gap-2">
                    📁 Upload Field Photo
                    <input type="file" accept="image/*" className="hidden" onChange={() => runPestDetect()}/>
                  </label>
                </>
              ) : (
                <button onClick={runPestDetect} disabled={detecting || pestSymptoms.length === 0}
                  className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-xl font-semibold transition-colors disabled:opacity-60 flex items-center gap-2 text-sm">
                  {detecting ? <><span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin"/>Diagnosing…</> : `🧠 Diagnose (${pestSymptoms.length} symptoms selected)`}
                </button>
              )}
            </div>
          </div>

          {detecting && (
            <div className="bg-white border border-[#e8e3d8] rounded-2xl p-8 text-center">
              <div className="w-12 h-12 border-4 border-red-100 border-t-red-500 rounded-full animate-spin mx-auto mb-4"/>
              <p className="font-semibold text-[#1a1a0e]">Cross-referencing disease database…</p>
              <p className="text-sm text-[#7c5c32] mt-1">Matching symptoms against ICAR, NIPHM & state agriculture records</p>
            </div>
          )}

          {pestResult && !detecting && (
            <div className="space-y-4">
              <div className="bg-white border border-red-200 rounded-2xl overflow-hidden shadow-sm">
                {/* Header */}
                <div className={`px-6 py-4 flex items-start gap-3 ${pestResult.severity.includes("Very High") || pestResult.severity.includes("URGENT") ? "bg-red-700" : "bg-red-600"} text-white`}>
                  <span className="text-3xl flex-shrink-0">{pestResult.icon}</span>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="font-bold text-lg">{pestResult.name}</p>
                      <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full font-mono">{pestResult.type}</span>
                    </div>
                    <p className="text-sm text-red-200 italic mt-0.5">{pestResult.sci}</p>
                    <p className="text-sm text-red-100 mt-1">Affects: {pestResult.crops.join(", ")} · Spread: {pestResult.spread}</p>
                  </div>
                </div>
                <div className="p-6 space-y-5">
                  {/* Severity + Loss risk */}
                  <div className="grid sm:grid-cols-2 gap-3">
                    <div className="bg-red-50 border border-red-200 rounded-xl p-3">
                      <p className="text-xs font-mono text-red-700 uppercase mb-1">Severity</p>
                      <p className="font-semibold text-red-800">{pestResult.severity}</p>
                    </div>
                    <div className="bg-amber-50 border border-amber-200 rounded-xl p-3">
                      <p className="text-xs font-mono text-amber-700 uppercase mb-1">Yield Risk</p>
                      <p className="font-semibold text-amber-800">{pestResult.lossRisk}</p>
                    </div>
                  </div>

                  {/* Symptoms checklist */}
                  <div>
                    <p className="text-xs font-mono text-[#7c5c32] uppercase tracking-wider mb-2">Diagnostic Symptoms</p>
                    <ul className="space-y-1.5">
                      {pestResult.symptomLabels.map((s, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-[#1a1a0e]">
                          <span className="text-red-500 font-bold flex-shrink-0 mt-0.5">✓</span>
                          {s}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Chemical treatment */}
                  <div>
                    <p className="text-xs font-mono text-[#7c5c32] uppercase tracking-wider mb-2">⚗️ Chemical Treatment</p>
                    <div className="bg-[#fef9ec] border border-[#e8b535] rounded-xl p-4">
                      <p className="text-sm text-[#1a1a0e] leading-relaxed">{pestResult.chemical}</p>
                    </div>
                  </div>

                  {/* Organic/biological */}
                  <div>
                    <p className="text-xs font-mono text-[#7c5c32] uppercase tracking-wider mb-2">🌿 Organic / Biological Alternatives</p>
                    <div className="bg-[#d6f0de] border border-[#4a7c59] rounded-xl p-4">
                      <p className="text-sm text-[#1e4d2b] leading-relaxed">{pestResult.organic}</p>
                    </div>
                  </div>

                  {/* Prevention */}
                  <div>
                    <p className="text-xs font-mono text-[#7c5c32] uppercase tracking-wider mb-2">🛡️ Prevention Measures</p>
                    <ul className="space-y-1.5">
                      {pestResult.prevention.map((p, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-[#1a1a0e]">
                          <span className="text-[#1e4d2b] font-bold flex-shrink-0">•</span>
                          {p}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Urgency + KVK */}
                  <div className="flex items-center gap-2 p-3 bg-red-50 rounded-xl border border-red-200">
                    <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse flex-shrink-0"/>
                    <span className="text-sm font-semibold text-red-700">Act: {pestResult.urgency}</span>
                    <span className="ml-auto text-xs text-red-500 font-mono">{pestResult.kvk}</span>
                  </div>

                  <div className="flex gap-3 flex-wrap">
                    <button className="bg-[#1e4d2b] text-white px-5 py-2.5 rounded-xl text-sm font-medium hover:bg-[#2d6b3e] transition-colors">📞 Report to KVK (1800-180-1551)</button>
                    <button className="border border-[#e8e3d8] text-[#7c5c32] px-5 py-2.5 rounded-xl text-sm hover:bg-[#f0ebe0] transition-colors">🛒 Get Pesticide Quote</button>
                    <button onClick={() => { setPestResult(null); setPestSymptoms([]); }} className="border border-[#e8e3d8] text-[#7c5c32] px-5 py-2.5 rounded-xl text-sm hover:bg-[#f0ebe0] transition-colors">Scan Another</button>
                  </div>
                </div>
              </div>

              <div className="bg-[#fef9ec] border border-[#e8b535] rounded-xl p-4 flex items-start gap-3">
                <span className="text-xl flex-shrink-0">💡</span>
                <p className="text-sm text-[#92400e]"><b>Insurance tip:</b> Pest events like {pestResult.name} are claimable under PM Fasal Bima Yojana. Document with geo-tagged photos and report to your insurer within 72 hours of crop damage. Enroll deadline: Oct 31.</p>
              </div>

              {/* All diseases for this crop */}
              <div className="bg-white border border-[#e8e3d8] rounded-2xl p-5">
                <h4 className="font-semibold text-sm mb-3">Other diseases affecting {pestCrop}</h4>
                <div className="space-y-2">
                  {PEST_DB.filter(d => d.crops.includes(pestCrop) && d.id !== pestResult.id).map(d => (
                    <button key={d.id} onClick={() => setPestResult(d)}
                      className="w-full flex items-center gap-3 p-3 rounded-xl border border-[#e8e3d8] hover:border-red-300 hover:bg-red-50 text-left transition-colors">
                      <span className="text-xl flex-shrink-0">{d.icon}</span>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-[#1a1a0e]">{d.name}</p>
                        <p className="text-xs text-[#7c5c32] italic">{d.sci}</p>
                      </div>
                      <span className={`text-xs font-mono px-2 py-0.5 rounded-full flex-shrink-0 ${d.severity.includes("Very High") ? "bg-red-100 text-red-700" : d.severity.includes("High") ? "bg-amber-100 text-amber-700" : "bg-[#d6f0de] text-[#1e4d2b]"}`}>{d.severity.split("—")[0].trim()}</span>
                    </button>
                  ))}
                  {PEST_DB.filter(d => d.crops.includes(pestCrop) && d.id !== pestResult.id).length === 0 && (
                    <p className="text-sm text-[#7c5c32]">No other diseases in database for {pestCrop}. Select a different crop to explore.</p>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Disease quick-reference library */}
          {!pestResult && !detecting && (
            <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6">
              <h4 className="font-semibold mb-3 text-sm">📚 Disease Library — Click to Learn</h4>
              <div className="grid sm:grid-cols-2 gap-3">
                {PEST_DB.filter(d => d.crops.includes(pestCrop)).map(d => (
                  <button key={d.id} onClick={() => { setPestResult(d); setPestSymptoms([]); }}
                    className="flex items-start gap-3 p-3.5 rounded-xl border border-[#e8e3d8] hover:border-red-300 hover:shadow-sm text-left transition-all">
                    <span className="text-2xl flex-shrink-0">{d.icon}</span>
                    <div>
                      <p className="text-sm font-semibold text-[#1a1a0e]">{d.name}</p>
                      <p className="text-xs text-[#7c5c32] italic mt-0.5">{d.sci} · {d.type}</p>
                      <p className="text-xs mt-1 font-mono" style={{color: d.severity.includes("Very High") ? "#991b1b" : d.severity.includes("High") ? "#92400e" : "#1e4d2b"}}>⚠ {d.severity}</p>
                    </div>
                  </button>
                ))}
                {PEST_DB.filter(d => d.crops.includes(pestCrop)).length === 0 && (
                  <div className="col-span-2 text-center py-8 text-[#7c5c32] text-sm">
                    <p className="text-3xl mb-2">🔍</p>
                    <p>No specific diseases in library for {pestCrop}. Use Symptom Checker mode to diagnose.</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── Tab: Financial Hub ── */}
      {tab === "financial" && (
        <div className="space-y-5">
          {/* Sub-tabs */}
          <div className="flex gap-1 bg-[#f0ebe0] rounded-xl p-1">
            {([
              {id:"schemes",     label:"🏛 Govt Schemes"},
              {id:"emi",         label:"📊 EMI Calculator"},
              {id:"eligibility", label:"✅ Eligibility Check"},
            ] as const).map(ft => (
              <button key={ft.id} onClick={() => setFinTab(ft.id)}
                className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all whitespace-nowrap ${finTab===ft.id ? "bg-white text-[#1e4d2b] shadow-sm" : "text-[#7c5c32] hover:text-[#1e4d2b]"}`}>
                {ft.label}
              </button>
            ))}
          </div>

          {/* ─ Govt Schemes sub-tab ─ */}
          {finTab === "schemes" && (
            <div className="space-y-4">
              {FINANCIAL_SCHEMES_DETAIL.map(s => (
                <div key={s.id} className="bg-white border border-[#e8e3d8] rounded-2xl overflow-hidden">
                  <button
                    className="w-full flex items-center gap-4 p-5 text-left hover:bg-[#faf7f0] transition-colors"
                    onClick={() => setSchemeExpanded(schemeExpanded === s.id ? null : s.id)}>
                    <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl flex-shrink-0" style={{background:`${s.color}18`}}>
                      {s.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-[#1a1a0e]">{s.name}</p>
                      <p className="text-xs text-[#7c5c32] mt-0.5">{s.interest}</p>
                    </div>
                    <span className="text-[#7c5c32] flex-shrink-0">{schemeExpanded === s.id ? "▲" : "▼"}</span>
                  </button>
                  {schemeExpanded === s.id && (
                    <div className="border-t border-[#e8e3d8] p-5 space-y-4 bg-[#faf7f0]">
                      <div className="grid sm:grid-cols-2 gap-4">
                        <div>
                          <p className="text-xs font-mono text-[#7c5c32] uppercase mb-1">Loan / Benefit Limit</p>
                          <p className="text-sm font-semibold text-[#1a1a0e]">{s.limit}</p>
                        </div>
                        <div>
                          <p className="text-xs font-mono text-[#7c5c32] uppercase mb-1">Eligibility</p>
                          <p className="text-sm text-[#1a1a0e]">{s.eligibility}</p>
                        </div>
                      </div>
                      <div>
                        <p className="text-xs font-mono text-[#7c5c32] uppercase mb-1.5">Documents Required</p>
                        <ul className="flex flex-wrap gap-2">
                          {s.documents.map((d, i) => (
                            <li key={i} className="text-xs bg-white border border-[#e8e3d8] rounded-lg px-2.5 py-1 text-[#1a1a0e]">📄 {d}</li>
                          ))}
                        </ul>
                      </div>
                      <div className="bg-[#d6f0de] border border-[#4a7c59] rounded-xl p-3">
                        <p className="text-xs font-mono text-[#1e4d2b] uppercase mb-1">Key Benefit</p>
                        <p className="text-sm text-[#1e4d2b]">{s.benefit}</p>
                      </div>
                      <div className="flex items-center justify-between flex-wrap gap-3">
                        <p className="text-xs font-mono text-[#7c5c32]">📞 Helpline: {s.helpline}</p>
                        <div className="flex gap-2">
                          <button className="text-sm font-semibold px-4 py-2 rounded-xl transition-colors bg-[#1e4d2b] text-white hover:bg-[#2d6b3e]">Apply Now</button>
                          <button className="text-sm font-semibold px-4 py-2 rounded-xl transition-colors border border-[#e8e3d8] text-[#7c5c32] hover:bg-[#f0ebe0]">Check Status</button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
              {/* Warehouse financing (preserved existing) */}
              <div className="bg-[#1e4d2b] text-white rounded-2xl p-6">
                <div className="flex items-start gap-4 flex-wrap">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-xl">🏦</span>
                      <h3 className="font-semibold text-lg" style={{fontFamily:"var(--font-display)"}}>Warehouse Receipt Financing</h3>
                      <span className="text-xs font-mono bg-[#e8b535] text-[#1a1a0e] px-2 py-0.5 rounded-full font-semibold">Active</span>
                    </div>
                    <p className="text-sm text-[#c8dfc8] mb-3">Your verified FPO stock acts as collateral for a short-term loan while you wait for better price windows. Kisansetu-verified stock qualifies automatically.</p>
                    <div className="grid grid-cols-3 gap-3 mb-4">
                      {[
                        { label:"Verified Stock", value:"12 MT Onion" },
                        { label:"Loan Eligible", value:"₹1.84 lakh" },
                        { label:"Rate", value:"8.5% p.a." },
                      ].map(ws => (
                        <div key={ws.label} className="bg-white/10 rounded-xl p-3">
                          <p className="text-xs text-white/60 font-mono mb-1">{ws.label}</p>
                          <p className="font-bold font-mono text-[#e8b535]">{ws.value}</p>
                        </div>
                      ))}
                    </div>
                    <p className="text-xs text-[#c8dfc8] font-mono">Status: Eligible — stock verified by Nashik FPO · Tenure: 90 days</p>
                  </div>
                  <div>
                    <button onClick={() => setWfApplied(true)}
                      className={`px-5 py-3 rounded-xl font-semibold text-sm transition-colors ${wfApplied ? "bg-[#4ade80] text-[#1a1a0e]" : "bg-[#e8b535] text-[#1a1a0e] hover:bg-[#fbbf24]"}`}>
                      {wfApplied ? "✓ Application Submitted" : "Apply for Loan"}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ─ EMI Calculator sub-tab ─ */}
          {finTab === "emi" && (
            <div className="space-y-4">
              <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6">
                <h4 className="font-semibold mb-4" style={{fontFamily:"var(--font-display)"}}>💳 KCC / Agri Loan EMI Calculator</h4>
                <div className="grid sm:grid-cols-3 gap-4 mb-6">
                  <div>
                    <label className="block text-xs font-mono text-[#7c5c32] mb-1.5 uppercase">Loan Amount (₹)</label>
                    <input type="number" min={10000} max={3000000} step={5000}
                      value={loanAmt} onChange={e => setLoanAmt(parseInt(e.target.value) || 0)}
                      className="w-full border border-[#e8e3d8] rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-[#c8941a] font-mono"/>
                    <p className="text-xs text-[#7c5c32] mt-1">= ₹{(loanAmt/100000).toFixed(2)} lakh</p>
                  </div>
                  <div>
                    <label className="block text-xs font-mono text-[#7c5c32] mb-1.5 uppercase">Interest Rate (% p.a.)</label>
                    <input type="number" min={4} max={18} step={0.25}
                      value={loanRate} onChange={e => setLoanRate(parseFloat(e.target.value) || 7)}
                      className="w-full border border-[#e8e3d8] rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-[#c8941a] font-mono"/>
                    <div className="flex gap-1 mt-1 flex-wrap">
                      {[[4,"KCC+subvention"],[7,"KCC standard"],[9,"Short-term"],[12,"Regular agri"]].map(([r,l]) => (
                        <button key={r} onClick={() => setLoanRate(r as number)} className="text-[10px] px-1.5 py-0.5 rounded bg-[#f0ebe0] text-[#7c5c32] hover:bg-[#e8e3d8]">{l}</button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-mono text-[#7c5c32] mb-1.5 uppercase">Tenure (Months)</label>
                    <input type="number" min={3} max={84} step={3}
                      value={loanTenure} onChange={e => setLoanTenure(parseInt(e.target.value) || 12)}
                      className="w-full border border-[#e8e3d8] rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-[#c8941a] font-mono"/>
                    <div className="flex gap-1 mt-1 flex-wrap">
                      {[[6,"6m"],[12,"1yr"],[24,"2yr"],[36,"3yr"]].map(([t,l]) => (
                        <button key={t} onClick={() => setLoanTenure(t as number)} className="text-[10px] px-1.5 py-0.5 rounded bg-[#f0ebe0] text-[#7c5c32] hover:bg-[#e8e3d8]">{l}</button>
                      ))}
                    </div>
                  </div>
                </div>
                {/* Result */}
                <div className="bg-[#1e4d2b] text-white rounded-2xl p-5 grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
                  {[
                    { label:"Monthly EMI", value:`₹${calcEMI().toLocaleString("en-IN")}`, big:true },
                    { label:"Total Payment", value:`₹${(calcEMI() * loanTenure).toLocaleString("en-IN")}` },
                    { label:"Total Interest", value:`₹${(calcEMI() * loanTenure - loanAmt).toLocaleString("en-IN")}` },
                    { label:"Interest / Loan", value:`${((calcEMI() * loanTenure - loanAmt) / loanAmt * 100).toFixed(1)}%` },
                  ].map(s => (
                    <div key={s.label}>
                      <p className={`font-bold font-mono text-[#e8b535] ${s.big ? "text-2xl" : "text-lg"}`}>{s.value}</p>
                      <p className="text-xs text-white/70 font-mono mt-1">{s.label}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-4 p-4 bg-[#fef9ec] border border-[#e8b535] rounded-xl">
                  <p className="text-sm text-[#92400e]"><b>KCC Tip:</b> At 7% p.a., KCC provides 3% subvention on prompt repayment — effective rate drops to <b>4% p.a.</b> for the first ₹3 lakh. Always repay within 1 year to claim the subvention.</p>
                </div>
              </div>
              {/* Loan comparison */}
              <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6">
                <h4 className="font-semibold mb-3 text-sm">📋 Agri Loan Options Comparison</h4>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-[#e8e3d8]">
                        <th className="text-left py-2 font-mono text-[#7c5c32]">Scheme</th>
                        <th className="text-right py-2 font-mono text-[#7c5c32]">Rate</th>
                        <th className="text-right py-2 font-mono text-[#7c5c32]">Effective Rate</th>
                        <th className="text-right py-2 font-mono text-[#7c5c32]">Max Limit</th>
                        <th className="text-right py-2 font-mono text-[#7c5c32]">Collateral</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[
                        {name:"KCC (prompt repayment)",rate:"7%",eff:"4%",limit:"₹3 lakh",coll:"None"},
                        {name:"KCC (standard)",rate:"7%",eff:"7%",limit:"₹3 lakh",coll:"None"},
                        {name:"KCC (above ₹3L)",rate:"7%",eff:"7%",limit:"₹10 lakh",coll:"Land/FD"},
                        {name:"Term Loan (crop)",rate:"9%",eff:"9%",limit:"₹10 lakh",coll:"Land"},
                        {name:"Warehouse Receipt",rate:"8.5%",eff:"8.5%",limit:"75% of stock value",coll:"Stock"},
                        {name:"MUDRA Kishor (FPO)",rate:"9–12%",eff:"9–12%",limit:"₹10 lakh",coll:"None"},
                      ].map(row => (
                        <tr key={row.name} className="border-b border-[#f0ebe0]">
                          <td className="py-2 font-medium text-[#1a1a0e]">{row.name}</td>
                          <td className="py-2 text-right font-mono">{row.rate}</td>
                          <td className="py-2 text-right font-mono text-[#1e4d2b] font-semibold">{row.eff}</td>
                          <td className="py-2 text-right font-mono">{row.limit}</td>
                          <td className="py-2 text-right text-[#7c5c32]">{row.coll}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ─ Eligibility Check sub-tab ─ */}
          {finTab === "eligibility" && (
            <div className="space-y-4">
              {/* KCC eligibility */}
              <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6">
                <h4 className="font-semibold mb-1" style={{fontFamily:"var(--font-display)"}}>💳 KCC Loan Eligibility Estimator</h4>
                <p className="text-sm text-[#7c5c32] mb-4">Enter your land holding to estimate KCC credit limit based on NABARD scale of finance.</p>
                <div className="flex gap-3 items-end mb-4 flex-wrap">
                  <div>
                    <label className="block text-xs font-mono text-[#7c5c32] mb-1.5 uppercase">Agricultural Land (Hectares)</label>
                    <input type="number" min={0.1} max={20} step={0.1} value={landHa}
                      onChange={e => setLandHa(parseFloat(e.target.value) || 1)}
                      className="w-36 border border-[#e8e3d8] rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-[#1e4d2b] font-mono"/>
                  </div>
                  <div className="text-sm text-[#7c5c32]">= {(landHa * 2.47).toFixed(1)} acres</div>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-4">
                  {[
                    { label:"KCC Credit Limit", value:`₹${Math.min(Math.round(landHa * 90000), 300000).toLocaleString("en-IN")}` },
                    { label:"Interest Rate", value:"7% (4% effective)" },
                    { label:"Collateral Required", value:calcLoanEligibility() >= 300000 ? "Land records needed" : "None" },
                  ].map(s => (
                    <div key={s.label} className="bg-[#f9f7f2] rounded-xl p-3">
                      <p className="text-xs font-mono text-[#7c5c32] mb-1">{s.label}</p>
                      <p className="font-bold text-sm text-[#1e4d2b]">{s.value}</p>
                    </div>
                  ))}
                </div>
                <p className="text-xs text-[#7c5c32]">Estimate based on ₹90,000/hectare NABARD scale of finance for mixed crop. Actual limit set by your bank branch based on crop plan, soil type, and credit history.</p>
              </div>

              {/* PM-KISAN status check */}
              <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6">
                <h4 className="font-semibold mb-1" style={{fontFamily:"var(--font-display)"}}>🌾 PM-KISAN Installment Status</h4>
                <p className="text-sm text-[#7c5c32] mb-4">Check if your next ₹2,000 installment is due. Requires Aadhaar-linked bank account.</p>
                <div className="grid sm:grid-cols-2 gap-3 mb-3">
                  <div>
                    <label className="block text-xs font-mono text-[#7c5c32] mb-1.5">Farmer Name (as in land record)</label>
                    <input value={pmkisanName} onChange={e => { setPmkisanName(e.target.value); setPmkisanStatus(null); }}
                      placeholder="e.g. Ramesh Kumar Yadav"
                      className="w-full border border-[#e8e3d8] rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-[#1e4d2b]"/>
                  </div>
                  <div>
                    <label className="block text-xs font-mono text-[#7c5c32] mb-1.5">Aadhaar Number (12 digits)</label>
                    <input value={pmkisanAadhaar} onChange={e => { setPmkisanAadhaar(e.target.value.replace(/\D/g,"")); setPmkisanStatus(null); }}
                      maxLength={12} placeholder="XXXXXXXXXXXX"
                      className="w-full border border-[#e8e3d8] rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-[#1e4d2b] font-mono tracking-widest"/>
                  </div>
                </div>
                <button onClick={checkPmkisanStatus}
                  disabled={!pmkisanName || pmkisanAadhaar.length < 12}
                  className="bg-[#1e4d2b] text-white px-6 py-2.5 rounded-xl text-sm font-semibold hover:bg-[#2d6b3e] transition-colors disabled:opacity-50">
                  Check PM-KISAN Status
                </button>
                {pmkisanStatus && (
                  <div className={`mt-4 p-4 rounded-xl border ${pmkisanStatus.startsWith("Active") || pmkisanStatus.startsWith("Eligible") ? "bg-[#d6f0de] border-[#4a7c59] text-[#1e4d2b]" : "bg-amber-50 border-amber-300 text-amber-800"}`}>
                    <p className="text-sm font-semibold">📋 {pmkisanName}</p>
                    <p className="text-sm mt-1">{pmkisanStatus}</p>
                  </div>
                )}
              </div>

              {/* PMFBY premium estimator */}
              <div className="bg-[#fef9ec] border border-[#e8b535] rounded-2xl p-5">
                <h4 className="font-semibold mb-3" style={{fontFamily:"var(--font-display)"}}>🛡️ PM Fasal Bima Premium Estimator</h4>
                <div className="grid sm:grid-cols-2 gap-3">
                  {[
                    {crop:"Kharif crops (Rice, Maize, Soybean)", premium:"2% of Sum Insured", govt:"98% premium"},
                    {crop:"Rabi crops (Wheat, Mustard, Gram)", premium:"1.5% of Sum Insured", govt:"98.5% premium"},
                    {crop:"Horticultural crops (Onion, Tomato, Potato)", premium:"5% of Sum Insured", govt:"95% premium"},
                    {crop:"Sugarcane (Annual commercial)", premium:"5% of Sum Insured", govt:"95% premium"},
                  ].map(row => (
                    <div key={row.crop} className="bg-white rounded-xl p-3 border border-[#e8b535]">
                      <p className="text-xs font-semibold text-[#1a1a0e]">{row.crop}</p>
                      <p className="text-lg font-bold font-mono text-[#c8941a] mt-1">{row.premium}</p>
                      <p className="text-xs text-[#7c5c32]">Govt pays: {row.govt}</p>
                    </div>
                  ))}
                </div>
                <p className="text-xs text-[#92400e] mt-3">Example: For 1 hectare wheat with sum insured ₹60,000 → Your premium = ₹900 only. Govt pays ₹59,100. Enrollment deadline: Oct 31 (Kharif) / Dec 31 (Rabi). Call 14447 to enroll.</p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── Tab: Community & Calendar ── */}
      {tab === "community" && (
        <div className="space-y-5">
          {/* Sub-tabs */}
          <div className="flex gap-1 bg-[#f0ebe0] rounded-xl p-1">
            {([{id:"feed",label:"💬 Farmer Forum"},{id:"fpo",label:"🤝 FPO Pools"},{id:"calendar",label:"📅 Crop Calendar"}] as const).map(ct => (
              <button key={ct.id} onClick={() => setCommunityTab(ct.id)}
                className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all whitespace-nowrap ${communityTab===ct.id ? "bg-white text-[#1e4d2b] shadow-sm" : "text-[#7c5c32] hover:text-[#1e4d2b]"}`}>
                {ct.label}
              </button>
            ))}
          </div>

          {/* ─ Farmer Forum ─ */}
          {communityTab === "feed" && (
            <div className="space-y-4">
              {/* Peer market visibility */}
              <div className="bg-white border border-[#e8e3d8] rounded-2xl p-5">
                <h3 className="font-semibold mb-1" style={{fontFamily:"var(--font-display)"}}>📊 Real-Time Peer Prices</h3>
                <p className="text-xs text-[#7c5c32] mb-3">What verified farmers in your network actually sold for this week. Reduces information asymmetry vs middlemen.</p>
                <div className="space-y-2.5">
                  {PEER_INSIGHTS.map(p => (
                    <div key={p.crop} className="flex items-center gap-3 p-3.5 bg-[#f9f7f2] rounded-xl hover:bg-[#f0ebe0] transition-colors">
                      <div className="w-9 h-9 rounded-lg bg-[#d6f0de] flex items-center justify-center text-base flex-shrink-0">
                        {p.icon}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-[#1a1a0e]">{p.crop} · <span className="font-normal text-[#7c5c32]">{p.region}</span></p>
                        <p className="text-xs text-[#7c5c32]">{p.sold} farmers · Best mandi: <b className="text-[#1a1a0e]">{p.bestMandi}</b></p>
                        <p className="text-[10px] text-[#7c5c32] mt-0.5">Buyers: {p.buyers}</p>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <p className="font-mono font-bold text-[#1e4d2b]">{p.avgPrice}</p>
                        <p className={`text-xs font-mono font-bold ${p.up ? "text-[#4a7c59]" : "text-red-600"}`}>{p.trend}</p>
                        {p.msp !== "Market rate" && <p className="text-[10px] text-[#c8941a] font-mono">MSP: {p.msp}</p>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              {/* Forum posts */}
              <div className="space-y-3">
                {COMMUNITY_POSTS.map(post => (
                  <div key={post.id} className="bg-white border border-[#e8e3d8] rounded-2xl p-5 hover:border-[#4a7c59] transition-colors">
                    <div className="flex items-start gap-3 mb-3">
                      <div className="w-10 h-10 rounded-full bg-[#d6f0de] flex items-center justify-center text-xl flex-shrink-0">{post.avatar}</div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-semibold text-sm text-[#1a1a0e]">{post.name}</span>
                          <span className="text-xs text-[#7c5c32]">· {post.region}</span>
                          <Badge label={post.crop} variant="green"/>
                          <span className="ml-auto text-[10px] text-[#7c5c32] font-mono">{post.time}</span>
                        </div>
                      </div>
                    </div>
                    <p className="text-sm text-[#1a1a0e] leading-relaxed mb-3">{post.text}</p>
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => setPostLikes(prev => ({...prev, [post.id]: !prev[post.id]}))}
                        className={`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg transition-colors border ${postLikes[post.id] ? "bg-[#d6f0de] border-[#4a7c59] text-[#1e4d2b]" : "border-[#e8e3d8] text-[#7c5c32] hover:bg-[#f0ebe0]"}`}>
                        👍 {post.likes + (postLikes[post.id] ? 1 : 0)}
                      </button>
                      <button className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border border-[#e8e3d8] text-[#7c5c32] hover:bg-[#f0ebe0] transition-colors">
                        💬 {post.replies} replies
                      </button>
                      <button className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border border-[#e8e3d8] text-[#7c5c32] hover:bg-[#f0ebe0] transition-colors ml-auto">
                        📤 Share
                      </button>
                    </div>
                  </div>
                ))}
              </div>
              {/* Post reply box */}
              <div className="bg-white border border-[#e8e3d8] rounded-2xl p-4 flex gap-3">
                <div className="w-9 h-9 rounded-full bg-[#1e4d2b] flex items-center justify-center text-white text-sm flex-shrink-0">👨</div>
                <input className="flex-1 border border-[#e8e3d8] rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-[#1e4d2b]" placeholder="Share your price, experience, or question with the community…"/>
                <button className="bg-[#1e4d2b] text-white px-4 py-2.5 rounded-xl text-sm font-medium hover:bg-[#2d6b3e] transition-colors flex-shrink-0">Post</button>
              </div>
            </div>
          )}

          {/* ─ FPO Pools ─ */}
          {communityTab === "fpo" && (
            <div className="space-y-4">
              <div className="bg-[#fef9ec] border border-[#e8b535] rounded-2xl p-4">
                <p className="text-sm text-[#92400e]"><b>How FPO Pooling works:</b> Small farmers aggregate produce to meet large buyer minimums (usually 50–100 MT). Pools negotiate 8–20% better prices than individual sales. Kisansetu verifies all pooled stock before listing.</p>
              </div>
              {FPO_POOLS.map(pool => {
                const pct = Math.round((pool.collected / pool.target) * 100);
                const joined = fpoJoined.includes(pool.id);
                return (
                  <div key={pool.id} className={`bg-white border rounded-2xl p-5 transition-all ${joined ? "border-[#4a7c59] shadow-md" : "border-[#e8e3d8] hover:border-[#e8b535]"}`}>
                    <div className="flex items-start gap-3 mb-3">
                      <span className="text-3xl flex-shrink-0">{pool.icon}</span>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="font-semibold text-[#1a1a0e]">{pool.crop}</p>
                          <Badge label={pool.region} variant="gray"/>
                          {joined && <Badge label="✓ Joined" variant="green"/>}
                        </div>
                        <p className="text-xs text-[#7c5c32] mt-0.5">Target: {pool.targetPrice} · Min qty: {pool.minQty} · Closes: {pool.deadline}</p>
                      </div>
                    </div>
                    <div className="mb-3">
                      <div className="flex justify-between text-xs font-mono text-[#7c5c32] mb-1">
                        <span>{pool.collected} MT collected</span>
                        <span>Target: {pool.target} MT ({pct}%)</span>
                      </div>
                      <div className="w-full bg-[#e8e3d8] rounded-full h-2.5">
                        <div className="h-2.5 rounded-full transition-all duration-700" style={{width:`${pct}%`, background: pct >= 80 ? "#1e4d2b" : pct >= 50 ? "#c8941a" : "#e8b535"}}/>
                      </div>
                    </div>
                    <div className="flex items-center justify-between flex-wrap gap-3">
                      <p className="text-xs text-[#7c5c32]">{pool.farmers}/{pool.maxFarmers} farmers · {pool.maxFarmers - pool.farmers} slots remaining</p>
                      <button
                        onClick={() => setFpoJoined(prev => joined ? prev.filter(x => x !== pool.id) : [...prev, pool.id])}
                        className={`px-5 py-2.5 rounded-xl text-sm font-semibold transition-colors ${joined ? "bg-[#d6f0de] text-[#1e4d2b] border border-[#4a7c59]" : "bg-[#c8941a] text-white hover:bg-[#e8b535]"}`}>
                        {joined ? "✓ Leave Pool" : "Join Bulk Pool →"}
                      </button>
                    </div>
                  </div>
                );
              })}
              <div className="bg-white border border-dashed border-[#e8e3d8] rounded-2xl p-5 text-center">
                <p className="text-2xl mb-2">➕</p>
                <p className="font-semibold text-sm text-[#1a1a0e] mb-1">Start a new pool</p>
                <p className="text-xs text-[#7c5c32] mb-3">Have 3+ tonnes of a crop? Start a pool and Kisansetu will help recruit farmers from your district.</p>
                <button className="bg-[#1e4d2b] text-white px-5 py-2.5 rounded-xl text-sm font-semibold hover:bg-[#2d6b3e] transition-colors">Create FPO Pool</button>
              </div>
            </div>
          )}

          {/* ─ Crop Calendar ─ */}
          {communityTab === "calendar" && (
            <div className="space-y-4">
              <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6">
                <h3 className="font-semibold mb-4" style={{fontFamily:"var(--font-display)"}}>📅 Crop Calendar & Agronomy Alerts</h3>
                <div className="space-y-3">
                  {CROP_CALENDAR_ITEMS.map(item => (
                    <div key={item.event} className={`rounded-xl border p-4 ${item.color}`}>
                      <div className="flex items-center gap-3 mb-2">
                        <span className="text-xl flex-shrink-0">{item.icon}</span>
                        <div className="flex-1">
                          <p className="text-sm font-semibold">{item.event}</p>
                          <p className="text-[10px] font-mono opacity-70">{item.date} · {item.daysLeft} days left</p>
                        </div>
                        <span className="text-[9px] font-mono uppercase tracking-wider opacity-70 flex-shrink-0 text-right">{item.type}</span>
                      </div>
                      <p className="text-xs opacity-80 pl-8">{item.action}</p>
                    </div>
                  ))}
                </div>
              </div>
              {/* Season reference */}
              <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6">
                <h4 className="font-semibold mb-3 text-sm">🗓 Indian Crop Season Calendar</h4>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-[#e8e3d8]">
                        <th className="text-left py-2 font-mono text-[#7c5c32]">Season</th>
                        <th className="text-left py-2 font-mono text-[#7c5c32]">Sowing</th>
                        <th className="text-left py-2 font-mono text-[#7c5c32]">Harvest</th>
                        <th className="text-left py-2 font-mono text-[#7c5c32]">Key Crops</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[
                        {season:"Kharif", sowing:"Jun–Jul", harvest:"Sep–Oct", crops:"Rice, Maize, Soybean, Cotton, Groundnut, Bajra", color:"bg-blue-50"},
                        {season:"Rabi",   sowing:"Oct–Nov", harvest:"Mar–Apr", crops:"Wheat, Mustard, Gram, Peas, Lentil, Potato",     color:"bg-[#d6f0de]"},
                        {season:"Zaid",   sowing:"Mar–Apr", harvest:"Jun–Jul", crops:"Watermelon, Cucumber, Moong dal, Fodder crops",   color:"bg-amber-50"},
                        {season:"Annual", sowing:"Any",     harvest:"12–18m",  crops:"Sugarcane, Banana, Turmeric, Ginger",             color:"bg-purple-50"},
                      ].map(row => (
                        <tr key={row.season} className={`border-b border-[#f0ebe0] ${row.color}`}>
                          <td className="py-2 font-semibold">{row.season}</td>
                          <td className="py-2 font-mono">{row.sowing}</td>
                          <td className="py-2 font-mono">{row.harvest}</td>
                          <td className="py-2 text-[#7c5c32]">{row.crops}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function ForecastView() {
  const [selected, setSelected] = useState(0);
  const fc = forecasts[selected];

  return (
    <div className="max-w-5xl mx-auto">
      <div className="mb-8">
        <h2 className="text-3xl font-bold" style={{ fontFamily: "var(--font-display)" }}>AI Demand Forecasting</h2>
        <p className="text-[#7c5c32] mt-1">Continuously learning from real transaction data. Confidence range, not false certainty.</p>
      </div>

      <div className="flex gap-3 mb-8 flex-wrap">
        {forecasts.map((f, i) => (
          <button key={f.crop} onClick={() => setSelected(i)}
            className={`px-5 py-2.5 rounded-xl text-sm font-medium transition-colors border ${i === selected ? "bg-[#1e4d2b] text-white border-[#1e4d2b]" : "bg-white border-[#e8e3d8] text-[#7c5c32] hover:border-[#4a7c59]"}`}>
            {f.crop === "Onion" ? "🧅" : f.crop === "Potato" ? "🥔" : "🍅"} {f.crop} · {f.region}
          </button>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-5">
        {/* Main forecast card */}
        <div className="lg:col-span-2 bg-white border border-[#e8e3d8] rounded-2xl p-7">
          <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
            <div>
              <h3 className="text-xl font-bold" style={{ fontFamily: "var(--font-display)" }}>{fc.crop} — {fc.region}</h3>
              <p className="text-[#7c5c32] text-sm font-mono">Best window: {fc.bestWindow}</p>
            </div>
            <Badge label={fc.demand + " Demand"} variant={fc.demand === "Very High" ? "green" : fc.demand === "High" ? "wheat" : "gray"} />
          </div>

          {/* Price range visualization */}
          <div className="bg-[#f5f0e8] rounded-xl p-5 mb-5">
            <p className="text-xs font-mono text-[#7c5c32] uppercase tracking-wider mb-2">Predicted Price Range</p>
            <div className="flex items-end gap-4">
              <span className="text-4xl font-bold font-mono text-[#1e4d2b]">{fc.priceRange}</span>
              <span className="text-lg font-mono text-[#c8941a] font-semibold mb-1">{fc.trend} vs last fortnight</span>
            </div>
            <div className="mt-4 relative h-8">
              <div className="absolute inset-y-0 bg-[#d6f0de] rounded-full" style={{ left: "10%", right: "20%" }} />
              <div className="absolute inset-y-0 bg-[#1e4d2b] rounded-full opacity-80" style={{ left: "30%", right: "40%" }} />
              <div className="absolute top-9 left-[10%] text-xs font-mono text-[#7c5c32]">Low</div>
              <div className="absolute top-9 right-[20%] text-xs font-mono text-[#7c5c32]">High</div>
            </div>
          </div>

          {/* Confidence */}
          <div className="mb-5">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-mono text-[#7c5c32]">Model Confidence</span>
              <span className="text-sm font-bold font-mono text-[#1e4d2b]">{fc.confidence}%</span>
            </div>
            <ConfidenceBar value={fc.confidence} color={fc.confidence >= 85 ? "soil" : fc.confidence >= 70 ? "leaf" : "wheat"} />
            <p className="text-xs text-[#a77c3e] mt-2 font-mono">
              {fc.confidence >= 85 ? "High confidence — based on strong historical and real-time signals" :
               fc.confidence >= 70 ? "Moderate confidence — some uncertainty in external supply factors" :
               "Lower confidence — thin data in this region; use range conservatively"}
            </p>
          </div>

          <p className="text-sm text-[#1a1a0e] leading-relaxed border-l-4 border-[#c8941a] pl-4 bg-[#fef9ec] py-3 rounded-r-lg">
            🤖 <b>AI Insight:</b> {fc.insight}
          </p>
        </div>

        {/* Demand drivers */}
        <div className="space-y-4">
          <div className="bg-white border border-[#e8e3d8] rounded-2xl p-5">
            <h4 className="font-semibold text-[#1e4d2b] mb-4 text-sm font-mono uppercase tracking-wide">Demand Drivers</h4>
            <ul className="space-y-3">
              {fc.drivers.map((d) => (
                <li key={d} className="flex items-start gap-2 text-sm">
                  <span className="text-[#c8941a] mt-0.5 flex-shrink-0">▲</span>
                  <span className="text-[#1a1a0e]">{d}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-[#1e4d2b] text-white rounded-2xl p-5">
            <h4 className="font-semibold mb-3 text-sm font-mono uppercase tracking-wide text-[#c8dfc8]">Learning Loop</h4>
            <p className="text-sm text-[#c8dfc8] leading-relaxed">This forecast improves with every completed transaction. Currently trained on <span className="text-[#e8b535] font-mono font-semibold">8,214</span> real sales events in this region.</p>
          </div>

          <div className="bg-white border border-[#e8e3d8] rounded-2xl p-5">
            <h4 className="font-semibold text-[#1e4d2b] mb-3 text-sm font-mono uppercase tracking-wide">Bootstrap Note</h4>
            <p className="text-xs text-[#7c5c32] leading-relaxed">Where platform data is thin, we seed forecasts with AGMARKNET historical data + simulated market signals until real transactions provide sufficient density.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function MatchingView() {
  const [activeMatch, setActiveMatch] = useState<null | number>(null);

  return (
    <div className="max-w-5xl mx-auto">
      <div className="mb-8">
        <h2 className="text-3xl font-bold" style={{ fontFamily: "var(--font-display)" }}>Smart Supply-Demand Matching</h2>
        <p className="text-[#7c5c32] mt-1">AI-surfaced matches by quantity, price fit, distance, and quality grade</p>
      </div>

      <div className="bg-[#fef9ec] border border-[#e8b535] rounded-xl px-5 py-4 mb-6 flex items-center gap-3">
        <span className="text-xl">⚡</span>
        <p className="text-sm text-[#92400e]"><b>3 new matches</b> auto-detected in the last hour. No manual searching required.</p>
      </div>

      <div className="space-y-4">
        {matches.map((m, i) => {
          const br = BUYER_RATINGS[m.buyer];
          const escrowAmt = m.status==="ready" ? `₹${(parseFloat(m.supply)*parseFloat(m.price.replace("₹","").replace("/kg",""))).toLocaleString("en-IN")} locked` : null;
          return (
          <div key={m.id} className="bg-white border border-[#e8e3d8] rounded-2xl overflow-hidden hover:border-[#4a7c59] transition-colors">
            <div className="p-5">
              <div className="flex items-center gap-5 flex-wrap">
                <ScoreRing score={m.score} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap mb-2">
                    <span className="font-mono text-xs text-[#7c5c32]">{m.id}</span>
                    <Badge label={m.status==="ready"?"Ready to dispatch":"Awaiting verification"} variant={m.status==="ready"?"green":"amber"}/>
                    <Badge label={`Grade ${m.grade}`} variant="blue"/>
                    {escrowAmt && (
                      <span className="inline-flex items-center gap-1 text-[10px] font-mono font-semibold bg-blue-50 border border-blue-200 text-blue-700 px-2.5 py-0.5 rounded-full">
                        🔒 {escrowAmt} in escrow
                      </span>
                    )}
                  </div>
                  <div className="grid sm:grid-cols-2 gap-x-8 gap-y-1">
                    <div className="text-sm"><span className="text-[#7c5c32]">Supply: </span><span className="font-medium">{m.farmer} · {m.crop} · {m.supply}</span></div>
                    <div className="text-sm flex items-center gap-2">
                      <span className="text-[#7c5c32]">Buyer: </span>
                      <span className="font-medium">{m.buyer}</span>
                      {br && (
                        <span className="text-[10px] font-mono text-[#c8941a]">
                          ★ {br.rating} · {br.trades} trades
                        </span>
                      )}
                    </div>
                    <div className="text-sm"><span className="text-[#7c5c32]">Agreed price: </span><span className="font-semibold text-[#1e4d2b] font-mono">{m.price}</span></div>
                    <div className="text-sm"><span className="text-[#7c5c32]">Distance: </span><span className="font-medium font-mono">{m.distance}</span></div>
                  </div>
                </div>
                <div className="flex gap-2 flex-shrink-0">
                  <button onClick={() => setActiveMatch(activeMatch===i?null:i)}
                    className="text-sm px-4 py-2 rounded-lg border border-[#e8e3d8] text-[#7c5c32] hover:bg-[#f0ebe0] transition-colors">
                    {activeMatch===i?"Collapse":"Details"}
                  </button>
                  <button className="text-sm px-4 py-2 rounded-lg bg-[#1e4d2b] text-white hover:bg-[#2d6b3e] transition-colors">
                    Confirm Match
                  </button>
                </div>
              </div>
            </div>

            {activeMatch===i && (
              <div className="border-t border-[#e8e3d8] bg-[#f9f7f2] px-5 py-4 space-y-4">
                <div className="grid sm:grid-cols-3 gap-4 text-sm">
                  <div>
                    <p className="font-mono text-xs text-[#7c5c32] uppercase mb-1">Match Factors</p>
                    <ul className="space-y-1">
                      <li className="flex justify-between"><span>Quantity fit</span><span className="font-mono font-semibold text-[#1e4d2b]">✓ Exact</span></li>
                      <li className="flex justify-between"><span>Price within range</span><span className="font-mono font-semibold text-[#1e4d2b]">✓ Yes</span></li>
                      <li className="flex justify-between"><span>Distance score</span><span className="font-mono font-semibold text-[#c8941a]">Good</span></li>
                      <li className="flex justify-between"><span>Grade requirement</span><span className="font-mono font-semibold text-[#1e4d2b]">✓ Met</span></li>
                    </ul>
                  </div>
                  <div>
                    <p className="font-mono text-xs text-[#7c5c32] uppercase mb-2">Buyer Reputation</p>
                    {br ? (
                      <div className="space-y-1.5">
                        <div className="flex items-center gap-2">
                          <span className="text-[#c8941a] text-sm">{"★".repeat(Math.round(br.rating))}</span>
                          <span className="font-mono font-bold text-sm">{br.rating}</span>
                          <span className="text-xs text-[#7c5c32]">({br.trades} trades)</span>
                        </div>
                        <div className="text-xs text-[#7c5c32]">On-time payment: <b className="text-[#1e4d2b]">{br.onTime}%</b></div>
                        <div className="text-xs text-[#7c5c32]">Quality disputes: <b className="text-[#1e4d2b]">{100-br.quality}%</b></div>
                      </div>
                    ) : <p className="text-xs text-[#7c5c32]">No rating data yet</p>}
                  </div>
                  <div>
                    <p className="font-mono text-xs text-[#7c5c32] uppercase mb-1">Escrow Payment</p>
                    {m.status==="ready" ? (
                      <div className="space-y-1.5">
                        <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-blue-500"/><span className="text-xs font-semibold text-blue-700">Buyer payment locked</span></div>
                        <p className="text-xs text-[#7c5c32]">Funds held by platform. Released only after your delivery confirmation.</p>
                      </div>
                    ) : (
                      <p className="text-xs text-[#7c5c32]">Escrow activated upon match confirmation. Buyer locks funds before pickup.</p>
                    )}
                  </div>
                </div>

                {/* Cold storage fallback */}
                {m.status!=="ready" && (
                  <div className="bg-[#fef9ec] border border-[#e8b535] rounded-xl p-4">
                    <p className="text-xs font-mono text-[#92400e] uppercase tracking-wider mb-2">⚠ No immediate match — Cold Storage Options nearby</p>
                    <div className="grid sm:grid-cols-3 gap-2">
                      {COLD_STORES.slice(0,3).map(cs => (
                        <div key={cs.id} className="bg-white rounded-lg p-2.5 text-xs">
                          <p className="font-semibold text-[#1a1a0e]">{cs.name}</p>
                          <p className="text-[#7c5c32] font-mono">{cs.dist} · {cs.avail} free · {cs.cost}</p>
                          <div className="flex items-center gap-1 mt-1">
                            <span className="text-[#c8941a]">★</span><span className="font-mono">{cs.rating}</span>
                            {cs.accredited && <span className="text-[#1e4d2b] text-[9px] font-mono">· Accredited</span>}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── Buyer filter catalogue (stable outside component) ───────────────────────
const CROP_OPTIONS = ["All crops","Tomato","Onion","Potato","Wheat","Groundnut","Maize","Garlic","Sugarcane","Capsicum","Brinjal","Soybean"];
const DISTANCE_OPTIONS = [
  { label:"Any distance", km: Infinity },
  { label:"Within 50 km",  km: 50  },
  { label:"Within 100 km", km: 100 },
  { label:"Within 200 km", km: 200 },
  { label:"Same state",    km: 400 },
];
const SORT_OPTIONS = [
  { value:"ai",       label:"⚡ Best AI Match",      desc:"Ranked by your history" },
  { value:"nearest",  label:"📍 Nearest first",       desc:"Lowest transport cost"  },
  { value:"price",    label:"₹ Lowest price first",   desc:"Best unit economics"    },
  { value:"quality",  label:"🏆 Highest grade first", desc:"Premium produce"        },
  { value:"fresh",    label:"🌿 Freshest harvest",    desc:"Minimum spoilage risk"  },
];

// Catalogue of available produce listings (what a buyer browsing would see)
const PRODUCE_CATALOGUE = [
  { id:"L-001", crop:"Tomato",    grade:"A+", qty:6,   unit:"MT", price:42,  priceNote:"↑18% · Good vs regional avg", trend:"up",    farmer:"Kavitha M.",  fpo:"TN FPO Collective", location:"Namakkal, TN",  dist:62,   harvestDays:1, verified:true,  organic:false, fpoRating:4.8, bulkPool:false, aiScore:97, priceTrend:"stable",   trendLabel:"Stable price this week"            },
  { id:"L-002", crop:"Onion",     grade:"A",  qty:12,  unit:"MT", price:21,  priceNote:"↑8% · Above floor price",    trend:"up",    farmer:"Ramesh Patil",fpo:"Nashik FPO",         location:"Nashik, MH",    dist:148,  harvestDays:3, verified:true,  organic:false, fpoRating:4.5, bulkPool:true,  aiScore:89, priceTrend:"rising",   trendLabel:"Price likely rising next 3 days"   },
  { id:"L-003", crop:"Potato",    grade:"B",  qty:5,   unit:"MT", price:14,  priceNote:"↓3% · Below last week",      trend:"down",  farmer:"Sunita Devi", fpo:"Bihar FPO",          location:"Muzaffarpur, BR",dist:890,  harvestDays:5, verified:true,  organic:false, fpoRating:4.1, bulkPool:false, aiScore:76, priceTrend:"falling",  trendLabel:"Price likely to drop in 2 days"    },
  { id:"L-004", crop:"Groundnut", grade:"A",  qty:8,   unit:"MT", price:55,  priceNote:"↑5% · Fair market",         trend:"up",    farmer:"Dilip Savani",fpo:"Saurashtra FPO",     location:"Rajkot, GJ",    dist:220,  harvestDays:2, verified:true,  organic:true,  fpoRating:4.6, bulkPool:true,  aiScore:84, priceTrend:"stable",   trendLabel:"Stable — good time to buy"         },
  { id:"L-005", crop:"Wheat",     grade:"A+", qty:20,  unit:"MT", price:22,  priceNote:"↑12% · High demand",        trend:"up",    farmer:"Gurpreet S.", fpo:"Punjab FPO Pool",    location:"Ludhiana, PB",  dist:310,  harvestDays:8, verified:true,  organic:false, fpoRating:4.9, bulkPool:true,  aiScore:92, priceTrend:"rising",   trendLabel:"Strong demand — price rising fast"  },
  { id:"L-006", crop:"Maize",     grade:"B",  qty:15,  unit:"MT", price:18,  priceNote:"↑3% · Slight uptick",       trend:"up",    farmer:"Arun Sahu",   fpo:"MP Grain FPO",       location:"Hoshangabad, MP",dist:185,  harvestDays:4, verified:false, organic:false, fpoRating:3.8, bulkPool:true,  aiScore:71, priceTrend:"stable",   trendLabel:"Price stable this fortnight"        },
  { id:"L-007", crop:"Tomato",    grade:"A",  qty:4,   unit:"MT", price:39,  priceNote:"Competitive",               trend:"up",    farmer:"Meena V.",    fpo:"AP Veg FPO",         location:"Kurnool, AP",   dist:78,   harvestDays:1, verified:true,  organic:true,  fpoRating:4.4, bulkPool:false, aiScore:88, priceTrend:"stable",   trendLabel:"Good deal — 7% below district avg"  },
  { id:"L-008", crop:"Garlic",    grade:"A+", qty:2,   unit:"MT", price:68,  priceNote:"↑22% · Peak season",        trend:"up",    farmer:"Bhaskar Rao", fpo:"Rajasthan Spice FPO",location:"Barmer, RJ",    dist:540,  harvestDays:6, verified:true,  organic:false, fpoRating:4.3, bulkPool:false, aiScore:80, priceTrend:"rising",   trendLabel:"Seasonal peak — buy now"           },
];

function PriceTrendTag({ trend, label }: { trend: string; label: string }) {
  const cfg = {
    rising:  { bg:"bg-amber-50",  border:"border-amber-200", text:"text-amber-700",  icon:"📈" },
    falling: { bg:"bg-red-50",    border:"border-red-200",   text:"text-red-700",    icon:"📉" },
    stable:  { bg:"bg-[#d6f0de]", border:"border-[#b6dfca]", text:"text-[#1e4d2b]",  icon:"〰" },
  }[trend] ?? { bg:"bg-gray-50", border:"border-gray-200", text:"text-gray-600", icon:"—" };
  return (
    <span className={`inline-flex items-center gap-1 text-[10px] font-mono px-2 py-0.5 rounded-full border ${cfg.bg} ${cfg.border} ${cfg.text}`}>
      {cfg.icon} {label}
    </span>
  );
}

function RangeSlider({ min, max, value, onChange, prefix="" }: { min:number; max:number; value:[number,number]; onChange:(v:[number,number])=>void; prefix?:string }) {
  const pct = (v: number) => ((v - min) / (max - min)) * 100;
  return (
    <div className="space-y-2">
      <div className="flex justify-between text-xs font-mono text-[#7c5c32]">
        <span>{prefix}{value[0].toLocaleString()}</span>
        <span>{prefix}{value[1].toLocaleString()}</span>
      </div>
      <div className="relative h-4 flex items-center">
        <div className="absolute left-0 right-0 h-1.5 bg-[#e8e3d8] rounded-full"/>
        <div className="absolute h-1.5 rounded-full bg-[#1e4d2b]" style={{ left:`${pct(value[0])}%`, right:`${100-pct(value[1])}%` }}/>
        <input type="range" min={min} max={max} value={value[0]}
          onChange={e => onChange([Math.min(+e.target.value, value[1]-1), value[1]])}
          className="absolute w-full appearance-none bg-transparent cursor-pointer" style={{ height:16 }}/>
        <input type="range" min={min} max={max} value={value[1]}
          onChange={e => onChange([value[0], Math.max(+e.target.value, value[0]+1)])}
          className="absolute w-full appearance-none bg-transparent cursor-pointer" style={{ height:16 }}/>
      </div>
    </div>
  );
}

function BuyerView() {
  // ── filter state ──────────────────────────────────────────────────────────
  const [crop,        setCrop]        = useState("All crops");
  const [qtyRange,    setQtyRange]    = useState<[number,number]>([0.5, 25]);
  const [priceRange,  setPriceRange]  = useState<[number,number]>([10, 100]);
  const [distKm,      setDistKm]      = useState(Infinity);
  const [grade,       setGrade]       = useState("Any");
  const [verifiedOnly,setVerifiedOnly]= useState(false);
  const [organicOnly, setOrganicOnly] = useState(false);
  const [minRating,   setMinRating]   = useState(0);
  const [freshDays,   setFreshDays]   = useState(14);
  const [bulkOnly,    setBulkOnly]    = useState(false);
  const [sortBy,      setSortBy]      = useState("ai");
  const [moreOpen,    setMoreOpen]    = useState(false);
  const [showForm,    setShowForm]    = useState(false);
  const [activeCard,  setActiveCard]  = useState<string|null>(null);

  // ── active filter count (for badge) ──────────────────────────────────────
  const extrasActive = [
    distKm !== Infinity, grade !== "Any", verifiedOnly,
    organicOnly, minRating > 0, freshDays < 14, bulkOnly,
  ].filter(Boolean).length;

  // ── filter + sort engine ──────────────────────────────────────────────────
  const results = PRODUCE_CATALOGUE
    .filter(l => {
      if (crop !== "All crops" && l.crop !== crop) return false;
      if (l.qty < qtyRange[0] || l.qty > qtyRange[1]) return false;
      if (l.price < priceRange[0] || l.price > priceRange[1]) return false;
      if (distKm !== Infinity && l.dist > distKm) return false;
      if (grade !== "Any" && l.grade !== grade) return false;
      if (verifiedOnly && !l.verified) return false;
      if (organicOnly  && !l.organic)  return false;
      if (l.fpoRating < minRating)     return false;
      if (l.harvestDays > freshDays)   return false;
      if (bulkOnly && !l.bulkPool)     return false;
      return true;
    })
    .sort((a, b) => {
      if (sortBy === "ai")      return b.aiScore - a.aiScore;
      if (sortBy === "nearest") return a.dist - b.dist;
      if (sortBy === "price")   return a.price - b.price;
      if (sortBy === "quality") return (a.grade < b.grade ? -1 : 1);
      if (sortBy === "fresh")   return a.harvestDays - b.harvestDays;
      return 0;
    });

  function clearAll() {
    setCrop("All crops"); setQtyRange([0.5,25]); setPriceRange([10,100]);
    setDistKm(Infinity); setGrade("Any"); setVerifiedOnly(false);
    setOrganicOnly(false); setMinRating(0); setFreshDays(14);
    setBulkOnly(false); setSortBy("ai");
  }

  const gradeColor: Record<string,string> = {
    "A+":"bg-[#d6f0de] text-[#1e4d2b] border-[#b6dfca]",
    "A": "bg-blue-50 text-blue-700 border-blue-200",
    "B": "bg-amber-50 text-amber-700 border-amber-200",
    "C": "bg-gray-50 text-gray-600 border-gray-200",
  };

  return (
    <div className="max-w-6xl mx-auto">

      {/* ── Page header ── */}
      <div className="flex items-center justify-between mb-6 flex-wrap gap-4">
        <div>
          <h2 className="text-3xl font-bold" style={{ fontFamily:"var(--font-display)" }}>Buyer & Retailer Portal</h2>
          <p className="text-[#7c5c32] mt-1">Smart filtered produce discovery with AI-ranked matching</p>
        </div>
        <button onClick={()=>setShowForm(!showForm)}
          className="bg-[#c8941a] text-white px-5 py-2.5 rounded-xl font-semibold hover:bg-[#e8b535] transition-colors text-sm">
          + Post Requirement
        </button>
      </div>

      {/* ── Post requirement form ── */}
      {showForm && (
        <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6 mb-6 shadow-sm">
          <h3 className="font-semibold text-[#1e4d2b] mb-4">New Buyer Requirement</h3>
          <div className="grid sm:grid-cols-2 gap-4">
            {["Organisation Name","Crop Required","Quantity (MT)","Price Range (₹/kg)","Required By Date","Delivery Location"].map(label=>(
              <div key={label}>
                <label className="block text-sm text-[#7c5c32] mb-1.5 font-mono">{label}</label>
                <input className="w-full border border-[#e8e3d8] rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-[#1e4d2b]" placeholder={label}/>
              </div>
            ))}
          </div>
          <div className="flex gap-3 mt-4">
            <button className="bg-[#1e4d2b] text-white px-6 py-2.5 rounded-xl text-sm font-semibold hover:bg-[#2d6b3e] transition-colors">Submit</button>
            <button onClick={()=>setShowForm(false)} className="border border-[#e8e3d8] text-[#7c5c32] px-6 py-2.5 rounded-xl text-sm hover:bg-[#f0ebe0] transition-colors">Cancel</button>
          </div>
        </div>
      )}

      {/* ══════════════════════════ FILTER PANEL ══════════════════════════ */}
      <div className="bg-white border border-[#e8e3d8] rounded-2xl overflow-hidden mb-5 shadow-sm">

        {/* ── TOP BAR: 3 primary filters always visible ── */}
        <div className="p-4 border-b border-[#f0ebe0]">
          <div className="flex flex-wrap gap-3 items-end">

            {/* 1. Crop type */}
            <div className="flex-1 min-w-[160px]">
              <label className="block text-[10px] font-mono font-bold text-[#7c5c32] uppercase tracking-wider mb-1.5">Crop / Product</label>
              <div className="relative">
                <select value={crop} onChange={e=>setCrop(e.target.value)}
                  className="w-full appearance-none border border-[#e8e3d8] rounded-xl px-4 py-2.5 text-sm bg-white focus:outline-none focus:border-[#1e4d2b] pr-8 text-[#1a1a0e] font-medium">
                  {CROP_OPTIONS.map(c=><option key={c}>{c}</option>)}
                </select>
                <span className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-[#7c5c32] text-xs">▾</span>
              </div>
            </div>

            {/* 2. Quantity range */}
            <div className="flex-1 min-w-[200px]">
              <label className="block text-[10px] font-mono font-bold text-[#7c5c32] uppercase tracking-wider mb-1.5">
                Quantity (MT) — {qtyRange[0]}–{qtyRange[1]} MT
              </label>
              <RangeSlider min={0.5} max={25} value={qtyRange} onChange={setQtyRange}/>
            </div>

            {/* 3. Price range */}
            <div className="flex-1 min-w-[200px]">
              <label className="block text-[10px] font-mono font-bold text-[#7c5c32] uppercase tracking-wider mb-1.5">
                Price (₹/kg) — ₹{priceRange[0]}–₹{priceRange[1]}
              </label>
              <RangeSlider min={10} max={100} value={priceRange} onChange={setPriceRange} prefix="₹"/>
            </div>

            {/* More filters toggle */}
            <button onClick={()=>setMoreOpen(o=>!o)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold border transition-colors flex-shrink-0 ${moreOpen ? "bg-[#1e4d2b] text-white border-[#1e4d2b]" : "bg-[#f5f0e8] border-[#e8e3d8] text-[#7c5c32] hover:bg-[#ebe6da]"}`}>
              <svg width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <line x1="4" y1="6" x2="20" y2="6"/><line x1="8" y1="12" x2="16" y2="12"/><line x1="11" y1="18" x2="13" y2="18"/>
              </svg>
              More filters
              {extrasActive > 0 && (
                <span className="bg-[#c8941a] text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  {extrasActive}
                </span>
              )}
            </button>

            {/* Clear all */}
            {(crop !== "All crops" || qtyRange[0] > 0.5 || qtyRange[1] < 25 || priceRange[0] > 10 || priceRange[1] < 100 || extrasActive > 0) && (
              <button onClick={clearAll} className="text-xs font-mono text-[#7c5c32] hover:text-red-600 transition-colors flex-shrink-0 underline underline-offset-2">
                Clear all
              </button>
            )}
          </div>
        </div>

        {/* ── EXPANDED: Location, Quality, Freshness, Certification, Rating ── */}
        {moreOpen && (
          <div className="p-4 bg-[#faf9f6] border-b border-[#f0ebe0]">
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">

              {/* Location / Distance */}
              <div>
                <label className="block text-[10px] font-mono font-bold text-[#7c5c32] uppercase tracking-wider mb-2">📍 Location / Distance</label>
                <div className="grid grid-cols-2 gap-1.5">
                  {DISTANCE_OPTIONS.map(d=>(
                    <button key={d.label} onClick={()=>setDistKm(d.km)}
                      className={`text-xs px-3 py-2 rounded-lg border text-left transition-all ${distKm===d.km ? "bg-[#1e4d2b] text-white border-[#1e4d2b]" : "bg-white border-[#e8e3d8] text-[#7c5c32] hover:border-[#4a7c59]"}`}>
                      {d.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Quality grade */}
              <div>
                <label className="block text-[10px] font-mono font-bold text-[#7c5c32] uppercase tracking-wider mb-2">🏷️ Quality Grade</label>
                <div className="flex gap-2 flex-wrap">
                  {["Any","A+","A","B","C"].map(g=>(
                    <button key={g} onClick={()=>setGrade(g)}
                      className={`text-xs px-3.5 py-1.5 rounded-lg border font-mono font-semibold transition-all ${grade===g ? "bg-[#1e4d2b] text-white border-[#1e4d2b]" : "bg-white border-[#e8e3d8] text-[#7c5c32] hover:border-[#4a7c59]"}`}>
                      {g}
                    </button>
                  ))}
                </div>

                {/* Toggles */}
                <div className="mt-3 space-y-2">
                  {[
                    { label:"Verified stock only",  val:verifiedOnly, set:setVerifiedOnly, icon:"✅" },
                    { label:"Organic / certified",  val:organicOnly,  set:setOrganicOnly,  icon:"🌿" },
                    { label:"Bulk / pooled FPO only",val:bulkOnly,    set:setBulkOnly,     icon:"🤝" },
                  ].map(t=>(
                    <label key={t.label} className="flex items-center gap-2.5 cursor-pointer group">
                      <div onClick={()=>t.set(!t.val)}
                        className={`relative w-9 h-5 rounded-full border transition-all flex-shrink-0 cursor-pointer ${t.val ? "bg-[#1e4d2b] border-[#1e4d2b]" : "bg-white border-[#d0cbbf]"}`}>
                        <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-all ${t.val ? "left-4" : "left-0.5"}`}/>
                      </div>
                      <span className="text-xs text-[#7c5c32] group-hover:text-[#1e4d2b] transition-colors">{t.icon} {t.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Freshness + Rating */}
              <div className="space-y-4">
                <div>
                  <label className="block text-[10px] font-mono font-bold text-[#7c5c32] uppercase tracking-wider mb-2">
                    🌿 Harvest within — {freshDays === 14 ? "any time" : `${freshDays} days`}
                  </label>
                  <div className="flex gap-2">
                    {[1,2,3,5,14].map(d=>(
                      <button key={d} onClick={()=>setFreshDays(d)}
                        className={`text-xs px-2.5 py-1.5 rounded-lg border font-mono transition-all ${freshDays===d ? "bg-[#1e4d2b] text-white border-[#1e4d2b]" : "bg-white border-[#e8e3d8] text-[#7c5c32] hover:border-[#4a7c59]"}`}>
                        {d===14?"Any":`≤${d}d`}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-mono font-bold text-[#7c5c32] uppercase tracking-wider mb-2">
                    ⭐ Min FPO rating — {minRating === 0 ? "any" : `${minRating}+`}
                  </label>
                  <div className="flex gap-2">
                    {[0,3.5,4,4.5].map(r=>(
                      <button key={r} onClick={()=>setMinRating(r)}
                        className={`text-xs px-2.5 py-1.5 rounded-lg border font-mono transition-all ${minRating===r ? "bg-[#1e4d2b] text-white border-[#1e4d2b]" : "bg-white border-[#e8e3d8] text-[#7c5c32] hover:border-[#4a7c59]"}`}>
                        {r===0?"Any":`★${r}`}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ── SORT BAR + result count ── */}
        <div className="px-4 py-3 flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold text-[#1a1a0e]">{results.length}</span>
            <span className="text-sm text-[#7c5c32]">listing{results.length!==1?"s":""} found</span>
            {sortBy === "ai" && (
              <span className="text-[10px] font-mono bg-[#d6f0de] text-[#1e4d2b] border border-[#b6dfca] px-2 py-0.5 rounded-full">⚡ AI ranked</span>
            )}
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[10px] font-mono text-[#7c5c32] uppercase tracking-wider">Sort:</span>
            <div className="flex gap-1.5">
              {SORT_OPTIONS.map(o=>(
                <button key={o.value} onClick={()=>setSortBy(o.value)} title={o.desc}
                  className={`text-xs px-3 py-1.5 rounded-lg font-medium transition-all border ${sortBy===o.value ? "bg-[#1e4d2b] text-white border-[#1e4d2b]" : "bg-[#f5f0e8] border-[#e8e3d8] text-[#7c5c32] hover:bg-[#ebe6da]"}`}>
                  {o.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* ══════════════════════════ RESULTS ══════════════════════════════ */}
      {results.length === 0 ? (
        <div className="bg-white border border-[#e8e3d8] rounded-2xl p-12 text-center">
          <div className="text-4xl mb-4">🔍</div>
          <p className="font-semibold text-[#1a1a0e] mb-2">No listings match your filters</p>
          <p className="text-sm text-[#7c5c32] mb-5">Try relaxing the quantity, price, or distance filters.</p>
          <button onClick={clearAll} className="bg-[#1e4d2b] text-white px-6 py-2.5 rounded-xl text-sm font-semibold hover:bg-[#2d6b3e] transition-colors">Clear all filters</button>
        </div>
      ) : (
        <div className="space-y-3">
          {results.map((l, i) => {
            const isActive = activeCard === l.id;
            const isTop = sortBy === "ai" && i === 0;
            return (
              <div key={l.id}
                className="bg-white border rounded-2xl overflow-hidden transition-all duration-200 hover:shadow-md cursor-pointer"
                style={{ borderColor: isActive ? "#4a7c59" : isTop ? "#c8941a40" : "#e8e3d8" }}
                onClick={()=>setActiveCard(isActive ? null : l.id)}>

                {/* Top badge for AI best match */}
                {isTop && sortBy === "ai" && (
                  <div className="px-5 py-1.5 text-[10px] font-mono font-bold tracking-widest" style={{ background:"linear-gradient(90deg,#c8941a10,#e8b53520)", color:"#c8941a", borderBottom:"1px solid #e8b53540" }}>
                    ⚡ AI BEST MATCH FOR YOU · Score {l.aiScore}/100
                  </div>
                )}

                <div className="p-5">
                  <div className="flex items-start gap-4 flex-wrap">

                    {/* Crop icon + AI score ring */}
                    <div className="relative flex-shrink-0">
                      <div className="w-13 h-13 rounded-2xl bg-[#f5f0e8] flex items-center justify-center text-2xl w-14 h-14">
                        {l.crop==="Tomato"?"🍅":l.crop==="Onion"?"🧅":l.crop==="Potato"?"🥔":l.crop==="Wheat"?"🌾":l.crop==="Groundnut"?"🥜":l.crop==="Maize"?"🌽":l.crop==="Garlic"?"🧄":"🌱"}
                      </div>
                      {sortBy === "ai" && (
                        <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-[#1e4d2b] flex items-center justify-center">
                          <span className="text-[8px] font-mono font-bold text-white">{l.aiScore}</span>
                        </div>
                      )}
                    </div>

                    {/* Main info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1.5">
                        <span className="font-bold text-[#1a1a0e]">{l.crop}</span>
                        <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${gradeColor[l.grade]??""}`}>Grade {l.grade}</span>
                        {l.verified && <span className="text-[10px] font-mono bg-[#d6f0de] text-[#1e4d2b] border border-[#b6dfca] px-2 py-0.5 rounded-full">✅ Verified</span>}
                        {l.organic  && <span className="text-[10px] font-mono bg-green-50 text-green-700 border border-green-200 px-2 py-0.5 rounded-full">🌿 Organic</span>}
                        {l.bulkPool && <span className="text-[10px] font-mono bg-purple-50 text-purple-700 border border-purple-200 px-2 py-0.5 rounded-full">🤝 FPO Pool</span>}
                      </div>

                      <div className="flex flex-wrap gap-x-5 gap-y-1 text-sm text-[#7c5c32] mb-2">
                        <span>👤 <b className="text-[#1a1a0e]">{l.farmer}</b> · {l.fpo}</span>
                        <span>📦 <b className="text-[#1a1a0e]">{l.qty} MT</b> available</span>
                        <span>📍 {l.location} · <span className="font-mono">{l.dist} km</span></span>
                        <span>🌿 Harvested <b>{l.harvestDays === 1 ? "today" : `${l.harvestDays}d ago`}</b></span>
                      </div>

                      <div className="flex items-center gap-3 flex-wrap">
                        <PriceTrendTag trend={l.priceTrend} label={l.trendLabel}/>
                        <span className="text-[10px] font-mono text-[#7c5c32]">★ {l.fpoRating} FPO rating</span>
                        <span className="text-[10px] font-mono text-[#7c5c32] bg-[#f5f0e8] px-2 py-0.5 rounded-full">{l.priceNote}</span>
                      </div>
                    </div>

                    {/* Price + CTA */}
                    <div className="flex flex-col items-end gap-2 flex-shrink-0">
                      <div className="text-right">
                        <div className="text-2xl font-bold font-mono text-[#1e4d2b]">₹{l.price}<span className="text-sm font-normal text-[#7c5c32]">/kg</span></div>
                        <div className="text-xs font-mono text-[#7c5c32]">≈ ₹{(l.price * l.qty * 1000).toLocaleString("en-IN")} total</div>
                      </div>
                      <button className="bg-[#1e4d2b] text-white px-5 py-2 rounded-xl text-sm font-semibold hover:bg-[#2d6b3e] transition-colors">
                        Request Match
                      </button>
                    </div>
                  </div>

                  {/* Expanded detail row */}
                  {isActive && (
                    <div className="mt-4 pt-4 border-t border-[#f0ebe0] grid sm:grid-cols-3 gap-4 text-sm">
                      <div>
                        <p className="text-[10px] font-mono text-[#7c5c32] uppercase tracking-wider mb-2">AI Match Factors</p>
                        <ul className="space-y-1 text-xs">
                          {[
                            ["Quantity fit",    "✓ Exact"],
                            ["Price in range",  "✓ Yes"],
                            ["Grade match",     "✓ Met"],
                            ["Distance score",  l.dist < 100 ? "✓ Near" : l.dist < 300 ? "Good" : "Far"],
                            ["FPO trust score", l.fpoRating >= 4.5 ? "High" : l.fpoRating >= 4 ? "Good" : "Moderate"],
                          ].map(([k,v])=>(
                            <li key={k} className="flex justify-between">
                              <span className="text-[#7c5c32]">{k}</span>
                              <span className={`font-mono font-semibold ${v.startsWith("✓") ? "text-[#1e4d2b]" : "text-[#c8941a]"}`}>{v}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <p className="text-[10px] font-mono text-[#7c5c32] uppercase tracking-wider mb-2">Price Intelligence</p>
                        <PriceTrendTag trend={l.priceTrend} label={l.trendLabel}/>
                        <p className="text-xs text-[#7c5c32] mt-2 leading-relaxed">Our forecasting engine tracks {l.crop} prices across 1,000+ mandis in real time.</p>
                      </div>
                      <div>
                        <p className="text-[10px] font-mono text-[#7c5c32] uppercase tracking-wider mb-2">Next Steps</p>
                        <ol className="text-xs text-[#1a1a0e] space-y-1 list-decimal list-inside">
                          <li>Request match — escrow activated</li>
                          <li>FPO confirms stock within 2h</li>
                          <li>Logistics route generated</li>
                          <li>Pickup scheduled within 24h</li>
                        </ol>
                        <button className="mt-3 w-full bg-[#c8941a] text-white py-2 rounded-xl text-xs font-semibold hover:bg-[#e8b535] transition-colors">
                          🔒 Lock in with Escrow →
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ── Existing requirements ── */}
      {buyerRequirements.length > 0 && (
        <div className="mt-8">
          <h3 className="font-semibold text-[#1a1a0e] mb-4" style={{ fontFamily:"var(--font-display)" }}>Your Posted Requirements</h3>
          <div className="space-y-3">
            {buyerRequirements.map(r=>(
              <div key={r.id} className="bg-[#f9f7f2] border border-[#e8e3d8] rounded-2xl p-5 flex items-center gap-4 flex-wrap">
                <div className="w-10 h-10 rounded-xl bg-[#fef9ec] border border-[#e8b535] flex items-center justify-center text-lg flex-shrink-0">🏪</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <span className="font-semibold text-sm">{r.buyer}</span>
                    <span className="font-mono text-xs text-[#7c5c32]">{r.id}</span>
                    {r.verified && <Badge label="Verified Buyer" variant="green"/>}
                  </div>
                  <div className="flex flex-wrap gap-x-5 gap-y-0.5 text-xs text-[#7c5c32]">
                    <span>🌾 {r.crop}</span><span>📦 {r.qty}</span><span>💰 {r.priceRange}</span><span>📅 {r.timing}</span><span>📍 {r.location}</span>
                  </div>
                </div>
                <button className={`text-sm px-4 py-2 rounded-xl transition-colors font-semibold ${r.matches > 0 ? "bg-[#1e4d2b] text-white" : "bg-[#e8e3d8] text-[#7c5c32]"}`}>
                  {r.matches > 0 ? `View ${r.matches} matches` : "No matches yet"}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Logistics Dashboard ──────────────────────────────────────────────────────


// ─── Real geo hub data ────────────────────────────────────────────────────────
interface GeoHub { id: string; lat: number; lng: number; name: string; city: string; type: string; }

const GEO_HUBS: GeoHub[] = [
  { id: "indore",      lat: 22.7196, lng: 75.8577, name: "Indore APMC",       city: "Indore",      type: "mandi" },
  { id: "bhopal",      lat: 23.2599, lng: 77.4126, name: "Bhopal DC",         city: "Bhopal",      type: "dc"    },
  { id: "ujjain",      lat: 23.1765, lng: 75.7885, name: "Ujjain DC",         city: "Ujjain",      type: "dc"    },
  { id: "dewas",       lat: 22.9676, lng: 76.0534, name: "Dewas Hub",         city: "Dewas",       type: "hub"   },
  { id: "sehore",      lat: 23.2002, lng: 77.0852, name: "Sehore Mandi",      city: "Sehore",      type: "mandi" },
  { id: "mandsaur",    lat: 24.0767, lng: 75.0696, name: "Mandsaur DC",       city: "Mandsaur",    type: "dc"    },
  { id: "ratlam",      lat: 23.3315, lng: 75.0367, name: "Ratlam Cluster",    city: "Ratlam",      type: "hub"   },
  { id: "hoshangabad", lat: 22.7534, lng: 77.7260, name: "Hoshangabad Mandi", city: "Hoshangabad", type: "mandi" },
  { id: "vidisha",     lat: 23.5257, lng: 77.8157, name: "Vidisha Farms",     city: "Vidisha",     type: "hub"   },
  { id: "raisen",      lat: 23.3311, lng: 77.7939, name: "Raisen Hub",        city: "Raisen",      type: "hub"   },
];

interface LiveRoute {
  id: string; fromId: string; toId: string; status: "in-transit" | "optimized" | "pending";
  cargo: string; eta: string; driver: string; truck: string;
  distance?: string; duration?: string;
  polyline?: [number, number][];
  progress?: number;
}

// Keep backward-compat alias for chatbot and other sections
const MP_HUBS = GEO_HUBS.map(h => ({ ...h, x: 0, y: 0 }));

let LIVE_ROUTES: LiveRoute[] = [
  { id:"RT-900", fromId:"sehore",      toId:"indore",   status:"in-transit", cargo:"4.2 T Tomato",  eta:"11:45 AM", driver:"Ravi Sharma",   truck:"MP-09-BT-4521", distance:"78 km",  duration:"1h 22m", progress:0.62 },
  { id:"RT-905", fromId:"dewas",       toId:"ujjain",   status:"optimized",  cargo:"2.8 T Onion",   eta:"02:15 PM", driver:"Anil Patel",    truck:"MP-15-CX-2234", distance:"36 km",  duration:"48m",    progress:0    },
  { id:"RT-813", fromId:"vidisha",     toId:"bhopal",   status:"optimized",  cargo:"5.1 T Wheat",   eta:"D+4",      driver:"Suresh Kumar",  truck:"MP-04-AX-8812", distance:"58 km",  duration:"1h 5m",  progress:0    },
  { id:"RT-889", fromId:"ratlam",      toId:"mandsaur", status:"in-transit", cargo:"1.2 T Garlic",  eta:"10:15 AM", driver:"Rakesh Yadav",  truck:"MP-09-KL-3318", distance:"124 km", duration:"2h 18m", progress:0.38 },
  { id:"RT-723", fromId:"raisen",      toId:"indore",   status:"pending",    cargo:"3.0 T Soybean", eta:"Next Day", driver:"Dinesh Tomar",  truck:"MP-11-BT-6640", distance:"165 km", duration:"3h 10m", progress:0    },
  { id:"RT-922", fromId:"hoshangabad", toId:"bhopal",   status:"optimized",  cargo:"6.1 T Rice",    eta:"Tomorrow", driver:"Arvind Singh",  truck:"MP-22-GH-1122", distance:"92 km",  duration:"1h 48m", progress:0    },
];

// Persist user-generated routes
try {
  const saved = localStorage.getItem("ks_routes");
  if (saved) { const parsed = JSON.parse(saved) as LiveRoute[]; parsed.forEach(r => { if (!LIVE_ROUTES.find(x=>x.id===r.id)) LIVE_ROUTES.push(r); }); }
} catch {}

const STATUS_CFG: Record<string, { label: string; dot: string; badge: string; text: string }> = {
  "in-transit": { label:"In Transit",  dot:"#22c55e", badge:"bg-green-50 border border-green-200",  text:"text-green-700" },
  "optimized":  { label:"Optimized",   dot:"#4a7c59", badge:"bg-[#edf7f1] border border-[#b6dfca]", text:"text-[#1e4d2b]" },
  "pending":    { label:"Pending",     dot:"#9ca3af", badge:"bg-gray-50 border border-gray-200",    text:"text-gray-500"  },
};

function getHub(id: string) { return GEO_HUBS.find(h => h.id === id) ?? GEO_HUBS[0]; }

// ─── OSRM routing ─────────────────────────────────────────────────────────────
interface OSRMResult { polyline: [number,number][]; distance: string; duration: string; steps: string[]; }

async function fetchOSRMRoute(from: GeoHub, to: GeoHub): Promise<OSRMResult | null> {
  try {
    const url = `https://router.project-osrm.org/route/v1/driving/${from.lng},${from.lat};${to.lng},${to.lat}?overview=full&geometries=geojson&steps=true`;
    const r = await fetch(url, { signal: AbortSignal.timeout(8000) });
    if (!r.ok) return null;
    const d = await r.json();
    if (!d.routes || !d.routes[0]) return null;
    const route = d.routes[0];
    const polyline = (route.geometry.coordinates as [number,number][]).map(([lng,lat]) => [lat, lng] as [number,number]);
    const distance = (route.distance / 1000).toFixed(1) + " km";
    const mins = Math.round(route.duration / 60);
    const duration = mins >= 60 ? `${Math.floor(mins/60)}h ${mins%60}m` : `${mins}m`;
    const steps: string[] = [];
    if (route.legs?.[0]?.steps) {
      for (const step of route.legs[0].steps.slice(0, 6)) {
        if (step.maneuver?.instruction || step.name) steps.push(step.maneuver?.instruction || ("Via " + step.name));
      }
    }
    return { polyline, distance, duration, steps };
  } catch { return null; }
}

// ─── Custom Leaflet markers ───────────────────────────────────────────────────
function makeHubIcon(color: string, size = 32) {
  return L.divIcon({
    className: "",
    html: `<div style="width:${size}px;height:${size}px;display:flex;align-items:center;justify-content:center">
      <svg width="${size}" height="${size+8}" viewBox="0 0 32 40" xmlns="http://www.w3.org/2000/svg">
        <path d="M16 0C7.16 0 0 7.16 0 16c0 12 16 24 16 24S32 28 32 16C32 7.16 24.84 0 16 0z" fill="${color}" filter="drop-shadow(0 2px 4px rgba(0,0,0,0.35))"/>
        <circle cx="16" cy="16" r="7" fill="white"/>
        <circle cx="16" cy="16" r="4" fill="${color}"/>
      </svg></div>`,
    iconSize: [size, size+8],
    iconAnchor: [size/2, size+8],
    popupAnchor: [0, -(size+8)],
  });
}

function makeTruckIcon(angle: number) {
  return L.divIcon({
    className: "",
    html: `<div style="transform:rotate(${angle}deg);font-size:26px;filter:drop-shadow(0 2px 6px rgba(0,0,0,0.5));line-height:1">🚛</div>`,
    iconSize: [32, 32],
    iconAnchor: [16, 16],
  });
}

function makeUserIcon() {
  return L.divIcon({
    className: "",
    html: `<div style="width:22px;height:22px;border-radius:50%;background:#4285f4;border:3px solid white;box-shadow:0 2px 8px rgba(66,133,244,0.6)">
      <div style="position:absolute;inset:-8px;border-radius:50%;background:rgba(66,133,244,0.15);animation:pulse 2s infinite"></div>
    </div>`,
    iconSize: [22, 22],
    iconAnchor: [11, 11],
  });
}

// ─── Interpolate position along polyline ─────────────────────────────────────
function interpolatePolyline(poly: [number,number][], t: number): [number, number] {
  if (!poly.length) return [22.7196, 75.8577];
  if (t <= 0) return poly[0];
  if (t >= 1) return poly[poly.length-1];
  let total = 0;
  const segs: number[] = [];
  for (let i = 1; i < poly.length; i++) {
    const d = Math.hypot(poly[i][0]-poly[i-1][0], poly[i][1]-poly[i-1][1]);
    segs.push(d); total += d;
  }
  let target = t * total, acc = 0;
  for (let i = 0; i < segs.length; i++) {
    if (acc + segs[i] >= target) {
      const frac = (target - acc) / segs[i];
      return [poly[i][0] + (poly[i+1][0]-poly[i][0])*frac, poly[i][1] + (poly[i+1][1]-poly[i][1])*frac];
    }
    acc += segs[i];
  }
  return poly[poly.length-1];
}

function truckAngle(poly: [number,number][], t: number): number {
  const p1 = interpolatePolyline(poly, Math.max(0, t-0.01));
  const p2 = interpolatePolyline(poly, Math.min(1, t+0.01));
  return Math.atan2(p2[1]-p1[1], p2[0]-p1[0]) * 180 / Math.PI - 90;
}

// ─── Map child components ─────────────────────────────────────────────────────
function MapRecenter({ lat, lng }: { lat: number; lng: number }) {
  const map = useMap();
  useEffect(() => { map.flyTo([lat, lng], map.getZoom(), { duration: 1.2 }); }, [lat, lng, map]);
  return null;
}

function LocationMarker({ onLocate }: { onLocate: (pos:[number,number])=>void }) {
  const [pos, setPos] = useState<[number,number]|null>(null);
  useMapEvents({
    locationfound(e) { const p:[number,number] = [e.latlng.lat, e.latlng.lng]; setPos(p); onLocate(p); },
  });
  return pos ? <Marker position={pos} icon={makeUserIcon()}><Popup>Your location</Popup></Marker> : null;
}

// ─── Main logistics map ───────────────────────────────────────────────────────
interface LiveMapProps {
  routes: LiveRoute[];
  selectedId: string;
  onSelectRoute: (id: string) => void;
  mapStyle: "streets" | "satellite";
  routePolylines: Record<string, [number,number][]>;
  truckPositions: Record<string, { pos: [number,number]; angle: number }>;
  userPos: [number,number] | null;
  centerOnRoute: { lat: number; lng: number } | null;
}

function LiveMap({ routes, selectedId, onSelectRoute, mapStyle, routePolylines, truckPositions, userPos, centerOnRoute }: LiveMapProps) {
  const mapRef = useRef<L.Map|null>(null);
  const centerIndia: [number, number] = [22.9, 76.8];

  return (
    <MapContainer
      center={centerIndia}
      zoom={8}
      style={{ width:"100%", height:"100%" }}
      ref={mapRef}
      zoomControl={false}
    >
      {/* Tile layers */}
      {mapStyle === "streets" ? (
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://osm.org">OpenStreetMap</a>'
          maxZoom={19}
        />
      ) : (
        <>
          <TileLayer
            url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
            attribution="Tiles &copy; Esri &mdash; Source: Esri, DigitalGlobe, GeoEye, Earthstar Geographics"
            maxZoom={19}
          />
          <TileLayer
            url="https://services.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}"
            attribution=""
            maxZoom={19}
          />
        </>
      )}

      {/* Route polylines */}
      {routes.map(r => {
        const poly = routePolylines[r.id];
        if (!poly || poly.length < 2) {
          const from = getHub(r.fromId); const to = getHub(r.toId);
          return <Polyline key={r.id} positions={[[from.lat,from.lng],[to.lat,to.lng]]}
            pathOptions={{ color: r.id===selectedId?"#1a73e8":r.status==="in-transit"?"#34a853":"#9aa0a6", weight: r.id===selectedId?6:3, opacity: r.id===selectedId?1:0.55, dashArray: r.status==="pending"?"8,6":undefined }}
            eventHandlers={{ click: ()=>onSelectRoute(r.id) }}/>;
        }
        return (
          <React.Fragment key={r.id}>
            <Polyline positions={poly}
              pathOptions={{ color:"white", weight: r.id===selectedId?12:6, opacity:0.7 }}
              eventHandlers={{ click: ()=>onSelectRoute(r.id) }}/>
            <Polyline positions={poly}
              pathOptions={{ color: r.id===selectedId?"#1a73e8":r.status==="in-transit"?"#34a853":"#9aa0a6", weight: r.id===selectedId?8:4, opacity: r.id===selectedId?1:0.6 }}
              eventHandlers={{ click: ()=>onSelectRoute(r.id) }}/>
          </React.Fragment>
        );
      })}

      {/* Hub markers */}
      {GEO_HUBS.map(h => {
        const isFrom = routes.find(r=>r.id===selectedId)?.fromId===h.id;
        const isTo   = routes.find(r=>r.id===selectedId)?.toId===h.id;
        const color  = isFrom?"#ea4335":isTo?"#1a73e8":"#5f6368";
        return (
          <Marker key={h.id} position={[h.lat, h.lng]} icon={makeHubIcon(color, isFrom||isTo?36:26)}>
            <Popup><b>{h.name}</b><br/>{h.city} &bull; {h.type}</Popup>
          </Marker>
        );
      })}

      {/* Truck icons on in-transit routes */}
      {routes.filter(r=>r.status==="in-transit").map(r => {
        const tp = truckPositions[r.id];
        if (!tp) return null;
        return (
          <Marker key={"truck-"+r.id} position={tp.pos} icon={makeTruckIcon(tp.angle)}>
            <Popup><b>{r.id}</b><br/>{r.cargo}<br/>Driver: {r.driver}</Popup>
          </Marker>
        );
      })}

      {/* User location */}
      {userPos && <Marker position={userPos} icon={makeUserIcon()}><Popup>Your location</Popup></Marker>}

      {centerOnRoute && <MapRecenter lat={centerOnRoute.lat} lng={centerOnRoute.lng}/>}
    </MapContainer>
  );
}

// ─── Route Planner Modal ──────────────────────────────────────────────────────
interface RoutePlannerProps {
  onClose: () => void;
  onRouteCreated: (r: LiveRoute) => void;
}
function RoutePlanner({ onClose, onRouteCreated }: RoutePlannerProps) {
  const [fromId, setFromId] = useState("sehore");
  const [toId,   setToId]   = useState("indore");
  const [cargo,  setCargo]  = useState("Tomato");
  const [weight, setWeight] = useState("2.0");
  const [driver, setDriver] = useState("");
  const [truck,  setTruck]  = useState("");
  const [loading, setLoading] = useState(false);
  const [preview, setPreview] = useState<OSRMResult|null>(null);
  const [error, setError] = useState("");

  async function handlePreview() {
    if (fromId === toId) { setError("Source and destination must differ."); return; }
    setLoading(true); setError(""); setPreview(null);
    const result = await fetchOSRMRoute(getHub(fromId), getHub(toId));
    setLoading(false);
    if (result) setPreview(result);
    else setError("Could not fetch route from OSRM. Check your connection.");
  }

  function handleCreate() {
    if (!preview) return;
    const id = "RT-" + (900 + Math.floor(Math.random()*900));
    const route: LiveRoute = {
      id, fromId, toId, status: "optimized",
      cargo: `${weight} T ${cargo}`,
      eta: "Scheduled",
      driver: driver || "TBD",
      truck: truck || "MP-XX-XX-XXXX",
      distance: preview.distance,
      duration: preview.duration,
      polyline: preview.polyline,
      progress: 0,
    };
    LIVE_ROUTES = [...LIVE_ROUTES, route];
    try { localStorage.setItem("ks_routes", JSON.stringify(LIVE_ROUTES.slice(6))); } catch {}
    onRouteCreated(route);
    onClose();
  }

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4" style={{ background:"rgba(0,0,0,0.5)" }} onClick={onClose}>
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden" onClick={e=>e.stopPropagation()}>
        <div className="px-6 py-5 flex items-center justify-between" style={{ background:"linear-gradient(135deg,#1e4d2b,#2a5e35)" }}>
          <div>
            <p className="text-sm font-bold text-white">&#128640; Generate New Route</p>
            <p className="text-xs text-white/60 mt-0.5">OSRM real-road routing &bull; Madhya Pradesh</p>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors">&#10005;</button>
        </div>

        <div className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-mono text-[#7c5c32] uppercase tracking-wider mb-1 block">From Hub</label>
              <select value={fromId} onChange={e=>setFromId(e.target.value)}
                className="w-full border border-[#e8e3d8] rounded-xl px-3 py-2.5 text-sm text-[#1a1a0e] focus:outline-none focus:border-[#4a7c59]">
                {GEO_HUBS.map(h=><option key={h.id} value={h.id}>{h.name}</option>)}
              </select>
            </div>
            <div>
              <label className="text-[10px] font-mono text-[#7c5c32] uppercase tracking-wider mb-1 block">To Hub</label>
              <select value={toId} onChange={e=>setToId(e.target.value)}
                className="w-full border border-[#e8e3d8] rounded-xl px-3 py-2.5 text-sm text-[#1a1a0e] focus:outline-none focus:border-[#4a7c59]">
                {GEO_HUBS.map(h=><option key={h.id} value={h.id}>{h.name}</option>)}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-mono text-[#7c5c32] uppercase tracking-wider mb-1 block">Cargo Type</label>
              <select value={cargo} onChange={e=>setCargo(e.target.value)}
                className="w-full border border-[#e8e3d8] rounded-xl px-3 py-2.5 text-sm text-[#1a1a0e] focus:outline-none focus:border-[#4a7c59]">
                {["Tomato","Onion","Wheat","Soybean","Rice","Garlic","Cotton","Maize","Chilli","Turmeric"].map(c=><option key={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="text-[10px] font-mono text-[#7c5c32] uppercase tracking-wider mb-1 block">Weight (MT)</label>
              <input value={weight} onChange={e=>setWeight(e.target.value)} type="number" min="0.5" max="20" step="0.5"
                className="w-full border border-[#e8e3d8] rounded-xl px-3 py-2.5 text-sm text-[#1a1a0e] focus:outline-none focus:border-[#4a7c59]"/>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-mono text-[#7c5c32] uppercase tracking-wider mb-1 block">Driver Name</label>
              <input value={driver} onChange={e=>setDriver(e.target.value)} placeholder="e.g. Ramesh Yadav"
                className="w-full border border-[#e8e3d8] rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-[#4a7c59] placeholder:text-[#c8b898]"/>
            </div>
            <div>
              <label className="text-[10px] font-mono text-[#7c5c32] uppercase tracking-wider mb-1 block">Truck Number</label>
              <input value={truck} onChange={e=>setTruck(e.target.value)} placeholder="e.g. MP-09-AB-1234"
                className="w-full border border-[#e8e3d8] rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-[#4a7c59] placeholder:text-[#c8b898]"/>
            </div>
          </div>

          {error && <p className="text-xs text-red-600 bg-red-50 rounded-xl px-4 py-2.5">{error}</p>}

          {preview && (
            <div className="bg-[#f0faf4] border border-[#b6dfca] rounded-2xl p-4 space-y-2">
              <p className="text-xs font-bold text-[#1e4d2b]">&#10003; Route calculated via OSRM</p>
              <div className="grid grid-cols-3 gap-2 text-center">
                {[{label:"Distance",value:preview.distance},{label:"Duration",value:preview.duration},{label:"Road Pts",value:preview.polyline.length+""}].map(s=>(
                  <div key={s.label} className="bg-white rounded-xl p-2">
                    <p className="text-xs font-bold font-mono text-[#1a1a0e]">{s.value}</p>
                    <p className="text-[9px] text-[#7c5c32]">{s.label}</p>
                  </div>
                ))}
              </div>
              {preview.steps.length > 0 && (
                <div className="text-[10px] text-[#7c5c32] space-y-0.5 max-h-24 overflow-y-auto">
                  {preview.steps.map((s,i)=><p key={i} className="flex gap-1"><span className="text-[#1e4d2b] font-bold">{i+1}.</span>{s}</p>)}
                </div>
              )}
            </div>
          )}
        </div>

        <div className="px-6 pb-6 flex gap-3">
          <button onClick={handlePreview} disabled={loading}
            className="flex-1 py-3 rounded-2xl border-2 border-[#1e4d2b] text-[#1e4d2b] text-sm font-bold hover:bg-[#d6f0de] transition-colors disabled:opacity-50">
            {loading ? "Calculating…" : "&#128507; Calculate Route"}
          </button>
          <button onClick={handleCreate} disabled={!preview}
            className="flex-1 py-3 rounded-2xl text-white text-sm font-bold transition-colors disabled:opacity-40"
            style={{ background: preview?"linear-gradient(135deg,#1e4d2b,#2d6b3e)":"#e8e3d8" }}>
            &#10003; Create Route
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── LogisticsView ────────────────────────────────────────────────────────────
function LogisticsView() {
  const [routes, setRoutes] = useState<LiveRoute[]>(LIVE_ROUTES);
  const [selectedId, setSelectedId] = useState("RT-900");
  const [mapStyle, setMapStyle] = useState<"streets"|"satellite">("streets");
  const [routeFilter, setRouteFilter] = useState<"all"|"optimized"|"in-transit"|"pending">("all");
  const [showPlanner, setShowPlanner] = useState(false);
  const [routePolylines, setRoutePolylines] = useState<Record<string,[number,number][]>>({});
  const [routeMeta, setRouteMeta] = useState<Record<string,{distance:string;duration:string;steps:string[]}>>({});
  const [truckPositions, setTruckPositions] = useState<Record<string,{pos:[number,number];angle:number}>>({});
  const [userPos, setUserPos] = useState<[number,number]|null>(null);
  const [locating, setLocating] = useState(false);
  const [fetchingRoute, setFetchingRoute] = useState(false);
  const [centerOn, setCenterOn] = useState<{lat:number;lng:number}|null>(null);
  const [osrmInfo, setOsrmInfo] = useState<{steps:string[]}|null>(null);
  const truckTimerRef = useRef<ReturnType<typeof setInterval>|null>(null);
  const progressRef = useRef<Record<string,number>>({});

  // Fetch OSRM route for selected route
  useEffect(() => {
    const selRoute = routes.find(r=>r.id===selectedId);
    if (!selRoute) return;
    if (routePolylines[selectedId] && routePolylines[selectedId].length > 2) return;
    setFetchingRoute(true);
    fetchOSRMRoute(getHub(selRoute.fromId), getHub(selRoute.toId)).then(result => {
      setFetchingRoute(false);
      if (result) {
        setRoutePolylines(p=>({...p,[selectedId]:result.polyline}));
        setRouteMeta(m=>({...m,[selectedId]:{distance:result.distance,duration:result.duration,steps:result.steps}}));
        setOsrmInfo({steps:result.steps});
      }
    });
  }, [selectedId, routes]);

  // Animate trucks along real polylines
  useEffect(() => {
    if (truckTimerRef.current) clearInterval(truckTimerRef.current);
    routes.filter(r=>r.status==="in-transit").forEach(r => {
      if (!(r.id in progressRef.current)) progressRef.current[r.id] = r.progress ?? 0.3;
    });
    truckTimerRef.current = setInterval(() => {
      setTruckPositions(prev => {
        const next = {...prev};
        routes.filter(r=>r.status==="in-transit").forEach(r => {
          const poly = routePolylines[r.id];
          if (!poly || poly.length < 2) {
            const f=getHub(r.fromId); const t=getHub(r.toId);
            const prog = progressRef.current[r.id] ?? 0.3;
            const fallbackPoly: [number,number][] = [[f.lat,f.lng],[t.lat,t.lng]];
            const pos = interpolatePolyline(fallbackPoly, prog);
            const angle = truckAngle(fallbackPoly, prog);
            next[r.id] = { pos, angle };
          } else {
            const prog = progressRef.current[r.id] ?? 0.3;
            progressRef.current[r.id] = Math.min(1, prog + 0.0003);
            const pos = interpolatePolyline(poly, prog);
            const angle = truckAngle(poly, prog);
            next[r.id] = { pos, angle };
          }
        });
        return next;
      });
    }, 200);
    return () => { if (truckTimerRef.current) clearInterval(truckTimerRef.current); };
  }, [routes, routePolylines]);

  // Center map on selected route
  useEffect(() => {
    const sel = routes.find(r=>r.id===selectedId);
    if (sel) {
      const f=getHub(sel.fromId); const t=getHub(sel.toId);
      setCenterOn({ lat:(f.lat+t.lat)/2, lng:(f.lng+t.lng)/2 });
    }
  }, [selectedId, routes]);

  function handleGeolocate() {
    setLocating(true);
    navigator.geolocation?.getCurrentPosition(
      pos => { setUserPos([pos.coords.latitude, pos.coords.longitude]); setCenterOn({lat:pos.coords.latitude,lng:pos.coords.longitude}); setLocating(false); },
      () => setLocating(false),
      { enableHighAccuracy: true, timeout: 8000 }
    );
  }

  const handleRouteCreated = useCallback((r: LiveRoute) => {
    setRoutes(prev => [...prev, r]);
    if (r.polyline) setRoutePolylines(p=>({...p,[r.id]:r.polyline!}));
    if (r.distance && r.duration) setRouteMeta(m=>({...m,[r.id]:{distance:r.distance!,duration:r.duration!,steps:[]}}));
    setSelectedId(r.id);
  }, []);

  const filtered = routes.filter(r => routeFilter==="all" || r.status===routeFilter);
  const selRoute = routes.find(r=>r.id===selectedId) ?? routes[0];
  const selFrom = getHub(selRoute.fromId);
  const selTo = getHub(selRoute.toId);
  const selMeta = routeMeta[selectedId];

  return (
    <div className="max-w-6xl mx-auto space-y-5">
      {showPlanner && <RoutePlanner onClose={()=>setShowPlanner(false)} onRouteCreated={handleRouteCreated}/>}

      {/* Header */}
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h2 className="text-2xl font-bold text-[#1a1a0e]" style={{ fontFamily:"var(--font-display)" }}>
            Route Planning &amp; Optimization
          </h2>
          <p className="text-sm text-[#7c5c32] mt-1">
            Live GPS tracking &bull; Real road routes via OSRM &bull; Satellite imagery &bull; Madhya Pradesh
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={handleGeolocate} disabled={locating}
            className="flex items-center gap-2 border border-[#e8e3d8] text-[#7c5c32] px-4 py-2.5 rounded-xl text-sm font-medium hover:bg-[#f5f0e8] transition-colors disabled:opacity-50">
            &#127759; {locating?"Locating…":"My Location"}
          </button>
          <button onClick={()=>setShowPlanner(true)}
            className="flex items-center gap-2 bg-[#1e4d2b] hover:bg-[#2d6b3e] text-white px-4 py-2.5 rounded-xl text-sm font-semibold transition-colors">
            &#128640; Generate New Route
          </button>
        </div>
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label:"Logistics Efficiency",  value:"94.2%",     trend:"↑ 12.3%",  sub:"vs manual planning" },
          { label:"Fuel Cost Savings",     value:"₹42,850",   trend:"↓ 18.2%",  sub:"Reduced carbon 2.4 T" },
          { label:"Avg Transit Time",      value:"4.2 Hrs",   trend:"↓ 45m",    sub:"Per delivery cycle" },
          { label:"Active Transporters",   value:routes.length+"", trend:"↑ Live", sub:"Routes tracked today" },
        ].map(k=>(
          <div key={k.label} className="bg-white border border-[#e8e3d8] rounded-2xl p-5 space-y-1.5">
            <span className="inline-block text-[10px] font-mono font-semibold text-[#1e4d2b] bg-[#d6f0de] px-2.5 py-0.5 rounded-full">{k.trend}</span>
            <div className="text-2xl font-bold font-mono text-[#1a1a0e]">{k.value}</div>
            <div className="text-[10px] font-mono text-[#7c5c32] uppercase tracking-wider">{k.label}</div>
            <p className="text-[10px] text-[#a77c3e] leading-snug">{k.sub}</p>
          </div>
        ))}
      </div>

      {/* Map + Routes */}
      <div className="grid lg:grid-cols-[1fr_336px] gap-5 items-start">

        {/* Map panel */}
        <div className="space-y-3">
          <div className="bg-white border border-[#e8e3d8] rounded-2xl overflow-hidden shadow-sm">

            {/* Map toolbar */}
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-[#e8e3d8]">
              <div>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#22c55e] animate-pulse"/>
                  <span className="text-sm font-semibold text-[#1a1a0e]">Live GPS Map</span>
                  {fetchingRoute && <span className="text-[10px] font-mono text-[#1a73e8] bg-[#e8f0fe] px-2 py-0.5 rounded-full animate-pulse">Fetching OSRM route…</span>}
                </div>
                <p className="text-xs text-[#7c5c32] mt-0.5">
                  {selFrom.name} &#8594; {selTo.name} &bull; {selMeta?.distance ?? "Calculating…"}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex bg-[#f5f0e8] rounded-xl p-1">
                  {(["streets","satellite"] as const).map(m=>(
                    <button key={m} onClick={()=>setMapStyle(m)}
                      className={"px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-all " + (mapStyle===m?"bg-white shadow-sm text-[#1a1a0e]":"text-[#7c5c32]")}>
                      {m==="streets"?"&#128506; Map":"&#127760; Satellite"}
                    </button>
                  ))}
                </div>
                <button onClick={handleGeolocate} disabled={locating}
                  className="w-8 h-8 rounded-xl bg-[#f5f0e8] flex items-center justify-center text-[#4285f4] hover:bg-[#e8e3d8] transition-colors disabled:opacity-50" title="My location">
                  <svg width="14" height="14" fill="currentColor" viewBox="0 0 24 24"><path d="M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zm8.94 3A8.994 8.994 0 0 0 13 3.06V1h-2v2.06A8.994 8.994 0 0 0 3.06 11H1v2h2.06A8.994 8.994 0 0 0 11 20.94V23h2v-2.06A8.994 8.994 0 0 0 20.94 13H23v-2h-2.06z"/></svg>
                </button>
              </div>
            </div>

            {/* Leaflet map */}
            <div style={{ height:"480px", position:"relative" }}>
              <LiveMap
                routes={routes}
                selectedId={selectedId}
                onSelectRoute={setSelectedId}
                mapStyle={mapStyle}
                routePolylines={routePolylines}
                truckPositions={truckPositions}
                userPos={userPos}
                centerOnRoute={centerOn}
              />

              {/* Overlay: Selected route info card */}
              <div className="absolute bottom-4 left-4 z-[1000] w-72 bg-white rounded-2xl shadow-2xl overflow-hidden pointer-events-auto">
                <div className="bg-[#1a73e8] px-4 py-3 flex items-center justify-between">
                  <div>
                    <p className="text-[9px] text-white/70 font-mono uppercase tracking-wider">{selRoute.id} &bull; {STATUS_CFG[selRoute.status].label}</p>
                    <p className="text-sm font-bold text-white">{selRoute.cargo}</p>
                  </div>
                  <span className="text-2xl">&#128667;</span>
                </div>
                <div className="px-4 py-3 space-y-2.5">
                  <div className="flex items-stretch gap-3">
                    <div className="flex flex-col items-center gap-1 pt-0.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-[#34a853] border-2 border-white shadow"/>
                      <div className="w-0.5 h-6 bg-[#e8e8e8]"/>
                      <div className="w-2.5 h-2.5 rounded-full bg-[#ea4335] border-2 border-white shadow"/>
                    </div>
                    <div className="flex-1 space-y-3">
                      <div><p className="text-[10px] font-mono text-[#9aa0a6]">Pickup</p><p className="text-xs font-semibold text-[#3c4043]">{selFrom.name}</p></div>
                      <div><p className="text-[10px] font-mono text-[#9aa0a6]">Dropoff</p><p className="text-xs font-semibold text-[#3c4043]">{selTo.name}</p></div>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2 pt-1 border-t border-[#f1f3f4]">
                    {[
                      {icon:"&#9201;",label:"ETA",value:selRoute.eta},
                      {icon:"&#128207;",label:"Dist",value:selMeta?.distance??selRoute.distance??"—"},
                      {icon:"&#127758;",label:"Drive",value:selMeta?.duration??selRoute.duration??"—"},
                    ].map(s=>(
                      <div key={s.label} className="text-center">
                        <p className="text-base" dangerouslySetInnerHTML={{__html:s.icon}}/>
                        <p className="text-[10px] font-bold font-mono text-[#3c4043]">{s.value}</p>
                        <p className="text-[9px] text-[#9aa0a6] font-mono">{s.label}</p>
                      </div>
                    ))}
                  </div>
                  {selRoute.status==="in-transit" && (
                    <div>
                      <div className="flex justify-between text-[9px] font-mono text-[#9aa0a6] mb-1">
                        <span>Progress</span>
                        <span className="text-[#1a73e8] font-semibold">{Math.round((selRoute.progress??0.5)*100)}% complete</span>
                      </div>
                      <div className="h-1.5 bg-[#f1f3f4] rounded-full overflow-hidden">
                        <div className="h-full bg-[#1a73e8] rounded-full transition-all" style={{ width:`${Math.round((selRoute.progress??0.5)*100)}%` }}/>
                      </div>
                    </div>
                  )}
                  {selRoute.driver!=="TBD" && <p className="text-[9px] font-mono text-[#7c5c32]">&#128100; {selRoute.driver} &bull; {selRoute.truck}</p>}
                </div>
                <div className="grid grid-cols-3 border-t border-[#f1f3f4]">
                  {[{label:"Call Driver"},{label:"Share ETA"},{label:"Re-route"}].map(a=>(
                    <button key={a.label} className="py-2.5 flex flex-col items-center gap-0.5 hover:bg-[#f8f9fa] transition-colors border-r border-[#f1f3f4] last:border-0 text-[8px] text-[#1a73e8] font-semibold">
                      {a.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* OSRM directions (overlay top right) */}
              {osrmInfo && osrmInfo.steps.length > 0 && (
                <div className="absolute top-4 right-4 z-[1000] bg-white rounded-2xl shadow-xl p-3 w-52 pointer-events-auto">
                  <p className="text-[9px] font-bold text-[#1e4d2b] mb-2 uppercase tracking-wider">&#128506; Turn-by-turn (OSRM)</p>
                  {osrmInfo.steps.map((s,i)=>(
                    <p key={i} className="text-[9px] text-[#3c4043] flex gap-1 mb-1 leading-tight">
                      <span className="text-[#1a73e8] font-bold flex-shrink-0">{i+1}.</span>{s}
                    </p>
                  ))}
                </div>
              )}

              {/* Live GPS badge */}
              <div className="absolute bottom-4 right-4 z-[1000] flex flex-col items-end gap-2 pointer-events-none">
                <div className="flex items-center gap-1.5 bg-white/90 backdrop-blur-sm border border-[#e8e8e8] rounded-full px-3 py-1 shadow-sm">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#ea4335] animate-pulse"/>
                  <span className="text-[9px] font-mono text-[#3c4043] font-semibold">GPS LIVE</span>
                </div>
                {userPos && (
                  <div className="flex items-center gap-1 bg-[#e8f0fe] border border-[#c5d7f8] rounded-full px-2.5 py-1 shadow-sm">
                    <span className="text-[9px] font-mono text-[#1a73e8]">&#127759; {userPos[0].toFixed(4)}, {userPos[1].toFixed(4)}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Below-map strip */}
            <div className="grid grid-cols-3 divide-x divide-[#e8e3d8]">
              {[
                {icon:"&#128336;",label:"Optimal Window",value:"06:00 – 08:30 AM",color:"text-[#1e4d2b]"},
                {icon:"&#9888;&#65039;",label:"Route Alert",value:"Moderate Traffic NH-3",color:"text-[#c8941a]"},
                {icon:"&#128260;",label:"Next Sync",value:"Starting in 1h 24m",color:"text-[#1e40af]"},
              ].map(s=>(
                <div key={s.label} className="px-5 py-4 flex items-center gap-3">
                  <span className="text-lg flex-shrink-0" dangerouslySetInnerHTML={{__html:s.icon}}/>
                  <div>
                    <p className="text-[9px] font-mono text-[#7c5c32] uppercase tracking-wider mb-0.5">{s.label}</p>
                    <p className={"text-xs font-semibold font-mono "+s.color}>{s.value}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Route list */}
        <div className="bg-white border border-[#e8e3d8] rounded-2xl overflow-hidden shadow-sm flex flex-col" style={{ minHeight:"580px" }}>
          <div className="px-5 py-4 border-b border-[#e8e3d8]">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-[#1a1a0e]">Live Routes</h3>
              <span className="text-[10px] font-mono text-[#7c5c32] bg-[#f5f0e8] px-2.5 py-1 rounded-full">{routes.length} total</span>
            </div>
          </div>

          <div className="px-4 py-3 border-b border-[#e8e3d8] flex gap-1">
            {(["all","in-transit","optimized","pending"] as const).map(f=>(
              <button key={f} onClick={()=>setRouteFilter(f)}
                className={"px-2.5 py-1 rounded-lg text-[10px] font-medium transition-all " + (routeFilter===f?"bg-[#1e4d2b] text-white":"text-[#7c5c32] hover:bg-[#f5f0e8]")}>
                {f==="all"?"All":f==="in-transit"?"Transit":f==="optimized"?"Ready":"Pending"}
              </button>
            ))}
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-[#f5f0e8]">
            {filtered.map(r=>{
              const sc=STATUS_CFG[r.status];
              const isSel=r.id===selectedId;
              const meta=routeMeta[r.id];
              return (
                <div key={r.id} className={"px-5 py-3.5 cursor-pointer transition-colors hover:bg-[#faf9f5] "+(isSel?"bg-[#f0faf3]":"")}
                  onClick={()=>setSelectedId(r.id)}>
                  <div className="flex items-start gap-3">
                    <div className="w-9 h-9 rounded-xl bg-[#f5f0e8] flex items-center justify-center flex-shrink-0 mt-0.5 text-base">&#128667;</div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                        <span className="text-[11px] font-mono font-bold text-[#7c5c32]">{r.id}</span>
                        <span className={"text-[9px] font-mono px-2 py-0.5 rounded-full "+sc.badge+" "+sc.text}>{sc.label}</span>
                      </div>
                      <p className="text-xs font-medium text-[#1a1a0e] truncate">{getHub(r.fromId).name} &#8594; {getHub(r.toId).name}</p>
                      <div className="flex items-center justify-between mt-1.5 gap-1 flex-wrap">
                        <span className="text-[9px] font-mono text-[#a77c3e] bg-[#fef9ec] px-1.5 py-0.5 rounded">{r.cargo}</span>
                        <span className="text-[9px] font-mono text-[#7c5c32]">{meta?.distance??r.distance??""} {meta?.duration?"/ "+meta.duration:""}</span>
                      </div>
                    </div>
                    <span className="w-2 h-2 rounded-full block mt-1.5 flex-shrink-0" style={{ background:sc.dot }}/>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="px-5 py-4 border-t border-[#e8e3d8] bg-[#f9f7f2] flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-[#d6f0de] flex items-center justify-center flex-shrink-0">
              <span className="text-xs">&#129302;</span>
            </div>
            <p className="text-[10px] text-[#1a1a0e] leading-relaxed flex-1">
              <b className="text-[#1e4d2b]">AI + OSRM:</b> Routes use real road data from OpenStreetMap via OSRM.
            </p>
          </div>
        </div>
      </div>

      {/* Bottom panels */}
      <div className="grid lg:grid-cols-2 gap-5">
        <div className="bg-white border border-[#e8e3d8] rounded-2xl overflow-hidden shadow-sm">
          <div className="px-5 py-4 border-b border-[#e8e3d8]"><h3 className="font-semibold text-[#1a1a0e]">Optimization Logs</h3></div>
          <div className="divide-y divide-[#f5f0e8]">
            {[
              { msg:"Route recalculated via OSRM for Indore Cluster",  detail:"Real road distance 78 km. Fuel-optimal via NH-52. Truck updated.", ts:"Live · OSRM_ROUTE_INDORE_0R6E" },
              { msg:"Cold chain alert resolved for Sehore Cluster",     detail:"Alternate vehicle deployed. Temperature 10–14°C maintained.",     ts:"14:19 · ALERT_COLDCHAIN_SEHORE"  },
              { msg:"New route RT-889 dispatched from Ratlam → Mandsaur", detail:"OSRM distance 124 km via SH-31. Garlic 1.2 T refrigerated.", ts:"13:55 · DISPATCH_RT889"          },
            ].map((log,i)=>(
              <div key={i} className="px-5 py-4 flex gap-3">
                <span className="w-2 h-2 rounded-full bg-[#4a7c59] mt-1.5 flex-shrink-0 block"/>
                <div>
                  <p className="text-xs font-semibold text-[#1a1a0e]">{log.msg}</p>
                  <p className="text-[10px] text-[#7c5c32] mt-0.5 leading-relaxed">{log.detail}</p>
                  <p className="text-[9px] font-mono text-[#a77c3e] mt-1.5 opacity-70">{log.ts}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white border border-[#e8e3d8] rounded-2xl overflow-hidden shadow-sm">
          <div className="px-5 py-4 border-b border-[#e8e3d8] flex items-center justify-between">
            <h3 className="font-semibold text-[#1a1a0e] flex items-center gap-2">&#128667; Fleet Utilization</h3>
            <button className="text-xs font-mono text-[#4a7c59] hover:text-[#1e4d2b]">View Report</button>
          </div>
          <div className="px-5 py-5 space-y-5">
            {[
              { label:"Active Fleet",                  pct:82, sub:"105 / 128 vehicles",    barColor:"#1e4d2b" },
              { label:"Fuel Consumption vs Target",    pct:64, sub:"64% Fuel-Optimized",    barColor:"#c8941a" },
            ].map(bar=>(
              <div key={bar.label}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-[#7c5c32]">{bar.label}</span>
                  <span className="text-xs font-mono font-semibold text-[#1a1a0e]">{bar.pct}%</span>
                </div>
                <div className="h-2.5 bg-[#f0ebe0] rounded-full overflow-hidden">
                  <div className="h-full rounded-full" style={{ width:`${bar.pct}%`, background:bar.barColor }}/>
                </div>
                <p className="text-[9px] font-mono text-[#a77c3e] mt-1">{bar.sub}</p>
              </div>
            ))}
            <div className="grid grid-cols-3 gap-3 pt-1">
              {[{label:"Maintenance",value:"12",color:"text-[#c8941a]"},{label:"On-Road",value:routes.filter(r=>r.status==="in-transit").length+"",color:"text-[#1e4d2b]"},{label:"Ready",value:routes.filter(r=>r.status==="optimized").length+"",color:"text-[#7c5c32]"}].map(s=>(
                <div key={s.label} className="bg-[#f9f7f2] border border-[#e8e3d8] rounded-2xl p-4 text-center">
                  <div className={"text-2xl font-bold font-mono "+s.color}>{s.value}</div>
                  <div className="text-[10px] text-[#7c5c32] mt-1 font-mono">{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}


function EscrowTracker({ status }: { status: string }) {
  const step = status==="settled" ? 5 : status==="delivered" ? 4 : status==="in-transit" ? 3 : 2;
  return (
    <div className="mt-4 pt-4 border-t border-[#e8e3d8]">
      <p className="text-xs font-mono text-[#7c5c32] uppercase tracking-wider mb-3">💳 Payment Escrow Track</p>
      <div className="flex items-start gap-1 overflow-x-auto pb-1">
        {ESCROW_STEPS.map((s, i) => {
          const done = i < step;
          const active = i === step - 1;
          return (
            <div key={s} className="flex flex-col items-center min-w-[90px] text-center">
              <div className="flex items-center w-full mb-1">
                {i > 0 && <div className={`flex-1 h-0.5 ${done ? "bg-[#1e4d2b]" : "bg-[#e8e3d8]"}`}/>}
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs flex-shrink-0 transition-colors ${done ? "bg-[#1e4d2b] text-white" : active ? "bg-[#c8941a] text-white" : "bg-[#e8e3d8] text-[#7c5c32]"}`}>
                  {done ? "✓" : i+1}
                </div>
                {i < ESCROW_STEPS.length-1 && <div className={`flex-1 h-0.5 ${i < step-1 ? "bg-[#1e4d2b]" : "bg-[#e8e3d8]"}`}/>}
              </div>
              <p className={`text-[9px] font-mono leading-tight ${done ? "text-[#1e4d2b] font-semibold" : "text-[#a77c3e]"}`}>{s}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function QRModal({ orderId, onClose }: { orderId: string; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-white rounded-2xl p-6 max-w-xs w-full mx-4 shadow-2xl" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold" style={{fontFamily:"var(--font-display)"}}>Farm-to-Consumer QR</h3>
          <button onClick={onClose} className="text-[#7c5c32] hover:text-[#1a1a0e]">✕</button>
        </div>
        <div className="bg-[#f5f0e8] rounded-xl p-6 flex items-center justify-center mb-4">
          <svg viewBox="0 0 100 100" width="140" height="140">
            {/* Simplified QR pattern */}
            <rect width="100" height="100" fill="white"/>
            {[0,1,2,3,4,5,6].map(r=>[0,1,2,3,4,5,6].map(c=>{
              const inCorner=(r<3&&c<3)||(r<3&&c>3)||(r>3&&c<3);
              const val=Math.random()>0.5;
              return inCorner||val ? <rect key={`${r}-${c}`} x={r*14} y={c*14} width="12" height="12" fill="#1e4d2b" rx="1"/> : null;
            }))}
            <rect x="2" y="2" width="30" height="30" rx="3" fill="none" stroke="#1e4d2b" strokeWidth="3"/>
            <rect x="5" y="5" width="24" height="24" rx="2" fill="#1e4d2b"/>
            <rect x="9" y="9" width="16" height="16" rx="1" fill="white"/>
            <rect x="12" y="12" width="10" height="10" rx="1" fill="#1e4d2b"/>
            <rect x="68" y="2" width="30" height="30" rx="3" fill="none" stroke="#1e4d2b" strokeWidth="3"/>
            <rect x="71" y="5" width="24" height="24" rx="2" fill="#1e4d2b"/>
            <rect x="75" y="9" width="16" height="16" rx="1" fill="white"/>
            <rect x="78" y="12" width="10" height="10" rx="1" fill="#1e4d2b"/>
            <rect x="2" y="68" width="30" height="30" rx="3" fill="none" stroke="#1e4d2b" strokeWidth="3"/>
            <rect x="5" y="71" width="24" height="24" rx="2" fill="#1e4d2b"/>
            <rect x="9" y="75" width="16" height="16" rx="1" fill="white"/>
            <rect x="12" y="78" width="10" height="10" rx="1" fill="#1e4d2b"/>
          </svg>
        </div>
        <p className="text-center text-xs text-[#7c5c32] font-mono">{orderId} · Farm-to-consumer trace</p>
        <p className="text-center text-[9px] text-[#a77c3e] mt-1">Scan to see full sourcing chain, farmer name, and verified quality grade</p>
        <button className="mt-4 w-full bg-[#1e4d2b] text-white py-2.5 rounded-xl text-sm font-semibold hover:bg-[#2d6b3e] transition-colors">Download QR</button>
      </div>
    </div>
  );
}

function OrdersView() {
  const [expandedOrder, setExpandedOrder] = useState<string|null>(null);
  const [qrOrder, setQrOrder] = useState<string|null>(null);

  return (
    <div className="max-w-5xl mx-auto">
      {qrOrder && <QRModal orderId={qrOrder} onClose={() => setQrOrder(null)}/>}

      <div className="mb-8">
        <h2 className="text-3xl font-bold" style={{ fontFamily: "var(--font-display)" }}>Transaction & Order Management</h2>
        <p className="text-[#7c5c32] mt-1">Every completed sale feeds outcome data back into the AI model</p>
      </div>

      <div className="grid md:grid-cols-4 gap-4 mb-8">
        {[
          { label: "Total Orders", value: "2,041" },
          { label: "In Transit", value: "124" },
          { label: "Settled", value: "1,894" },
          { label: "Total GMV", value: "₹8.4Cr" },
        ].map((s) => (
          <div key={s.label} className="bg-white border border-[#e8e3d8] rounded-2xl p-5 text-center">
            <div className="text-2xl font-bold font-mono text-[#1e4d2b]">{s.value}</div>
            <div className="text-sm text-[#7c5c32] mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="bg-white border border-[#e8e3d8] rounded-2xl overflow-hidden">
        <div className="p-5 border-b border-[#e8e3d8] flex items-center justify-between">
          <h3 className="font-semibold">Recent Orders</h3>
          <span className="text-xs font-mono text-[#4a7c59] bg-[#d6f0de] px-3 py-1 rounded-full">Live feed</span>
        </div>
        <div className="divide-y divide-[#e8e3d8]">
          {orders.map((o) => (
            <div key={o.id} className="hover:bg-[#faf9f5] transition-colors">
              <div className="p-5">
                <div className="flex items-center gap-4 flex-wrap">
                  <div className="w-10 h-10 rounded-xl bg-[#f0ebe0] flex items-center justify-center font-mono text-xs text-[#7c5c32] flex-shrink-0">
                    {o.crop==="Tomato"?"🍅":o.crop==="Onion"?"🧅":"🥔"}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <span className="font-mono text-xs text-[#7c5c32]">{o.id}</span>
                      <span className="font-medium">{o.crop}</span>
                      <Badge label={o.status==="delivered"?"Delivered":o.status==="in-transit"?"In Transit":"Settled"} variant={o.status==="delivered"?"green":o.status==="in-transit"?"blue":"gray"}/>
                    </div>
                    <div className="flex flex-wrap gap-x-5 gap-y-0.5 text-sm text-[#7c5c32]">
                      <span>{o.farmer} → {o.buyer}</span>
                      <span>📦 {o.qty}</span>
                      <span className="font-mono font-semibold text-[#1e4d2b]">{o.value}</span>
                      <span>Farmer share: <span className="font-semibold text-[#4a7c59]">{o.farmerShare}</span></span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <button onClick={() => setQrOrder(o.id)} className="text-xs px-3 py-1.5 rounded-lg bg-[#f0ebe0] text-[#7c5c32] hover:bg-[#e8e3d8] font-mono transition-colors" title="QR Traceability">
                      QR
                    </button>
                    <button onClick={() => setExpandedOrder(expandedOrder===o.id?null:o.id)} className="text-xs px-3 py-1.5 rounded-lg bg-[#1e4d2b] text-white hover:bg-[#2d6b3e] font-mono transition-colors">
                      {expandedOrder===o.id?"Hide":"Payment Track"}
                    </button>
                    <div className="text-right">
                      <div className="font-mono font-semibold text-[#1e4d2b]">{o.priceSold}</div>
                      <div className="text-xs text-[#7c5c32] font-mono">{o.date}</div>
                    </div>
                  </div>
                </div>
                {expandedOrder===o.id && <EscrowTracker status={o.status}/>}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-5 bg-[#1e4d2b] text-white rounded-2xl p-5 flex items-center gap-4">
        <span className="text-3xl">🔄</span>
        <div>
          <p className="font-semibold">Continuous Learning Loop Active</p>
          <p className="text-sm text-[#c8dfc8] mt-1">Actual price, quantity sold, and delivery success from every order automatically retrains the demand forecasting model. Last update: 14 minutes ago.</p>
        </div>
      </div>
    </div>
  );
}

function TransparencyView() {
  const orders_settled = orders.filter(o => o.status === "settled" || o.status === "delivered");
  return (
    <div className="max-w-5xl mx-auto">
      <div className="mb-8">
        <h2 className="text-3xl font-bold" style={{ fontFamily: "var(--font-display)" }}>Transparency & Price Discovery</h2>
        <p className="text-[#7c5c32] mt-1">Farmers see their share of final price. Buyers see verified sourcing details.</p>
      </div>

      {/* Price waterfall */}
      <div className="bg-white border border-[#e8e3d8] rounded-2xl p-7 mb-6">
        <h3 className="font-semibold mb-6" style={{ fontFamily: "var(--font-display)" }}>Tomato Price Journey — Farm to Consumer</h3>
        <div className="space-y-3">
          {[
            { stage: "Farmer Gate Price", value: 30, amount: "₹30/kg", color: "bg-[#1e4d2b]" },
            { stage: "Kisansetu Platform Fee (3%)", value: 1, amount: "₹1/kg", color: "bg-[#4a7c59]" },
            { stage: "Transport & Logistics", value: 4, amount: "₹4/kg", color: "bg-[#c8941a]" },
            { stage: "Buyer Margin", value: 7, amount: "₹7/kg", color: "bg-[#a77c3e]" },
            { stage: "Retail Markup", value: 10, amount: "₹10/kg", color: "bg-[#e8e3d8] text-[#7c5c32]" },
          ].map((s, i) => (
            <div key={s.stage} className="flex items-center gap-4">
              <span className="text-sm text-[#7c5c32] w-52 flex-shrink-0 font-mono text-xs">{s.stage}</span>
              <div className="flex-1 bg-[#f0ebe0] rounded-full h-7 overflow-hidden">
                <div className={`${s.color} h-full rounded-full transition-all duration-700 flex items-center px-3`}
                  style={{ width: `${(s.value / 52) * 100}%` }}>
                  <span className={`text-xs font-mono font-semibold ${s.color.includes("e8e3d8") ? "text-[#7c5c32]" : "text-white"} whitespace-nowrap`}>{s.amount}</span>
                </div>
              </div>
            </div>
          ))}
          <div className="border-t border-[#e8e3d8] pt-3 flex items-center gap-4">
            <span className="text-sm font-semibold text-[#1a1a0e] w-52 font-mono text-xs">Consumer Pays</span>
            <div className="flex-1">
              <span className="text-2xl font-bold font-mono text-[#1e4d2b]">₹52/kg</span>
              <span className="text-sm text-[#7c5c32] ml-3">Farmer receives <span className="font-bold text-[#1e4d2b]">57.7%</span> of consumer price</span>
            </div>
          </div>
        </div>
      </div>

      {/* Sourcing cards */}
      <div className="grid md:grid-cols-2 gap-5">
        {orders_settled.map((o) => (
          <div key={o.id} className="bg-white border border-[#e8e3d8] rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-lg">{o.crop === "Tomato" ? "🍅" : o.crop === "Onion" ? "🧅" : "🥔"}</span>
              <span className="font-semibold">{o.crop}</span>
              <span className="font-mono text-xs text-[#7c5c32]">· {o.id}</span>
            </div>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <p className="text-[#7c5c32] font-mono text-xs mb-1">Source</p>
                <p className="font-medium">{o.farmer}</p>
              </div>
              <div>
                <p className="text-[#7c5c32] font-mono text-xs mb-1">Buyer</p>
                <p className="font-medium">{o.buyer}</p>
              </div>
              <div>
                <p className="text-[#7c5c32] font-mono text-xs mb-1">Sale Price</p>
                <p className="font-mono font-semibold text-[#1e4d2b]">{o.priceSold}</p>
              </div>
              <div>
                <p className="text-[#7c5c7f] font-mono text-xs mb-1">Farmer's Share</p>
                <p className="font-mono font-semibold text-[#4a7c59]">{o.farmerShare}</p>
              </div>
            </div>
          </div>
        ))}

        <div className="bg-[#f5f0e8] border border-[#e8e3d8] rounded-2xl p-5 flex flex-col justify-center">
          <p className="font-semibold mb-2" style={{ fontFamily: "var(--font-display)" }}>Platform Average</p>
          <div className="text-4xl font-bold font-mono text-[#1e4d2b] mb-1">74–81%</div>
          <p className="text-sm text-[#7c5c32]">of consumer price reaching farmers vs. traditional ~40% via mandi chain</p>
        </div>
      </div>
    </div>
  );
}

// ─── Nav ──────────────────────────────────────────────────────────────────────

// ─── Profile / Auth ───────────────────────────────────────────────────────────

type AccountType = "farmer" | "buyer";

interface CropItem { name: string; photo: string; acreage: string; season: string; }
interface SaleRecord { id: string; crop: string; qty: string; price: string; buyer: string; date: string; rating: number; status: string; }
interface RequirementRecord { id: string; crop: string; qty: string; priceRange: string; date: string; status: string; }
interface PurchaseRecord { id: string; crop: string; qty: string; price: string; farmer: string; date: string; }

interface UserProfile {
  name: string; phone: string; email: string; accountType: AccountType; password: string;
  // farmer
  village: string; district: string; state: string; preferredLang: string; photoUrl: string;
  fpoName: string; landAcres: string; primaryCrops: string; bankName: string; upiId: string;
  kccStatus: string; pmKisanStatus: string; loanStatus: string; loanAmount: string;
  crops: CropItem[]; sales: SaleRecord[]; badgeVerified: boolean; badgeTopSeller: boolean;
  // buyer
  orgName: string; orgType: string; gst: string; deliveryCity: string;
  preferredCrops: string; monthlyVolume: string; contactPerson: string;
  requirements: RequirementRecord[]; purchases: PurchaseRecord[];
  savedFilters: string; favoriteFarmers: string[];
  buyerRating: number; buyerVerified: boolean;
  joinedDate: string; lastSync: string;
}

const INDIAN_STATES = ["Andhra Pradesh","Assam","Bihar","Chhattisgarh","Gujarat","Haryana","Himachal Pradesh","Jharkhand","Karnataka","Kerala","Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Odisha","Punjab","Rajasthan","Tamil Nadu","Telangana","Uttar Pradesh","Uttarakhand","West Bengal"];
const LANGUAGES = ["Hindi","Marathi","Telugu","Tamil","Kannada","Gujarati","Bengali","Punjabi","Odia","English"];

const DEMO_FARMER: UserProfile = {
  name:"Ramesh Patil", phone:"9876543210", email:"ramesh@example.com", accountType:"farmer", password:"demo123",
  village:"Nashik Rural", district:"Nashik", state:"Maharashtra", preferredLang:"Marathi", photoUrl:"",
  fpoName:"Nashik FPO Ltd.", landAcres:"4.5", primaryCrops:"Tomato, Onion, Grapes", bankName:"Bank of Maharashtra", upiId:"ramesh@upi",
  kccStatus:"Active · ₹1.5L limit", pmKisanStatus:"₹6,000/yr · Next: Dec 2024", loanStatus:"Warehouse loan active", loanAmount:"₹80,000",
  crops:[
    {name:"Tomato", photo:"https://images.unsplash.com/photo-1546094096-0df4bcaad337?w=200&h=200&fit=crop", acreage:"1.5", season:"Kharif"},
    {name:"Onion",  photo:"https://images.unsplash.com/photo-1618512496248-a07fe83aa8cb?w=200&h=200&fit=crop", acreage:"2.0", season:"Rabi"},
    {name:"Grapes", photo:"https://images.unsplash.com/photo-1537640538966-79f369143f8f?w=200&h=200&fit=crop", acreage:"1.0", season:"Annual"},
  ],
  sales:[
    {id:"S1", crop:"Tomato", qty:"2.5 MT", price:"₹52/kg", buyer:"BigBasket Wholesale", date:"12 Aug 2024", rating:5, status:"Completed"},
    {id:"S2", crop:"Onion",  qty:"4 MT",   price:"₹28/kg", buyer:"Reliance Fresh Hub", date:"3 Jul 2024",  rating:4, status:"Completed"},
    {id:"S3", crop:"Grapes", qty:"800 kg", price:"₹95/kg", buyer:"Star Exports Pvt",   date:"20 Jun 2024", rating:5, status:"Completed"},
  ],
  badgeVerified:true, badgeTopSeller:true,
  orgName:"", orgType:"Retailer", gst:"", deliveryCity:"", preferredCrops:"", monthlyVolume:"", contactPerson:"",
  requirements:[], purchases:[], savedFilters:"", favoriteFarmers:[], buyerRating:0, buyerVerified:false,
  joinedDate:"15 Jan 2024", lastSync: new Date().toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit"}),
};

const DEMO_BUYER: UserProfile = {
  name:"Kavita Sharma", phone:"9123456780", email:"kavita@bigbasket.com", accountType:"buyer", password:"demo123",
  village:"", district:"", state:"Karnataka", preferredLang:"English", photoUrl:"",
  fpoName:"", landAcres:"", primaryCrops:"", bankName:"", upiId:"",
  kccStatus:"", pmKisanStatus:"", loanStatus:"", loanAmount:"",
  crops:[], sales:[], badgeVerified:false, badgeTopSeller:false,
  orgName:"BigBasket Wholesale", orgType:"Supermarket", gst:"29AABCB1234D1Z5", deliveryCity:"Bengaluru",
  preferredCrops:"Tomato, Potato, Onion, Leafy Greens", monthlyVolume:"120", contactPerson:"Kavita Sharma",
  requirements:[
    {id:"R1", crop:"Tomato",  qty:"10 MT/week", priceRange:"₹40–60/kg", date:"20 Aug 2024", status:"Active"},
    {id:"R2", crop:"Potato",  qty:"8 MT/week",  priceRange:"₹18–28/kg", date:"15 Aug 2024", status:"Active"},
    {id:"R3", crop:"Spinach", qty:"500 kg/week",priceRange:"₹25–40/kg", date:"10 Jul 2024",  status:"Closed"},
  ],
  purchases:[
    {id:"P1", crop:"Tomato", qty:"2.5 MT", price:"₹52/kg", farmer:"Ramesh Patil · Nashik FPO", date:"12 Aug 2024"},
    {id:"P2", crop:"Onion",  qty:"4 MT",   price:"₹28/kg", farmer:"Suresh Yadav · UP Kisan Samiti", date:"5 Aug 2024"},
    {id:"P3", crop:"Potato", qty:"6 MT",   price:"₹22/kg", farmer:"Anita Devi · Bihar FPO", date:"28 Jul 2024"},
  ],
  savedFilters:"Tomato | 5–20 MT | <100 km | Grade A", favoriteFarmers:["Ramesh Patil · Nashik FPO","Suresh Yadav · UP Kisan"],
  buyerRating:4.6, buyerVerified:true,
  joinedDate:"3 Mar 2024", lastSync: new Date().toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit"}),
};

const STORAGE_KEY = "kisansetu_profile_v2";

function loadSaved(): { profile: UserProfile | null; step: string } {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) { const d = JSON.parse(raw); return { profile: d.profile, step: d.step || "loggedin" }; }
  } catch {}
  return { profile: null, step: "landing" };
}

function saveToStorage(profile: UserProfile, step: string) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify({ profile, step, ts: Date.now() })); } catch {}
}

// ── Star rating display ────────────────────────────────────────────────────
function StarRow({ rating, max=5, size=14 }: { rating: number; max?: number; size?: number }) {
  return (
    <span className="flex items-center gap-0.5">
      {Array.from({length: max}).map((_,i) => (
        <svg key={i} width={size} height={size} viewBox="0 0 24 24" fill={i < Math.round(rating) ? "#e8b535" : "#e8e3d8"}>
          <polygon points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26"/>
        </svg>
      ))}
      <span className="text-[10px] font-mono text-[#7c5c32] ml-1">{rating.toFixed(1)}</span>
    </span>
  );
}

// ── Badge chip ─────────────────────────────────────────────────────────────
function ProfileBadge({ icon, label, color }: { icon: string; label: string; color: string }) {
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono font-semibold border"
      style={{ background: color+"22", borderColor: color+"55", color }}>
      {icon} {label}
    </span>
  );
}

// ── Sync indicator ─────────────────────────────────────────────────────────
function SyncBadge({ time }: { time: string }) {
  return (
    <span className="inline-flex items-center gap-1 text-[10px] font-mono text-[#4a7c59]">
      <span className="w-1.5 h-1.5 rounded-full bg-[#4ade80]"/>
      Synced {time}
    </span>
  );
}

function ProfileView() {
  const saved = loadSaved();
  const [authStep,    setAuthStep]    = useState<"landing"|"login"|"register"|"otp"|"loggedin">(saved.step as any || "landing");
  const [accountType, setAccountType] = useState<AccountType>(saved.profile?.accountType || "farmer");
  const [phone,       setPhone]       = useState("");
  const [email,       setEmail]       = useState("");
  const [password,    setPassword]    = useState("");
  const [confirmPw,   setConfirmPw]   = useState("");
  const [otp,         setOtp]         = useState("");
  const [pwVisible,   setPwVisible]   = useState(false);
  const [authError,   setAuthError]   = useState("");
  const [profileTab,  setProfileTab]  = useState<string>("portfolio");
  const [saving,      setSaving]      = useState(false);
  const [saved2,      setSaved2]      = useState(false);
  const [editMode,    setEditMode]    = useState(false);
  const [profile,     setProfile]     = useState<UserProfile>(saved.profile || { ...DEMO_FARMER, name:"" });

  const isFarmer = accountType === "farmer";

  function upd(k: keyof UserProfile, v: string) {
    setProfile(p => { const n={...p,[k]:v}; saveToStorage(n,"loggedin"); return n; });
  }

  function sendOtp() {
    if (!phone.match(/^\d{10}$/)) { setAuthError("Enter a valid 10-digit mobile number"); return; }
    setAuthError("");
    // auto-save partial registration data locally
    const partial = { ...profile, phone, email, accountType };
    saveToStorage(partial, "register");
    setAuthStep("otp");
  }

  function verifyOtp() {
    if (otp !== "1234") { setAuthError("Incorrect OTP · Demo code is 1234"); return; }
    setAuthError("");
    const base = accountType === "farmer" ? DEMO_FARMER : DEMO_BUYER;
    const merged: UserProfile = {
      ...base,
      name: profile.name || base.name,
      phone, email, accountType, password,
      lastSync: new Date().toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit"}),
    };
    setProfile(merged);
    saveToStorage(merged, "loggedin");
    setAuthStep("loggedin");
  }

  function handleLogin() {
    if (!phone && !email) { setAuthError("Enter your mobile number or email"); return; }
    if (!password) { setAuthError("Enter your password"); return; }
    const base = accountType === "farmer" ? DEMO_FARMER : DEMO_BUYER;
    const merged = { ...base, phone: phone || base.phone, email: email || base.email, accountType,
      lastSync: new Date().toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit"}) };
    setProfile(merged);
    saveToStorage(merged, "loggedin");
    setAuthStep("loggedin");
  }

  function handleRegister() {
    if (!profile.name) { setAuthError("Enter your full name"); return; }
    if (!phone.match(/^\d{10}$/)) { setAuthError("Enter a valid 10-digit mobile"); return; }
    if (password.length < 6) { setAuthError("Password must be at least 6 characters"); return; }
    if (password !== confirmPw) { setAuthError("Passwords do not match"); return; }
    setAuthError("");
    sendOtp();
  }

  function saveProfile() {
    setSaving(true);
    const updated = { ...profile, lastSync: new Date().toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit"}) };
    setTimeout(() => {
      setProfile(updated);
      saveToStorage(updated, "loggedin");
      setSaving(false); setSaved2(true); setEditMode(false);
      setTimeout(() => setSaved2(false), 2500);
    }, 1000);
  }

  function signOut() {
    localStorage.removeItem(STORAGE_KEY);
    setAuthStep("landing"); setProfile({ ...DEMO_FARMER, name:"" }); setPhone(""); setEmail(""); setPassword(""); setOtp("");
  }

  // ── Shared field component ─────────────────────────────────────────────
  function Field({ label, value, onChange, placeholder, type="text", mono=false }: {
    label:string; value:string; onChange:(v:string)=>void;
    placeholder?:string; type?:string; mono?:boolean;
  }) {
    return (
      <div>
        <label className="block text-[11px] font-mono font-bold text-[#7c5c32] uppercase tracking-wider mb-1.5">{label}</label>
        <input type={type} value={value} onChange={e=>onChange(e.target.value)}
          disabled={!editMode} placeholder={placeholder || label}
          className={`w-full border rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-[#1e4d2b] transition-colors disabled:bg-[#faf9f6] disabled:text-[#4a4a2e] ${mono?"font-mono":""}`}
          style={{ borderColor: editMode ? "#d0cbbf" : "#f0ebe0" }}/>
      </div>
    );
  }

  // ══════════════════════════════════════════════════════════════════════
  // AUTH SCREENS
  // ══════════════════════════════════════════════════════════════════════
  if (authStep === "landing") return (
    <div className="max-w-2xl mx-auto">
      <div className="text-center mb-10">
        <div className="w-20 h-20 rounded-3xl bg-[#1e4d2b] flex items-center justify-center text-4xl mx-auto mb-5 shadow-lg">👤</div>
        <h2 className="text-3xl font-bold text-[#1a1a0e] mb-2" style={{fontFamily:"var(--font-display)"}}>Your Kisansetu Account</h2>
        <p className="text-[#7c5c32] text-sm leading-relaxed max-w-md mx-auto">
          Create a portfolio to showcase your produce, save your preferences, track orders — your data is always safe and synced to your phone number.
        </p>
      </div>
      <div className="grid grid-cols-2 gap-4 mb-8">
        {([
          ["farmer","🌾","Farmer / FPO","List crops, track payments, build a verified seller portfolio. Your history stays tied to your mobile number."],
          ["buyer","🏪","Buyer / Retailer","Save search filters, manage sourcing requirements, track purchase history and farmer ratings."],
        ] as const).map(([type,icon,title,desc])=>(
          <button key={type} onClick={()=>setAccountType(type)}
            className={`p-6 rounded-2xl border-2 text-left transition-all ${accountType===type?"border-[#1e4d2b] bg-[#d6f0de]":"border-[#e8e3d8] bg-white hover:border-[#4a7c59]"}`}>
            <div className="text-3xl mb-3">{icon}</div>
            <div className="font-semibold text-[#1a1a0e] mb-1">{title}</div>
            <div className="text-xs text-[#7c5c32] leading-relaxed">{desc}</div>
            {accountType===type && <div className="mt-3 text-[#1e4d2b] text-xs font-semibold font-mono">✓ Selected</div>}
          </button>
        ))}
      </div>
      <div className="flex gap-3 mb-5">
        <button onClick={()=>setAuthStep("login")}
          className="flex-1 bg-[#1e4d2b] text-white py-3.5 rounded-2xl font-semibold text-sm hover:bg-[#2d6b3e] transition-colors">
          Sign In to My Account
        </button>
        <button onClick={()=>setAuthStep("register")}
          className="flex-1 border-2 border-[#1e4d2b] text-[#1e4d2b] py-3.5 rounded-2xl font-semibold text-sm hover:bg-[#d6f0de] transition-colors">
          Create New Account
        </button>
      </div>
      {/* Quick demo login */}
      <div className="bg-[#fffbf0] border border-[#e8d890] rounded-2xl p-4">
        <p className="text-xs font-mono text-[#a77c3e] mb-3">⚡ Demo — log in instantly to see the full profile experience:</p>
        <div className="flex gap-2">
          <button onClick={()=>{ setAccountType("farmer"); setPhone("9876543210"); setPassword("demo123");
            const m={...DEMO_FARMER,lastSync:new Date().toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit"})};
            setProfile(m); saveToStorage(m,"loggedin"); setAuthStep("loggedin"); }}
            className="flex-1 py-2 rounded-xl bg-[#1e4d2b]/10 border border-[#1e4d2b]/30 text-[#1e4d2b] text-xs font-semibold hover:bg-[#1e4d2b]/20 transition-colors">
            🌾 Demo Farmer
          </button>
          <button onClick={()=>{ setAccountType("buyer"); setPhone("9123456780"); setPassword("demo123");
            const m={...DEMO_BUYER,lastSync:new Date().toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit"})};
            setProfile(m); saveToStorage(m,"loggedin"); setAuthStep("loggedin"); }}
            className="flex-1 py-2 rounded-xl bg-[#7c5c32]/10 border border-[#7c5c32]/30 text-[#7c5c32] text-xs font-semibold hover:bg-[#7c5c32]/20 transition-colors">
            🏪 Demo Buyer
          </button>
        </div>
      </div>
      <p className="text-center text-xs text-[#a77c3e] mt-4 font-mono">
        🔒 Data tied to your verified phone number · End-to-end encrypted · Works offline
      </p>
    </div>
  );

  if (authStep === "login") return (
    <div className="max-w-md mx-auto">
      <button onClick={()=>setAuthStep("landing")} className="flex items-center gap-1.5 text-sm text-[#7c5c32] hover:text-[#1e4d2b] mb-6 transition-colors">← Back</button>
      <div className="bg-white border border-[#e8e3d8] rounded-3xl p-8 shadow-sm">
        <div className="text-center mb-7">
          <div className="text-4xl mb-3">{isFarmer?"🌾":"🏪"}</div>
          <h3 className="text-2xl font-bold text-[#1a1a0e]" style={{fontFamily:"var(--font-display)"}}>Welcome back</h3>
          <p className="text-sm text-[#7c5c32] mt-1">Sign in as {isFarmer?"Farmer / FPO":"Buyer / Retailer"}</p>
        </div>
        <div className="space-y-4">
          <div>
            <label className="block text-[11px] font-mono font-bold text-[#7c5c32] uppercase tracking-wider mb-1.5">Mobile or Email</label>
            <input value={phone||email} onChange={e=>{ const v=e.target.value; v.match(/^\d+$/) ? setPhone(v) : setEmail(v); }}
              placeholder="9876543210 or name@example.com"
              className="w-full border border-[#e8e3d8] rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[#1e4d2b] font-mono"/>
          </div>
          <div>
            <label className="block text-[11px] font-mono font-bold text-[#7c5c32] uppercase tracking-wider mb-1.5">Password</label>
            <div className="relative">
              <input type={pwVisible?"text":"password"} value={password} onChange={e=>setPassword(e.target.value)}
                placeholder="Your password"
                className="w-full border border-[#e8e3d8] rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[#1e4d2b] pr-16"/>
              <button type="button" onClick={()=>setPwVisible(!pwVisible)} className="absolute right-4 top-1/2 -translate-y-1/2 text-xs text-[#7c5c32]">{pwVisible?"Hide":"Show"}</button>
            </div>
          </div>
          {authError && <p className="text-xs text-red-600 bg-red-50 border border-red-200 rounded-xl px-3 py-2">{authError}</p>}
          <button onClick={handleLogin} className="w-full bg-[#1e4d2b] text-white py-3.5 rounded-2xl font-semibold text-sm hover:bg-[#2d6b3e] transition-colors mt-1">Sign In</button>
          <div className="text-center">
            <button onClick={()=>{setAuthStep("otp"); setOtp("");}} className="text-xs text-[#1e4d2b] underline underline-offset-2">Sign in with OTP instead</button>
          </div>
        </div>
      </div>
      <p className="text-center text-xs text-[#a77c3e] mt-4">No account? <button onClick={()=>setAuthStep("register")} className="text-[#1e4d2b] font-semibold underline underline-offset-2">Create one free</button></p>
    </div>
  );

  if (authStep === "register") return (
    <div className="max-w-md mx-auto">
      <button onClick={()=>setAuthStep("landing")} className="flex items-center gap-1.5 text-sm text-[#7c5c32] hover:text-[#1e4d2b] mb-6 transition-colors">← Back</button>
      <div className="bg-white border border-[#e8e3d8] rounded-3xl p-8 shadow-sm">
        <div className="text-center mb-7">
          <div className="text-4xl mb-3">{isFarmer?"🌾":"🏪"}</div>
          <h3 className="text-2xl font-bold text-[#1a1a0e]" style={{fontFamily:"var(--font-display)"}}>Create Account</h3>
          <p className="text-sm text-[#7c5c32] mt-1">{isFarmer?"Farmer / FPO":"Buyer / Retailer"} · Free forever · Data never lost</p>
        </div>
        <div className="space-y-4">
          <div>
            <label className="block text-[11px] font-mono font-bold text-[#7c5c32] uppercase tracking-wider mb-1.5">Full Name</label>
            <input value={profile.name} onChange={e=>setProfile(p=>({...p,name:e.target.value}))} placeholder={isFarmer?"e.g. Ramesh Patil":"e.g. Kavita Sharma"}
              className="w-full border border-[#e8e3d8] rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[#1e4d2b]"/>
          </div>
          <div>
            <label className="block text-[11px] font-mono font-bold text-[#7c5c32] uppercase tracking-wider mb-1.5">Mobile Number</label>
            <div className="flex gap-2">
              <span className="flex items-center px-3 bg-[#f5f0e8] border border-[#e8e3d8] rounded-xl text-sm text-[#7c5c32] font-mono">+91</span>
              <input value={phone} onChange={e=>setPhone(e.target.value.replace(/\D/,"").slice(0,10))} placeholder="10-digit mobile" maxLength={10}
                className="flex-1 border border-[#e8e3d8] rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[#1e4d2b] font-mono"/>
            </div>
            <p className="text-[10px] font-mono text-[#a77c3e] mt-1">Your data is permanently tied to this number — never lost even if you change phones.</p>
          </div>
          <div>
            <label className="block text-[11px] font-mono font-bold text-[#7c5c32] uppercase tracking-wider mb-1.5">Email <span className="font-normal normal-case text-[#a77c3e]">(optional)</span></label>
            <input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="name@example.com"
              className="w-full border border-[#e8e3d8] rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[#1e4d2b]"/>
          </div>
          <div>
            <label className="block text-[11px] font-mono font-bold text-[#7c5c32] uppercase tracking-wider mb-1.5">Password <span className="font-normal normal-case text-[#a77c3e]">(min 6 chars)</span></label>
            <div className="relative">
              <input type={pwVisible?"text":"password"} value={password} onChange={e=>setPassword(e.target.value)} placeholder="Create a password"
                className="w-full border border-[#e8e3d8] rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[#1e4d2b] pr-16"/>
              <button type="button" onClick={()=>setPwVisible(!pwVisible)} className="absolute right-4 top-1/2 -translate-y-1/2 text-xs text-[#7c5c32]">{pwVisible?"Hide":"Show"}</button>
            </div>
          </div>
          <div>
            <label className="block text-[11px] font-mono font-bold text-[#7c5c32] uppercase tracking-wider mb-1.5">Confirm Password</label>
            <input type="password" value={confirmPw} onChange={e=>setConfirmPw(e.target.value)} placeholder="Re-enter password"
              className="w-full border border-[#e8e3d8] rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[#1e4d2b]"/>
          </div>
          {authError && <p className="text-xs text-red-600 bg-red-50 border border-red-200 rounded-xl px-3 py-2">{authError}</p>}
          <button onClick={handleRegister} className="w-full bg-[#1e4d2b] text-white py-3.5 rounded-2xl font-semibold text-sm hover:bg-[#2d6b3e] transition-colors">Send OTP & Continue →</button>
          <p className="text-[10px] text-center text-[#a77c3e] font-mono">4-digit OTP will be sent to verify your mobile number.</p>
        </div>
      </div>
      <p className="text-center text-xs text-[#a77c3e] mt-4">Already registered? <button onClick={()=>setAuthStep("login")} className="text-[#1e4d2b] font-semibold underline underline-offset-2">Sign in</button></p>
    </div>
  );

  if (authStep === "otp") return (
    <div className="max-w-sm mx-auto text-center">
      <button onClick={()=>setAuthStep("register")} className="flex items-center gap-1.5 text-sm text-[#7c5c32] hover:text-[#1e4d2b] mb-6 mx-auto transition-colors">← Back</button>
      <div className="bg-white border border-[#e8e3d8] rounded-3xl p-8 shadow-sm">
        <div className="text-5xl mb-4">📱</div>
        <h3 className="text-xl font-bold text-[#1a1a0e] mb-2" style={{fontFamily:"var(--font-display)"}}>Verify your mobile</h3>
        <p className="text-sm text-[#7c5c32] mb-1">OTP sent to <span className="font-mono font-semibold">+91 {phone}</span></p>
        <p className="text-xs text-[#a77c3e] mb-6 font-mono">Demo: enter 1234</p>
        <div className="flex gap-3 justify-center mb-6">
          {[0,1,2,3].map(i=>(
            <input key={i} type="text" maxLength={1} value={otp[i]||""} inputMode="numeric"
              onChange={e=>{ const v=e.target.value.replace(/\D/,""); const arr=otp.split(""); arr[i]=v; setOtp(arr.join("").slice(0,4));
                if(v&&i<3)(document.querySelectorAll("[data-otp]")[i+1] as HTMLInputElement)?.focus(); }}
              data-otp className="w-14 h-14 border-2 border-[#e8e3d8] rounded-2xl text-center text-2xl font-mono font-bold focus:outline-none focus:border-[#1e4d2b] transition-colors"
              style={{borderColor: otp[i]?"#1e4d2b":undefined}}/>
          ))}
        </div>
        {authError && <p className="text-xs text-red-600 bg-red-50 border border-red-200 rounded-xl px-3 py-2 mb-4">{authError}</p>}
        <button onClick={verifyOtp} disabled={otp.length<4}
          className="w-full bg-[#1e4d2b] text-white py-3.5 rounded-2xl font-semibold text-sm hover:bg-[#2d6b3e] transition-colors disabled:opacity-50">
          Verify & Activate Account
        </button>
        <button onClick={()=>setOtp("")} className="mt-3 text-xs text-[#1e4d2b] underline underline-offset-2">Resend OTP</button>
      </div>
    </div>
  );

  // ══════════════════════════════════════════════════════════════════════
  // LOGGED IN — FULL DASHBOARD
  // ══════════════════════════════════════════════════════════════════════
  const farmerTabs = ["portfolio","history","financial","account","security"];
  const buyerTabs  = ["portfolio","requirements","purchases","preferences","account","security"];
  const tabs = isFarmer ? farmerTabs : buyerTabs;
  if (!tabs.includes(profileTab)) setProfileTab("portfolio");

  const farmerStats = [
    {label:"Crops Listed",    value: String(profile.crops.length || 3), icon:"🌱"},
    {label:"Completed Sales", value: String(profile.sales.length || 3), icon:"📦"},
    {label:"Avg Rating",      value: profile.sales.length ? (profile.sales.reduce((a,s)=>a+s.rating,0)/profile.sales.length).toFixed(1)+" ★" : "—", icon:"⭐"},
    {label:"Trust Score",     value: profile.badgeTopSeller ? "Top Seller" : "Growing", icon:"🏆"},
  ];
  const buyerStats = [
    {label:"Active Requirements", value: String(profile.requirements.filter(r=>r.status==="Active").length), icon:"📋"},
    {label:"Purchases Made",      value: String(profile.purchases.length),                                    icon:"📦"},
    {label:"Buyer Rating",        value: profile.buyerRating ? profile.buyerRating.toFixed(1)+" ★" : "—",    icon:"⭐"},
    {label:"Monthly Volume",      value: profile.monthlyVolume ? profile.monthlyVolume+" MT" : "—",           icon:"🚛"},
  ];
  const stats = isFarmer ? farmerStats : buyerStats;

  const tabLabels: Record<string,string> = {
    portfolio:"Portfolio", history:"Sales History", financial:"Financial Hub",
    requirements:"Requirements", purchases:"Purchase History", preferences:"Preferences",
    account:"Account", security:"Security",
  };

  return (
    <div className="max-w-5xl mx-auto">

      {/* ── Hero Banner ── */}
      <div className="relative rounded-3xl overflow-hidden mb-6" style={{background:"linear-gradient(135deg,#0f2d15 0%,#1e4d2b 50%,#2a6035 100%)", minHeight:190}}>
        <div className="absolute inset-0 opacity-10" style={{backgroundImage:"url(https://images.unsplash.com/photo-1595434730960-fe4b5e925688?w=900&h=300&fit=crop&auto=format)",backgroundSize:"cover",backgroundPosition:"center"}}/>
        <div className="relative p-6 flex items-end gap-5 flex-wrap" style={{minHeight:190,alignItems:"flex-end"}}>
          <div className="w-20 h-20 rounded-2xl border-4 border-white/20 flex items-center justify-center text-4xl flex-shrink-0"
            style={{background:"rgba(255,255,255,0.15)",backdropFilter:"blur(8px)"}}>
            {isFarmer?"🌾":"🏪"}
          </div>
          <div className="flex-1 min-w-0 text-white pb-1">
            <div className="flex items-center gap-2 flex-wrap mb-1.5">
              <h2 className="text-2xl font-bold" style={{fontFamily:"var(--font-display)"}}>{profile.name}</h2>
              <ProfileBadge icon={isFarmer?"🌾":"🏪"} label={isFarmer?"Farmer / FPO":"Buyer / Retailer"} color="#a3e635"/>
              {(profile.badgeVerified || profile.buyerVerified) && <ProfileBadge icon="✓" label="Verified" color="#4ade80"/>}
              {profile.badgeTopSeller && <ProfileBadge icon="🏆" label="Top Seller" color="#fbbf24"/>}
            </div>
            <p className="text-sm text-white/60 font-mono mb-1">
              {isFarmer ? `${profile.fpoName || "Independent"} · ${profile.district || ""}${profile.state ? ", "+profile.state : ""}` : `${profile.orgName} · ${profile.orgType}`}
            </p>
            <p className="text-xs text-white/40 font-mono">Member since {profile.joinedDate}</p>
          </div>
          <div className="flex flex-col items-end gap-2 pb-1">
            <SyncBadge time={profile.lastSync}/>
            <div className="flex gap-2">
              {!editMode ? (
                <button onClick={()=>setEditMode(true)}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white/10 border border-white/20 text-white text-sm font-semibold hover:bg-white/20 transition-colors">
                  ✏️ Edit Profile
                </button>
              ) : (
                <>
                  <button onClick={saveProfile} disabled={saving}
                    className="px-4 py-2 rounded-xl bg-[#e8b535] text-[#0d1a04] text-sm font-bold hover:bg-[#fbbf24] transition-colors disabled:opacity-60">
                    {saving?"Saving…":saved2?"✓ Saved!":"💾 Save"}
                  </button>
                  <button onClick={()=>setEditMode(false)}
                    className="px-3 py-2 rounded-xl bg-white/10 border border-white/20 text-white text-sm hover:bg-white/20 transition-colors">Cancel</button>
                </>
              )}
              <button onClick={signOut}
                className="px-4 py-2 rounded-xl bg-red-500/20 border border-red-400/30 text-red-300 text-sm hover:bg-red-500/30 transition-colors">Sign Out</button>
            </div>
          </div>
        </div>
      </div>

      {/* ── Stat bar ── */}
      <div className="grid grid-cols-4 gap-3 mb-6">
        {stats.map(s=>(
          <div key={s.label} className="bg-white border border-[#e8e3d8] rounded-2xl p-4 text-center">
            <div className="text-xl mb-1">{s.icon}</div>
            <div className="font-bold font-mono text-[#1e4d2b] text-sm">{s.value}</div>
            <div className="text-[10px] text-[#7c5c32] font-mono mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>

      {/* ── Tab bar ── */}
      <div className="flex gap-1 bg-[#f0ebe0] rounded-xl p-1 mb-6 overflow-x-auto">
        {tabs.map(t=>(
          <button key={t} onClick={()=>setProfileTab(t)}
            className={`whitespace-nowrap px-3 py-2 rounded-lg text-xs font-medium transition-all flex-shrink-0 ${profileTab===t?"bg-white text-[#1e4d2b] shadow-sm":"text-[#7c5c32] hover:text-[#1e4d2b]"}`}>
            {tabLabels[t]}
          </button>
        ))}
      </div>

      {/* ════════════════ FARMER PORTFOLIO ════════════════ */}
      {profileTab==="portfolio" && isFarmer && (
        <div className="space-y-5">
          {/* Crops grid */}
          <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold" style={{fontFamily:"var(--font-display)"}}>🌾 Crops I Grow</h3>
              <span className="text-xs font-mono text-[#7c5c32]">{profile.crops.length} crops</span>
            </div>
            <div className="grid grid-cols-3 gap-3 mb-4">
              {profile.crops.map((c,i)=>(
                <div key={i} className="rounded-xl overflow-hidden border border-[#e8e3d8]">
                  <img src={c.photo} alt={c.name} className="w-full h-24 object-cover"/>
                  <div className="p-2">
                    <p className="text-xs font-semibold text-[#1a1a0e]">{c.name}</p>
                    <p className="text-[10px] font-mono text-[#7c5c32]">{c.acreage} acres · {c.season}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="grid sm:grid-cols-2 gap-4 pt-4 border-t border-[#f0ebe0]">
              <Field label="Primary Crops" value={profile.primaryCrops} onChange={v=>upd("primaryCrops",v)} placeholder="Tomato, Onion, Grapes"/>
              <Field label="Land Holding (acres)" value={profile.landAcres} onChange={v=>upd("landAcres",v)} placeholder="e.g. 4.5"/>
            </div>
          </div>
          {/* Farm details */}
          <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6">
            <h3 className="font-semibold mb-4" style={{fontFamily:"var(--font-display)"}}>📍 Farm Location</h3>
            <div className="grid sm:grid-cols-2 gap-4">
              <Field label="Village / Town" value={profile.village} onChange={v=>upd("village",v)}/>
              <Field label="District" value={profile.district} onChange={v=>upd("district",v)}/>
              <div>
                <label className="block text-[11px] font-mono font-bold text-[#7c5c32] uppercase tracking-wider mb-1.5">State</label>
                <select value={profile.state} onChange={e=>upd("state",e.target.value)} disabled={!editMode}
                  className="w-full border rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-[#1e4d2b] disabled:bg-[#faf9f6] disabled:text-[#4a4a2e]"
                  style={{borderColor:editMode?"#d0cbbf":"#f0ebe0"}}>
                  {INDIAN_STATES.map(s=><option key={s}>{s}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-[11px] font-mono font-bold text-[#7c5c32] uppercase tracking-wider mb-1.5">Preferred Language</label>
                <select value={profile.preferredLang} onChange={e=>upd("preferredLang",e.target.value)} disabled={!editMode}
                  className="w-full border rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-[#1e4d2b] disabled:bg-[#faf9f6] disabled:text-[#4a4a2e]"
                  style={{borderColor:editMode?"#d0cbbf":"#f0ebe0"}}>
                  {LANGUAGES.map(l=><option key={l}>{l}</option>)}
                </select>
              </div>
              <Field label="FPO / Cooperative Name" value={profile.fpoName} onChange={v=>upd("fpoName",v)} placeholder="Nashik FPO Ltd."/>
            </div>
          </div>
          {/* Payment */}
          <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6">
            <h3 className="font-semibold mb-4" style={{fontFamily:"var(--font-display)"}}>🏦 Payment Details</h3>
            <div className="grid sm:grid-cols-2 gap-4">
              <Field label="Bank Name" value={profile.bankName} onChange={v=>upd("bankName",v)}/>
              <Field label="UPI ID" value={profile.upiId} onChange={v=>upd("upiId",v)} placeholder="name@upi" mono/>
            </div>
            {!editMode && <p className="text-xs text-[#a77c3e] mt-3 font-mono">🔒 Encrypted · Only you can see this · Used for escrow release payments</p>}
          </div>
        </div>
      )}

      {/* ════════════════ FARMER HISTORY ════════════════ */}
      {profileTab==="history" && isFarmer && (
        <div className="space-y-5">
          <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6">
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-semibold" style={{fontFamily:"var(--font-display)"}}>📦 Sales History</h3>
              <span className="text-xs font-mono bg-[#1e4d2b]/10 text-[#1e4d2b] px-2.5 py-1 rounded-full">{profile.sales.length} transactions</span>
            </div>
            <div className="space-y-3">
              {profile.sales.map(s=>(
                <div key={s.id} className="flex items-center gap-4 p-4 rounded-xl border border-[#f0ebe0] hover:border-[#d0cbbf] transition-colors">
                  <div className="w-10 h-10 rounded-xl bg-[#d6f0de] flex items-center justify-center text-xl flex-shrink-0">🌱</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-semibold text-sm text-[#1a1a0e]">{s.crop}</span>
                      <span className="text-[10px] font-mono bg-[#4ade80]/20 text-[#166534] px-2 py-0.5 rounded-full border border-[#4ade80]/30">{s.status}</span>
                    </div>
                    <p className="text-xs text-[#7c5c32]">{s.qty} · {s.price} · {s.buyer}</p>
                    <p className="text-[10px] font-mono text-[#a77c3e] mt-0.5">{s.date}</p>
                  </div>
                  <StarRow rating={s.rating}/>
                </div>
              ))}
            </div>
            {/* Aggregate */}
            <div className="mt-5 pt-5 border-t border-[#f0ebe0] grid grid-cols-3 gap-3">
              {[
                {label:"Avg Price Received", value:"₹58/kg", icon:"💰"},
                {label:"Avg Buyer Rating", value:(profile.sales.reduce((a,s)=>a+s.rating,0)/Math.max(profile.sales.length,1)).toFixed(1)+" ★", icon:"⭐"},
                {label:"Total Volume Sold", value:"7.3 MT", icon:"📦"},
              ].map(m=>(
                <div key={m.label} className="text-center p-3 bg-[#faf9f5] rounded-xl">
                  <div className="text-lg mb-1">{m.icon}</div>
                  <div className="font-bold font-mono text-[#1e4d2b] text-sm">{m.value}</div>
                  <div className="text-[10px] text-[#7c5c32] font-mono mt-0.5">{m.label}</div>
                </div>
              ))}
            </div>
          </div>
          {/* Trust badges */}
          <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6">
            <h3 className="font-semibold mb-4" style={{fontFamily:"var(--font-display)"}}>🏆 Trust & Achievement Badges</h3>
            <div className="flex flex-wrap gap-3">
              {[
                {icon:"✓",  label:"Verified Farmer",   desc:"Identity confirmed by FPO",               unlocked:profile.badgeVerified},
                {icon:"🏆", label:"Top Seller",         desc:"Completed 10+ orders with 4★+ avg",       unlocked:profile.badgeTopSeller},
                {icon:"⚡", label:"Fast Responder",     desc:"Responds to buyer queries within 2 hours", unlocked:true},
                {icon:"🌱", label:"Organic Certified",  desc:"Verified organic produce documentation",   unlocked:false},
                {icon:"💰", label:"Escrow Champion",    desc:"All payments via secure escrow",           unlocked:true},
                {icon:"📦", label:"Zero Rejection",     desc:"No quality rejections in last 6 months",  unlocked:false},
              ].map(b=>(
                <div key={b.label} className={`flex items-start gap-3 p-3 rounded-xl border flex-1 min-w-[200px] ${b.unlocked?"border-[#1e4d2b]/30 bg-[#d6f0de]/50":"border-[#e8e3d8] bg-[#faf9f5] opacity-50"}`}>
                  <span className="text-2xl">{b.icon}</span>
                  <div>
                    <p className="text-xs font-semibold text-[#1a1a0e]">{b.label}</p>
                    <p className="text-[10px] text-[#7c5c32] mt-0.5">{b.desc}</p>
                    <p className="text-[9px] font-mono text-[#a77c3e] mt-1">{b.unlocked?"✓ Earned":"🔒 Not yet unlocked"}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ════════════════ FARMER FINANCIAL HUB ════════════════ */}
      {profileTab==="financial" && isFarmer && (
        <div className="space-y-5">
          {/* Scheme status */}
          <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6">
            <h3 className="font-semibold mb-4" style={{fontFamily:"var(--font-display)"}}>🏛️ Government Schemes Status</h3>
            <div className="space-y-3">
              {[
                {label:"Kisan Credit Card (KCC)", value:profile.kccStatus, icon:"💳", color:"#1e4d2b"},
                {label:"PM-KISAN Samman Nidhi",   value:profile.pmKisanStatus, icon:"🏛️", color:"#c8941a"},
                {label:"Warehouse Financing",      value:profile.loanStatus,    icon:"🏭", color:"#4a7c59"},
              ].map(s=>(
                <div key={s.label} className="flex items-center gap-4 p-4 rounded-xl border border-[#f0ebe0]">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl flex-shrink-0" style={{background:s.color+"20"}}>{s.icon}</div>
                  <div className="flex-1">
                    <p className="text-xs font-mono text-[#7c5c32] mb-0.5">{s.label}</p>
                    <p className="text-sm font-semibold text-[#1a1a0e]">{s.value}</p>
                  </div>
                  <span className="text-[10px] font-mono text-[#4a7c59] bg-[#d6f0de] px-2 py-0.5 rounded-full">Active</span>
                </div>
              ))}
            </div>
          </div>
          {/* Payment history */}
          <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6">
            <h3 className="font-semibold mb-4" style={{fontFamily:"var(--font-display)"}}>💰 Payment History</h3>
            <div className="space-y-2">
              {[
                {date:"12 Aug 2024", desc:"Tomato sale — BigBasket", amount:"+₹1,30,000", type:"credit"},
                {date:"3 Jul 2024",  desc:"Onion sale — Reliance Fresh", amount:"+₹1,12,000", type:"credit"},
                {date:"1 Jul 2024",  desc:"KCC interest payment", amount:"−₹3,200", type:"debit"},
                {date:"20 Jun 2024", desc:"Grapes export — Star Exports", amount:"+₹76,000", type:"credit"},
                {date:"5 Jun 2024",  desc:"Warehouse storage fee", amount:"−₹1,800", type:"debit"},
              ].map((p,i)=>(
                <div key={i} className="flex items-center justify-between p-3 rounded-xl hover:bg-[#faf9f5] transition-colors">
                  <div>
                    <p className="text-xs font-semibold text-[#1a1a0e]">{p.desc}</p>
                    <p className="text-[10px] font-mono text-[#a77c3e]">{p.date}</p>
                  </div>
                  <span className={`text-sm font-mono font-bold ${p.type==="credit"?"text-[#166534]":"text-red-600"}`}>{p.amount}</span>
                </div>
              ))}
            </div>
            <div className="mt-4 pt-4 border-t border-[#f0ebe0] flex items-center justify-between">
              <span className="text-xs font-mono text-[#7c5c32]">Net this season</span>
              <span className="text-base font-bold font-mono text-[#1e4d2b]">+₹3,13,000</span>
            </div>
          </div>
          {/* Apply for credit */}
          <div className="bg-gradient-to-r from-[#0f2d15] to-[#1e4d2b] rounded-2xl p-6 text-white">
            <h3 className="font-semibold mb-2" style={{fontFamily:"var(--font-display)"}}>🚀 Explore More Financing</h3>
            <p className="text-sm text-white/70 mb-4">Based on your 3 successful sales and 4.8★ rating, you qualify for additional credit options.</p>
            <div className="flex gap-2 flex-wrap">
              {["Crop Insurance","Input Credit","Warehouse Receipt Loan","FPO Equity Scheme"].map(s=>(
                <button key={s} className="px-3 py-1.5 rounded-xl bg-white/10 border border-white/20 text-xs font-mono hover:bg-white/20 transition-colors">{s}</button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ════════════════ BUYER PORTFOLIO ════════════════ */}
      {profileTab==="portfolio" && !isFarmer && (
        <div className="space-y-5">
          <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6">
            <h3 className="font-semibold mb-4" style={{fontFamily:"var(--font-display)"}}>🏪 Organisation Details</h3>
            <div className="grid sm:grid-cols-2 gap-4">
              <Field label="Organisation Name" value={profile.orgName} onChange={v=>upd("orgName",v)} placeholder="BigBasket Wholesale"/>
              <div>
                <label className="block text-[11px] font-mono font-bold text-[#7c5c32] uppercase tracking-wider mb-1.5">Organisation Type</label>
                <select value={profile.orgType} onChange={e=>upd("orgType",e.target.value)} disabled={!editMode}
                  className="w-full border rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-[#1e4d2b] disabled:bg-[#faf9f6]"
                  style={{borderColor:editMode?"#d0cbbf":"#f0ebe0"}}>
                  {["Retailer","Wholesaler","Supermarket Chain","Processor","Exporter","Restaurant Chain","Government Agency","NGO"].map(o=><option key={o}>{o}</option>)}
                </select>
              </div>
              <Field label="Contact Person" value={profile.contactPerson} onChange={v=>upd("contactPerson",v)}/>
              <Field label="GST Number" value={profile.gst} onChange={v=>upd("gst",v)} placeholder="22AAAAA0000A1Z5" mono/>
              <Field label="Primary Delivery City" value={profile.deliveryCity} onChange={v=>upd("deliveryCity",v)}/>
              <div>
                <label className="block text-[11px] font-mono font-bold text-[#7c5c32] uppercase tracking-wider mb-1.5">Preferred Language</label>
                <select value={profile.preferredLang} onChange={e=>upd("preferredLang",e.target.value)} disabled={!editMode}
                  className="w-full border rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-[#1e4d2b] disabled:bg-[#faf9f6]"
                  style={{borderColor:editMode?"#d0cbbf":"#f0ebe0"}}>
                  {LANGUAGES.map(l=><option key={l}>{l}</option>)}
                </select>
              </div>
              <Field label="Preferred Crops" value={profile.preferredCrops} onChange={v=>upd("preferredCrops",v)} placeholder="Tomato, Potato, Onion"/>
              <Field label="Monthly Volume (MT)" value={profile.monthlyVolume} onChange={v=>upd("monthlyVolume",v)}/>
            </div>
          </div>
          {/* Buyer trust */}
          <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6">
            <h3 className="font-semibold mb-4" style={{fontFamily:"var(--font-display)"}}>🏆 Buyer Trust Profile</h3>
            <div className="flex items-center gap-6 mb-5">
              <div className="text-center">
                <div className="text-4xl font-bold font-mono text-[#1e4d2b] mb-1">{profile.buyerRating.toFixed(1)}</div>
                <StarRow rating={profile.buyerRating} size={16}/>
                <p className="text-[10px] font-mono text-[#7c5c32] mt-1">Given by farmers</p>
              </div>
              <div className="flex-1 space-y-2">
                {[
                  {label:"Payment Reliability", val:96},
                  {label:"Quality Acceptance",  val:91},
                  {label:"Communication",       val:88},
                ].map(r=>(
                  <div key={r.label} className="flex items-center gap-3">
                    <span className="text-[10px] font-mono text-[#7c5c32] w-36 flex-shrink-0">{r.label}</span>
                    <div className="flex-1 h-2 bg-[#f0ebe0] rounded-full overflow-hidden">
                      <div className="h-full bg-[#1e4d2b] rounded-full" style={{width:r.val+"%"}}/>
                    </div>
                    <span className="text-[10px] font-mono text-[#1e4d2b] w-8 text-right">{r.val}%</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              {profile.buyerVerified && <ProfileBadge icon="✓" label="Verified Business" color="#4ade80"/>}
              <ProfileBadge icon="⚡" label="Fast Payment" color="#fbbf24"/>
              <ProfileBadge icon="🤝" label="Fair Dealing" color="#60a5fa"/>
            </div>
          </div>
        </div>
      )}

      {/* ════════════════ BUYER REQUIREMENTS ════════════════ */}
      {profileTab==="requirements" && !isFarmer && (
        <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6">
          <div className="flex items-center justify-between mb-5">
            <h3 className="font-semibold" style={{fontFamily:"var(--font-display)"}}>📋 Sourcing Requirements</h3>
            <div className="flex gap-2 text-xs font-mono">
              <span className="bg-[#d6f0de] text-[#166534] px-2 py-0.5 rounded-full">{profile.requirements.filter(r=>r.status==="Active").length} Active</span>
              <span className="bg-[#f0ebe0] text-[#7c5c32] px-2 py-0.5 rounded-full">{profile.requirements.filter(r=>r.status!=="Active").length} Closed</span>
            </div>
          </div>
          <div className="space-y-3">
            {profile.requirements.map(r=>(
              <div key={r.id} className={`p-4 rounded-xl border transition-colors ${r.status==="Active"?"border-[#1e4d2b]/30 bg-[#d6f0de]/30":"border-[#f0ebe0] bg-[#faf9f5] opacity-70"}`}>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-sm text-[#1a1a0e]">{r.crop}</span>
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full ${r.status==="Active"?"bg-[#4ade80]/20 text-[#166534] border border-[#4ade80]/30":"bg-[#e8e3d8] text-[#7c5c32]"}`}>{r.status}</span>
                </div>
                <div className="grid grid-cols-3 gap-2 text-[10px] font-mono text-[#7c5c32]">
                  <span>Qty: {r.qty}</span>
                  <span>Price: {r.priceRange}</span>
                  <span>Posted: {r.date}</span>
                </div>
              </div>
            ))}
          </div>
          <button className="mt-4 w-full py-3 border-2 border-dashed border-[#d0cbbf] rounded-xl text-sm text-[#7c5c32] hover:border-[#1e4d2b] hover:text-[#1e4d2b] transition-colors">
            + Post New Requirement
          </button>
        </div>
      )}

      {/* ════════════════ BUYER PURCHASES ════════════════ */}
      {profileTab==="purchases" && !isFarmer && (
        <div className="space-y-5">
          <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6">
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-semibold" style={{fontFamily:"var(--font-display)"}}>📦 Purchase History</h3>
              <span className="text-xs font-mono text-[#7c5c32]">{profile.purchases.length} orders</span>
            </div>
            <div className="space-y-3">
              {profile.purchases.map(p=>(
                <div key={p.id} className="flex items-center gap-4 p-4 rounded-xl border border-[#f0ebe0] hover:border-[#d0cbbf] transition-colors">
                  <div className="w-10 h-10 rounded-xl bg-[#e8f4ff] flex items-center justify-center text-xl flex-shrink-0">🏪</div>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-[#1a1a0e]">{p.crop}</p>
                    <p className="text-xs text-[#7c5c32]">{p.qty} · {p.price} · from {p.farmer}</p>
                    <p className="text-[10px] font-mono text-[#a77c3e] mt-0.5">{p.date}</p>
                  </div>
                  <span className="text-[10px] font-mono text-[#4a7c59] bg-[#d6f0de] px-2 py-0.5 rounded-full">✓ Delivered</span>
                </div>
              ))}
            </div>
            <div className="mt-5 pt-5 border-t border-[#f0ebe0] grid grid-cols-3 gap-3">
              {[
                {label:"Total Purchased",   value:"12.5 MT", icon:"📦"},
                {label:"Avg Price vs Mandi",value:"−11%",    icon:"💰"},
                {label:"Repeat Suppliers",  value:"2",       icon:"🤝"},
              ].map(m=>(
                <div key={m.label} className="text-center p-3 bg-[#faf9f5] rounded-xl">
                  <div className="text-lg mb-1">{m.icon}</div>
                  <div className="font-bold font-mono text-[#1e4d2b] text-sm">{m.value}</div>
                  <div className="text-[10px] text-[#7c5c32] font-mono mt-0.5">{m.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ════════════════ BUYER PREFERENCES ════════════════ */}
      {profileTab==="preferences" && !isFarmer && (
        <div className="space-y-5">
          <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6">
            <h3 className="font-semibold mb-4" style={{fontFamily:"var(--font-display)"}}>🔍 Saved Search Filters</h3>
            <div className="p-4 bg-[#faf9f5] rounded-xl border border-[#f0ebe0] mb-3">
              <p className="text-xs font-mono text-[#7c5c32] mb-1">Last used filter</p>
              <p className="text-sm font-semibold text-[#1a1a0e]">{profile.savedFilters || "No saved filters yet"}</p>
            </div>
            <p className="text-xs text-[#a77c3e] font-mono">Filters are automatically saved each time you search in the Buyers tab.</p>
          </div>
          <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6">
            <h3 className="font-semibold mb-4" style={{fontFamily:"var(--font-display)"}}>⭐ Favourite Farmers & FPOs</h3>
            <div className="space-y-2">
              {profile.favoriteFarmers.map((f,i)=>(
                <div key={i} className="flex items-center gap-3 p-3 rounded-xl border border-[#f0ebe0] hover:border-[#d0cbbf] transition-colors">
                  <span className="text-xl">🌾</span>
                  <span className="text-sm text-[#1a1a0e] flex-1">{f}</span>
                  <button className="text-[10px] font-mono text-[#1e4d2b] hover:underline">Contact</button>
                </div>
              ))}
              {profile.favoriteFarmers.length === 0 && (
                <p className="text-xs text-[#a77c3e] font-mono text-center py-4">No favourites yet — star a farmer from the Matching tab</p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ════════════════ ACCOUNT (shared) ════════════════ */}
      {profileTab==="account" && (
        <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6">
          <h3 className="font-semibold mb-5" style={{fontFamily:"var(--font-display)"}}>👤 Personal Information</h3>
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Full Name" value={profile.name} onChange={v=>upd("name",v)}/>
            <div>
              <label className="block text-[11px] font-mono font-bold text-[#7c5c32] uppercase tracking-wider mb-1.5">Mobile Number</label>
              <div className="flex gap-2">
                <span className="flex items-center px-3 bg-[#f5f0e8] border border-[#f0ebe0] rounded-xl text-sm text-[#7c5c32] font-mono flex-shrink-0">+91</span>
                <input value={profile.phone} onChange={e=>upd("phone",e.target.value)} disabled={!editMode}
                  className="flex-1 border rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-[#1e4d2b] font-mono disabled:bg-[#faf9f6] disabled:text-[#4a4a2e]"
                  style={{borderColor:editMode?"#d0cbbf":"#f0ebe0"}}/>
              </div>
              <p className="text-[10px] font-mono text-[#a77c3e] mt-1">Primary identifier — tied to all your data</p>
            </div>
            <Field label="Email Address" value={profile.email} onChange={v=>upd("email",v)} type="email"/>
          </div>
          <div className="mt-5 pt-5 border-t border-[#f0ebe0] flex items-center gap-3">
            <span className="text-lg">📱</span>
            <p className="text-xs font-mono text-[#a77c3e]">
              Your mobile number is permanently tied to your account. If you change phones, simply sign in with OTP on your new device — all your data moves with you automatically.
            </p>
          </div>
        </div>
      )}

      {/* ════════════════ SECURITY (shared) ════════════════ */}
      {profileTab==="security" && (
        <div className="space-y-5">
          <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6">
            <h3 className="font-semibold mb-5" style={{fontFamily:"var(--font-display)"}}>🔑 Change Password</h3>
            <div className="space-y-4 max-w-sm">
              {[{label:"Current Password",pw:password,set:setPassword},{label:"New Password",pw:confirmPw,set:setConfirmPw}].map(f=>(
                <div key={f.label}>
                  <label className="block text-[11px] font-mono font-bold text-[#7c5c32] uppercase tracking-wider mb-1.5">{f.label}</label>
                  <input type={pwVisible?"text":"password"} value={f.pw} onChange={e=>f.set(e.target.value)}
                    className="w-full border border-[#e8e3d8] rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-[#1e4d2b]"/>
                </div>
              ))}
              <div className="flex gap-2">
                <button className="bg-[#1e4d2b] text-white px-5 py-2.5 rounded-xl text-sm font-semibold hover:bg-[#2d6b3e] transition-colors">Update Password</button>
                <button onClick={()=>setPwVisible(!pwVisible)} className="px-4 py-2.5 rounded-xl border border-[#e8e3d8] text-sm text-[#7c5c32] hover:border-[#d0cbbf]">{pwVisible?"Hide":"Show"}</button>
              </div>
            </div>
          </div>
          <div className="bg-white border border-[#e8e3d8] rounded-2xl p-6">
            <h3 className="font-semibold mb-4" style={{fontFamily:"var(--font-display)"}}>🛡️ Security Settings</h3>
            <div className="space-y-3">
              {[
                {label:"SMS OTP login",          sub:"Required each time you sign in from a new device",  on:true},
                {label:"Payment release SMS",     sub:"SMS when escrow payment is released to you",        on:true},
                {label:"Price spike alerts",      sub:"SMS when your listed crop price spikes >10%",       on:true},
                {label:"New buyer match alerts",  sub:"Notify when a verified buyer matches your listing", on:true},
                {label:"Login activity emails",   sub:"Email when a new sign-in is detected",              on:false},
                {label:"Weekly summary email",    sub:"Sales and earnings summary every Monday",           on:false},
              ].map(s=>(
                <div key={s.label} className="flex items-start justify-between gap-4 py-3 border-b border-[#f5f0e8] last:border-0">
                  <div>
                    <p className="text-sm font-semibold text-[#1a1a0e]">{s.label}</p>
                    <p className="text-xs text-[#7c5c32] mt-0.5">{s.sub}</p>
                  </div>
                  <div className={`relative w-9 h-5 rounded-full flex-shrink-0 mt-0.5 cursor-pointer ${s.on?"bg-[#1e4d2b]":"bg-[#e8e3d8]"}`}>
                    <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-all ${s.on?"left-4":"left-0.5"}`}/>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="bg-[#fff8f0] border border-[#f8e0c0] rounded-2xl p-5 flex items-start gap-4">
            <span className="text-2xl">🔒</span>
            <div>
              <p className="text-sm font-semibold text-[#7c3a00] mb-1">Data Safety Promise</p>
              <p className="text-xs text-[#a0522d] leading-relaxed">All your data is encrypted and tied to your verified mobile number. We never share your contact details, bank information, or trade history with third parties. You can export or delete your account at any time.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}


const navItems: { id: View; label: string; icon: string }[] = [
  { id: "home",         label: "Home",       icon: "🏠" },
  { id: "farmer",       label: "Farmers",    icon: "🌱" },
  { id: "forecast",     label: "AI Forecast",icon: "🤖" },
  { id: "matching",     label: "Matching",   icon: "⚡" },
  { id: "buyer",        label: "Buyers",     icon: "🏪" },
  { id: "logistics",    label: "Logistics",  icon: "🚛" },
  { id: "orders",       label: "Orders",     icon: "📋" },
  { id: "transparency", label: "Pricing",    icon: "💡" },
  { id: "profile",      label: "Profile",    icon: "👤" },
];

// ─── Chatbot ──────────────────────────────────────────────────────────────────

type ChatMsg = { from: "user" | "bot"; text: string; ts: string };
function nowTS() { return new Date().toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit"}); }

// ─── Live crop price data ─────────────────────────────────────────────────
const LIVE_PRICES: Record<string, { price: string; trend: string; mandi: string; conf: number; min: string; max: string }> = {
  tomato:   { price:"₹48/kg", trend:"↑ +12%", mandi:"Lasalgaon APMC",  conf:91, min:"₹38", max:"₹62"  },
  onion:    { price:"₹22/kg", trend:"↓ −5%",  mandi:"Nashik APMC",     conf:88, min:"₹16", max:"₹28"  },
  potato:   { price:"₹18/kg", trend:"→ stable",mandi:"Agra APMC",      conf:85, min:"₹14", max:"₹24"  },
  wheat:    { price:"₹24/kg", trend:"↑ +3%",  mandi:"Indore APMC",     conf:94, min:"₹21", max:"₹27"  },
  rice:     { price:"₹38/kg", trend:"→ stable",mandi:"Warangal APMC",  conf:90, min:"₹34", max:"₹44"  },
  soybean:  { price:"₹46/kg", trend:"↑ +8%",  mandi:"Latur APMC",      conf:87, min:"₹40", max:"₹52"  },
  cotton:   { price:"₹62/kg", trend:"↑ +5%",  mandi:"Akola APMC",      conf:83, min:"₹55", max:"₹70"  },
  maize:    { price:"₹21/kg", trend:"↓ −3%",  mandi:"Davangere APMC",  conf:86, min:"₹18", max:"₹25"  },
  garlic:   { price:"₹85/kg", trend:"↑ +18%", mandi:"Mandsaur APMC",   conf:79, min:"₹65", max:"₹110" },
  ginger:   { price:"₹72/kg", trend:"→ stable",mandi:"Erode APMC",     conf:81, min:"₹58", max:"₹90"  },
  grapes:   { price:"₹95/kg", trend:"↑ +6%",  mandi:"Sangli APMC",     conf:84, min:"₹80", max:"₹120" },
  banana:   { price:"₹28/kg", trend:"↓ −4%",  mandi:"Jalgaon APMC",    conf:88, min:"₹22", max:"₹36"  },
  chilli:   { price:"₹110/kg",trend:"↑ +22%", mandi:"Guntur APMC",     conf:82, min:"₹85", max:"₹140" },
  turmeric: { price:"₹145/kg",trend:"↑ +14%", mandi:"Nizamabad APMC",  conf:80, min:"₹120",max:"₹175" },
};

const GOVT_SCHEMES = [
  { name:"PM-KISAN",       desc:"₹6,000/year in 3 instalments directly to farmer bank account. Register at pmkisan.gov.in with Aadhaar + land records.", eligibility:"All small & marginal farmers with cultivable land." },
  { name:"Kisan Credit Card (KCC)", desc:"Short-term credit up to ₹3 lakh at 4% interest (with government subsidy). Apply at any nationalized bank or cooperative bank.", eligibility:"All farmers — crop, horticulture, and allied activities." },
  { name:"PMFBY (Crop Insurance)", desc:"Premium: 1.5–2% for Kharif, 1.5% for Rabi. Covers yield losses from natural calamities. Register via CSC or bank before crop sowing.", eligibility:"Loanee and non-loanee farmers growing notified crops." },
  { name:"eNAM",           desc:"National Agriculture Market — sell directly to buyers across India online. Register at enam.gov.in with Aadhaar + bank details.", eligibility:"Farmers with produce registered at participating APMC mandis." },
  { name:"PM Kisan Maan Dhan",desc:"Monthly pension ₹3,000 after age 60. Premium ₹55–₹200/month depending on entry age. Enroll at CSC centers.", eligibility:"Small & marginal farmers aged 18–40 years." },
];

// ─── Native crop name aliases (any language → English key) ─────────────────
const CROP_ALIASES: [string, string][] = [
  ["टमाटर","tomato"],["टमाटा","tomato"],["टोमॅटो","tomato"],["தக்காளி","tomato"],["టమాటో","tomato"],["ಟೊಮೇಟೋ","tomato"],["ટામેટા","tomato"],["টমেটো","tomato"],["ਟਮਾਟਰ","tomato"],
  ["प्याज","onion"],["कांदा","onion"],["வெங்காயம்","onion"],["ఉల్లిపాయ","onion"],["ಈರುಳ್ಳಿ","onion"],["ડુંगળী","onion"],["পেঁয়াজ","onion"],["ਪਿਆਜ਼","onion"],
  ["आलू","potato"],["बटाटा","potato"],["உருளைக்கிழங்கு","potato"],["బంగాళాదుంప","potato"],["ಆಲೂಗಡ್ಡೆ","potato"],["બटाटا","potato"],["আলু","potato"],["ਆਲੂ","potato"],
  ["गेहूँ","wheat"],["गव्हू","wheat"],["கோதுமை","wheat"],["గోధుమ","wheat"],["ಗೋಧಿ","wheat"],["ઘઉ","wheat"],["গম","wheat"],["ਕਣਕ","wheat"],
  ["चावल","rice"],["भात","rice"],["அரிசி","rice"],["వడ్లు","rice"],["ಅಕ್ಕಿ","rice"],["ભาत","rice"],["চাল","rice"],["ਚੌਲ","rice"],
  ["सोयाबीन","soybean"],["சோயா","soybean"],["సోయాబీన్","soybean"],["ಸೋಯಾ","soybean"],["সয়াবিন","soybean"],["ਸੋਇਆ","soybean"],
  ["कपास","cotton"],["कापूस","cotton"],["பருத்தி","cotton"],["పత్తి","cotton"],["ಹತ್ತಿ","cotton"],["কাপাস","cotton"],["ਕਪਾਹ","cotton"],
  ["मक्का","maize"],["மக்காச்சோளம்","maize"],["మొక்కజొన్న","maize"],["ಮೆಕ್ಕೆಜೋಳ","maize"],["ভুট্টা","maize"],["ਮੱਕੀ","maize"],
  ["लहसुन","garlic"],["लसूण","garlic"],["பூண்டு","garlic"],["వెల్లుల్లి","garlic"],["ಬೆಳ್ಳುಳ್ಳಿ","garlic"],["লসুন","garlic"],["ਲਸਣ","garlic"],
  ["अदरक","ginger"],["आले","ginger"],["இஞ்சி","ginger"],["అల్లం","ginger"],["ಶುಂಠಿ","ginger"],["আদা","ginger"],["ਅਦਰਕ","ginger"],
  ["अंगूर","grapes"],["द्राक्ष","grapes"],["திராட்சை","grapes"],["ద్రాక్ష","grapes"],["ದ್ರಾಕ್ಷಿ","grapes"],["আঙুর","grapes"],["ਅੰਗੂਰ","grapes"],
  ["केला","banana"],["केळी","banana"],["வாழைப்பழம்","banana"],["అరటి","banana"],["ಬಾಳೆ","banana"],["কলা","banana"],["ਕੇਲਾ","banana"],
  ["मिर्च","chilli"],["मिरची","chilli"],["மிளகாய்","chilli"],["మిర్చి","chilli"],["ಮೆಣಸಿನಕಾಯಿ","chilli"],["মরিচ","chilli"],["ਮਿਰਚ","chilli"],
  ["हल्दी","turmeric"],["हळद","turmeric"],["மஞ்சள்","turmeric"],["పసుపు","turmeric"],["ಅರಿಶಿನ","turmeric"],["হলুদ","turmeric"],["ਹਲਦੀ","turmeric"],
];

// ─── Language system ────────────────────────────────────────────────────────
type Lang = "en" | "hi" | "mr" | "ta" | "te" | "kn" | "gu" | "bn" | "pa";

const LANG_META: Record<Lang, { native: string; flag: string; label: string }> = {
  en: { native: "English",  flag: "🇬🇧", label: "English"  },
  hi: { native: "हिन्दी",   flag: "🇮🇳", label: "Hindi"    },
  mr: { native: "मराठी",    flag: "🌾",  label: "Marathi"  },
  ta: { native: "தமிழ்",   flag: "🌴",  label: "Tamil"    },
  te: { native: "తెలుగు",  flag: "🌻",  label: "Telugu"   },
  kn: { native: "ಕನ್ನಡ",   flag: "🏔️",  label: "Kannada"  },
  gu: { native: "ગુજરાતી", flag: "🎪",  label: "Gujarati" },
  bn: { native: "বাংলা",   flag: "🌺",  label: "Bengali"  },
  pa: { native: "ਪੰਜਾਬੀ",  flag: "☀️",  label: "Punjabi"  },
};

// ─── Per-language quick chips ───────────────────────────────────────────────
const LANG_CHIPS: Record<Lang, string[]> = {
  en: ["🍅 Tomato price","📊 All crop prices","🌱 How to sell crop?","🏛️ PM-KISAN scheme","🚛 Track my truck","🐛 Pest alert","💰 Escrow payment","🏭 Cold storage"],
  hi: ["🍅 टमाटर का भाव","📊 सभी फसलों का भाव","🌱 फसल कैसे बेचें?","🏛️ PM-किसान योजना","🚛 ट्रक कहाँ है?","🐛 कीट-रोग सलाह","💰 पेमेंट कब मिलेगी?","🏭 ठंडा गोदाम"],
  mr: ["🍅 टोमॅटोचा भाव","📊 सर्व पिकांचे भाव","🌱 पीक कसे विकायचे?","🏛️ PM-किसान योजना","🚛 ट्रक कुठे आहे?","🐛 किड-रोग सल्ला","💰 पेमेंट कधी?","🏭 शीतगृह"],
  ta: ["🍅 தக்காளி விலை","📊 அனைத்து விலைகள்","🌱 பயிர் விற்பது எப்படி?","🏛️ PM-கிசான்","🚛 லாரி எங்கே?","🐛 பூச்சி ஆலோசனை","💰 பணம் எப்போது?","🏭 குளிர் சேமிப்பு"],
  te: ["🍅 టమాటో ధర","📊 అన్ని ధరలు","🌱 పంట అమ్మడం ఎలా?","🏛️ PM-కిసాన్","🚛 ట్రక్ ఎక్కడ?","🐛 తెగులు సలహా","💰 పేమెంట్ ఎప్పుడు?","🏭 శీతల గిడ్డంగి"],
  kn: ["🍅 ಟೊಮೇಟೋ ಬೆಲೆ","📊 ಎಲ್ಲಾ ಬೆಲೆ","🌱 ಬೆಳೆ ಮಾರಾಟ?","🏛️ PM-ಕಿಸಾನ್","🚛 ಟ್ರಕ್ ಎಲ್ಲಿ?","🐛 ಕೀಟ ಸಲಹೆ","💰 ಹಣ ಯಾವಾಗ?","🏭 ಶೀತ ಗೋದಾಮು"],
  gu: ["🍅 ટામેટાનો ભાવ","📊 બધા ભાવ","🌱 પાક કેવી રીતે વેચવો?","🏛️ PM-કિસાન","🚛 ટ્રક ક્યાં?","🐛 જીવાત સલાહ","💰 પૈસા ક્યારે?","🏭 ઠંડો ગોડાઉન"],
  bn: ["🍅 টমেটোর দাম","📊 সব ফসলের দাম","🌱 ফসল কীভাবে বিক্রি?","🏛️ PM-কিসান","🚛 ট্রাক কোথায়?","🐛 পোকামাকড় সলাহ","💰 টাকা কখন?","🏭 শীতল গুদাম"],
  pa: ["🍅 ਟਮਾਟਰ ਦਾ ਭਾਅ","📊 ਸਾਰੇ ਭਾਅ","🌱 ਫਸਲ ਕਿਵੇਂ ਵੇਚੀਏ?","🏛️ PM-ਕਿਸਾਨ","🚛 ਟਰੱਕ ਕਿੱਥੇ?","🐛 ਕੀੜੇ ਸਲਾਹ","💰 ਪੈਸੇ ਕਦੋਂ?","🏭 ਠੰਡਾ ਗੁਦਾਮ"],
};

// ─── Translation templates (6 key intents × 9 languages) ───────────────────
interface LangPack {
  greeting: string;
  price: (crop: string, p: string, trend: string, mandi: string, conf: number, min: string, max: string) => string;
  allPricesHeader: string;
  howToList: string;
  payment: string;
  pmKisan: string;
  fallback: string;
  nativePrefix: string;
}

const T: Record<Lang, LangPack> = {
  en: {
    greeting: `Namaste! 🌾 I'm Kisansetu AI — your agri assistant.\n\nI can help with:\n• **Live crop prices** — tomato, onion, wheat & 11 more\n• **Govt schemes** — PM-KISAN, KCC, PMFBY\n• **Truck tracking** & logistics\n• **Buyer matching** & escrow payments\n• **Weather** & pest advisory\n\nJust ask in plain language — I understand English, Hindi, Marathi, Tamil, Telugu, Kannada, Gujarati, Bengali & Punjabi.`,
    price: (crop, p, trend, mandi, conf, min, max) =>
      `📊 **${crop} — Live Price**\n\n• Today: **${p}** ${trend}\n• Range: ${min} – ${max} per kg\n• Best mandi: ${mandi}\n• AI confidence: ${conf}%\n\n${trend.startsWith("↑")?"💡 Price rising — good time to sell today!":trend.startsWith("↓")?"💡 Price falling — store 1–2 weeks if possible.":"💡 Stable price — list now for guaranteed buyer."}`,
    allPricesHeader: `📊 **Today's Live Mandi Prices**\n\n`,
    howToList: `🌱 **How to Sell Your Crop**\n\n1️⃣ Open the **Farmers tab**\n2️⃣ Tap **"+ Add Crop"**\n3️⃣ Fill crop name, quantity & harvest date\n4️⃣ FPO verifies your stock (1–2 days)\n5️⃣ Matched buyers appear automatically!\n\n📸 Add a photo — you get 3× more buyer responses\n🎙️ Tap the mic button to speak instead of typing`,
    payment: `💰 **When & How You Get Paid**\n\n✅ Buyer deposits payment **before** your truck is loaded\n✅ Money reaches your UPI in **48 hours** after delivery\n✅ Escrow protection — **zero fraud risk**\n\n📊 Track record: ₹0 farmer losses on our platform\n📞 Any problem? Call **1800-KISAN-AI** (free, 8am–8pm)`,
    pmKisan: `🏛️ **PM-KISAN Scheme**\n\n• ₹6,000 per year in **3 equal instalments**\n• Paid directly to your **bank account**\n• Register free at: **pmkisan.gov.in**\n• Documents needed: Aadhaar card + land papers\n\n✅ Eligible: All small & marginal farmers with cultivable land\n\nAsk me about KCC, PMFBY, or eNAM for more schemes.`,
    fallback: `I didn't quite understand. You can ask me:\n• "_Tomato price today_"\n• "_How do I sell my crop?_"\n• "_PM-KISAN scheme details_"\n• "_Track my truck_"\n\nOr tap a quick button below 👇`,
    nativePrefix: "",
  },
  hi: {
    greeting: `नमस्ते! 🌾 मैं किसानसेतु AI हूँ।\n\nमैं **हिंदी** में मदद करूँगा:\n• 📊 **फसल का भाव** — टमाटर, प्याज, गेहूँ और 11 और\n• 🏛️ **सरकारी योजनाएँ** — PM-किसान, KCC, बीमा\n• 🚛 **ट्रक ट्रैकिंग**\n• ⚡ **खरीदार से जोड़ना**\n• 🌤️ **मौसम और कीट सलाह**\n\nकोई भी सवाल पूछें — मैं समझूँगा!`,
    price: (crop, p, trend, mandi, conf, min, max) =>
      `📊 **${crop} का आज का भाव**\n\n• आज का दाम: **${p}** ${trend}\n• कम से कम – ज़्यादा से ज़्यादा: ${min} – ${max}/किलो\n• सबसे अच्छी मंडी: ${mandi}\n• AI भरोसा: ${conf}%\n\n${trend.startsWith("↑")?"💡 दाम बढ़ रहे हैं — आज ही बेचें!":trend.startsWith("↓")?"💡 दाम गिर रहे हैं — 1–2 हफ्ते ठंडे गोदाम में रखें।":"💡 दाम स्थिर हैं — अभी लिस्ट करें।"}`,
    allPricesHeader: `📊 **आज के सभी मंडी भाव**\n\n`,
    howToList: `🌱 **फसल कैसे बेचें?**\n\n1️⃣ ऐप में **किसान टैब** पर जाएँ\n2️⃣ **"+ नई फसल"** बटन दबाएँ\n3️⃣ फसल का नाम, वज़न और तारीख भरें\n4️⃣ FPO जाँच करेगा (1–2 दिन में)\n5️⃣ खरीदार खुद मिल जाएगा!\n\n📸 फोटो डालें → 3 गुना ज़्यादा खरीदार\n🎙️ माइक बटन दबाकर बोलकर भी बता सकते हैं`,
    payment: `💰 **पैसे कब और कैसे मिलेंगे?**\n\n✅ ट्रक लोड होने से **पहले** खरीदार पैसे जमा करता है\n✅ माल पहुँचने के **48 घंटे** में UPI में आ जाता है\n✅ एस्क्रो सुरक्षा — **कोई धोखा नहीं**\n\n📊 अब तक: किसी भी किसान का **₹1 भी नहीं डूबा**\n📞 परेशानी हो: **1800-KISAN-AI** (मुफ़्त कॉल)`,
    pmKisan: `🏛️ **PM-किसान योजना**\n\n• हर साल **₹6,000** — 3 किस्तों में\n• सीधे **बैंक खाते** में आता है\n• रजिस्टर करें: **pmkisan.gov.in**\n• ज़रूरी कागज़: आधार कार्ड + जमीन के कागज़\n\n✅ कौन ले सकता है: सभी छोटे और मझोले किसान\n\nKCC, PMFBY या eNAM के बारे में भी पूछ सकते हैं।`,
    fallback: `माफ करें, मैं समझ नहीं पाया। आप ये पूछ सकते हैं:\n• "_टमाटर का भाव क्या है?_"\n• "_फसल कैसे बेचें?_"\n• "_PM-किसान योजना_"\n• "_मेरा ट्रक कहाँ है?_"\n\nया नीचे कोई बटन दबाएँ 👇`,
    nativePrefix: "📌 यहाँ जानकारी है:\n\n",
  },
  mr: {
    greeting: `नमस्कार! 🌾 मी किसानसेतू AI आहे.\n\n**मराठीत** मदत करतो:\n• 📊 **पिकाचे भाव** — टोमॅटो, कांदा, गहू आणि 11 पिके\n• 🏛️ **सरकारी योजना** — PM-किसान, KCC, विमा\n• 🚛 **ट्रक ट्रॅकिंग**\n• ⚡ **खरेदीदार जोडणे**\n• 🌤️ **हवामान आणि कीड सल्ला**\n\nकोणताही प्रश्न विचारा — मी समजतो!`,
    price: (crop, p, trend, mandi, conf, min, max) =>
      `📊 **${crop} चा आजचा भाव**\n\n• आजचा दर: **${p}** ${trend}\n• श्रेणी: ${min} – ${max}/किलो\n• सर्वोत्तम बाजार: ${mandi}\n• AI विश्वास: ${conf}%\n\n${trend.startsWith("↑")?"💡 भाव वाढत आहेत — आजच विका!":trend.startsWith("↓")?"💡 भाव घसरत आहेत — 1–2 आठवडे शीतगृहात ठेवा.":"💡 भाव स्थिर — आत्ताच नोंदणी करा."}`,
    allPricesHeader: `📊 **आजचे सर्व मंडी भाव**\n\n`,
    howToList: `🌱 **पीक कसे विकायचे?**\n\n1️⃣ ऐपमध्ये **शेतकरी टॅब** वर जा\n2️⃣ **"+ नवीन पीक"** दाबा\n3️⃣ पिकाचे नाव, वज़न आणि तारीख भरा\n4️⃣ FPO तपासणी (1–2 दिवस)\n5️⃣ खरेदीदार आपोआप मिळेल!\n\n📸 फोटो टाका → 3 पट जास्त खरेदीदार`,
    payment: `💰 **पैसे कधी आणि कसे मिळतील?**\n\n✅ ट्रक लोड होण्यापूर्वी खरेदीदार पैसे जमा करतो\n✅ माल पोहोचल्यावर **48 तासांत** UPI मध्ये\n✅ एस्क्रो संरक्षण — **कोणतीही फसवणूक नाही**\n\n📞 अडचण: **1800-KISAN-AI** (मोफत कॉल)`,
    pmKisan: `🏛️ **PM-किसान योजना**\n\n• दरवर्षी **₹6,000** — 3 हप्त्यांत\n• थेट **बँक खात्यात**\n• नोंदणी: **pmkisan.gov.in**\n• लागणारे: आधार कार्ड + जमीन कागदपत्रे\n\n✅ पात्रता: सर्व लहान आणि मध्यम शेतकरी`,
    fallback: `माफ करा, समजले नाही. हे विचारा:\n• "_टोमॅटोचा भाव?_"\n• "_पीक कसे विकायचे?_"\n• "_PM-किसान योजना_"\n\nखालील बटणे दाबा 👇`,
    nativePrefix: "📌 येथे माहिती आहे:\n\n",
  },
  ta: {
    greeting: `வணக்கம்! 🌾 நான் கிசான்சேது AI.\n\n**தமிழில்** உதவுகிறேன்:\n• 📊 **பயிர் விலை** — தக்காளி, வெங்காயம், கோதுமை மற்றும் 11 பயிர்கள்\n• 🏛️ **அரசு திட்டங்கள்** — PM-கிசான், KCC, காப்பீடு\n• 🚛 **லாரி கண்காணிப்பு**\n• ⚡ **வாங்குபவர் தொடர்பு**\n• 🌤️ **வானிலை & பூச்சி ஆலோசனை**\n\nயாரும் கேளுங்கள் — புரிந்துகொள்கிறேன்!`,
    price: (crop, p, trend, mandi, conf, min, max) =>
      `📊 **${crop} — இன்றைய விலை**\n\n• இன்று: **${p}** ${trend}\n• வரம்பு: ${min} – ${max} / கிலோ\n• சிறந்த சந்தை: ${mandi}\n• AI நம்பிக்கை: ${conf}%\n\n${trend.startsWith("↑")?"💡 விலை உயர்கிறது — இன்றே விற்கவும்!":trend.startsWith("↓")?"💡 விலை குறைகிறது — 1–2 வாரம் குளிர் சேமிப்பில் வைக்கவும்.":"💡 விலை நிலையானது — இப்போதே பட்டியலிடவும்."}`,
    allPricesHeader: `📊 **இன்றைய மண்டி விலைகள்**\n\n`,
    howToList: `🌱 **பயிரை எப்படி விற்பது?**\n\n1️⃣ **விவசாயி தாவல்** திறக்கவும்\n2️⃣ **"+ புதிய பயிர்"** அழுத்தவும்\n3️⃣ பெயர், எடை, அறுவடை தேதி நிரப்பவும்\n4️⃣ FPO சரிபார்க்கும் (1–2 நாட்கள்)\n5️⃣ வாங்குபவர் தானாக வருவார்!`,
    payment: `💰 **பணம் எப்போது வரும்?**\n\n✅ லாரி ஏற்றுவதற்கு முன்பு வாங்குபவர் பணம் செலுத்துவார்\n✅ டெலிவரி பின் **48 மணி நேரத்தில்** UPI-ல்\n✅ எஸ்க்ரோ பாதுகாப்பு — **மோசடி இல்லை**\n\n📞 உதவிக்கு: **1800-KISAN-AI** (இலவசம்)`,
    pmKisan: `🏛️ **PM-கிசான் திட்டம்**\n\n• ஆண்டுக்கு **₹6,000** — 3 தவணைகளில்\n• நேரடியாக **வங்கிக் கணக்கில்**\n• பதிவு: **pmkisan.gov.in**\n• தேவை: ஆதார் + நில ஆவணங்கள்\n\n✅ தகுதி: அனைத்து சிறு விவசாயிகள்`,
    fallback: `புரியவில்லை. இவற்றை கேளுங்கள்:\n• "_தக்காளி விலை?_"\n• "_பயிர் எப்படி விற்பது?_"\n• "_PM-கிசான் திட்டம்_"\n\nகீழுள்ள பொத்தான்களை அழுத்துங்கள் 👇`,
    nativePrefix: "📌 இங்கே தகவல்:\n\n",
  },
  te: {
    greeting: `నమస్కారం! 🌾 నేను కిసాన్‌సేతు AI.\n\n**తెలుగులో** సహాయం చేస్తాను:\n• 📊 **పంట ధరలు** — టమాటో, ఉల్లిపాయ, గోధుమ మరియు 11 పంటలు\n• 🏛️ **ప్రభుత్వ పథకాలు** — PM-కిసాన్, KCC, బీమా\n• 🚛 **ట్రక్ ట్రాకింగ్**\n• ⚡ **కొనుగోలుదారు అనుసంధానం**\n• 🌤️ **వాతావరణం & తెగులు సలహా**\n\nఏదైనా అడగండి — అర్థం చేసుకుంటాను!`,
    price: (crop, p, trend, mandi, conf, min, max) =>
      `📊 **${crop} — నేటి ధర**\n\n• ఈరోజు: **${p}** ${trend}\n• పరిధి: ${min} – ${max} / కిలో\n• మంచి మండి: ${mandi}\n• AI నమ్మకం: ${conf}%\n\n${trend.startsWith("↑")?"💡 ధర పెరుగుతోంది — ఈరోజే అమ్మండి!":trend.startsWith("↓")?"💡 ధర తగ్గుతోంది — 1–2 వారాలు శీతల గిడ్డంగిలో ఉంచండి.":"💡 ధర స్థిరంగా ఉంది — ఇప్పుడే జాబితా చేయండి."}`,
    allPricesHeader: `📊 **నేటి మండి ధరలు**\n\n`,
    howToList: `🌱 **పంటను ఎలా అమ్మాలి?**\n\n1️⃣ **రైతు టాబ్** తెరవండి\n2️⃣ **"+ కొత్త పంట"** నొక్కండి\n3️⃣ పంట పేరు, బరువు, తేదీ నింపండి\n4️⃣ FPO తనిఖీ చేస్తుంది (1–2 రోజులు)\n5️⃣ కొనుగోలుదారు వస్తాడు!`,
    payment: `💰 **పేమెంట్ ఎప్పుడు వస్తుంది?**\n\n✅ ట్రక్ లోడ్ చేయడానికి ముందే డబ్బు లాక్ అవుతుంది\n✅ డెలివరీ తర్వాత **48 గంటల్లో** UPI లో\n✅ ఎస్క్రో భద్రత — **మోసం లేదు**\n\n📞 సహాయం: **1800-KISAN-AI** (ఉచితం)`,
    pmKisan: `🏛️ **PM-కిసాన్ పథకం**\n\n• ఏడాదికి **₹6,000** — 3 వాయిదాలలో\n• నేరుగా **బ్యాంక్ ఖాతాకు**\n• నమోదు: **pmkisan.gov.in**\n• అవసరం: ఆధార్ + భూమి పత్రాలు\n\n✅ అర్హత: అన్ని చిన్న రైతులు`,
    fallback: `అర్థం కాలేదు. ఇవి అడగండి:\n• "_టమాటో ధర?_"\n• "_పంట అమ్మడం ఎలా?_"\n• "_PM-కిసాన్ పథకం_"\n\nకింది బటన్లు నొక్కండి 👇`,
    nativePrefix: "📌 ఇక్కడ సమాచారం:\n\n",
  },
  kn: {
    greeting: `ನಮಸ್ಕಾರ! 🌾 ನಾನು ಕಿಸಾನ್‌ಸೇತು AI.\n\n**ಕನ್ನಡದಲ್ಲಿ** ಸಹಾಯ ಮಾಡುತ್ತೇನೆ:\n• 📊 **ಬೆಳೆ ಬೆಲೆ** — ಟೊಮೇಟೋ, ಈರುಳ್ಳಿ, ಗೋಧಿ ಮತ್ತು 11 ಬೆಳೆಗಳು\n• 🏛️ **ಸರ್ಕಾರಿ ಯೋಜನೆ** — PM-ಕಿಸಾನ್, KCC, ವಿಮೆ\n• 🚛 **ಟ್ರಕ್ ಟ್ರ್ಯಾಕಿಂಗ್**\n• ⚡ **ಖರೀದಿದಾರ ಸಂಪರ್ಕ**\n• 🌤️ **ಹವಾಮಾನ & ಕೀಟ ಸಲಹೆ**\n\nಏನಾದರೂ ಕೇಳಿ — ಅರ್ಥಮಾಡಿಕೊಳ್ಳುತ್ತೇನೆ!`,
    price: (crop, p, trend, mandi, conf, min, max) =>
      `📊 **${crop} — ಇಂದಿನ ಬೆಲೆ**\n\n• ಇಂದು: **${p}** ${trend}\n• ವ್ಯಾಪ್ತಿ: ${min} – ${max} / ಕೆಜಿ\n• ಉತ್ತಮ ಮಂಡಿ: ${mandi}\n• AI ನಂಬಿಕೆ: ${conf}%\n\n${trend.startsWith("↑")?"💡 ಬೆಲೆ ಏರುತ್ತಿದೆ — ಇಂದೇ ಮಾರಿ!":trend.startsWith("↓")?"💡 ಬೆಲೆ ಇಳಿಯುತ್ತಿದೆ — 1–2 ವಾರ ಶೀತ ಗೋದಾಮಿನಲ್ಲಿ ಇಡಿ.":"💡 ಬೆಲೆ ಸ್ಥಿರ — ಈಗಲೇ ಪಟ್ಟಿ ಮಾಡಿ."}`,
    allPricesHeader: `📊 **ಇಂದಿನ ಮಂಡಿ ಬೆಲೆಗಳು**\n\n`,
    howToList: `🌱 **ಬೆಳೆ ಹೇಗೆ ಮಾರಾಟ?**\n\n1️⃣ **ರೈತ ಟ್ಯಾಬ್** ತೆರೆಯಿರಿ\n2️⃣ **"+ ಹೊಸ ಬೆಳೆ"** ಒತ್ತಿರಿ\n3️⃣ ಹೆಸರು, ತೂಕ, ದಿನಾಂಕ ತುಂಬಿ\n4️⃣ FPO ಪರಿಶೀಲಿಸುತ್ತದೆ (1–2 ದಿನ)\n5️⃣ ಖರೀದಿದಾರ ತಾನೇ ಸಿಗುತ್ತಾನೆ!`,
    payment: `💰 **ಹಣ ಯಾವಾಗ ಬರುತ್ತದೆ?**\n\n✅ ಟ್ರಕ್ ಲೋಡ್ ಮೊದಲೇ ಹಣ ಲಾಕ್ ಆಗುತ್ತದೆ\n✅ ಡೆಲಿವರಿ ನಂತರ **48 ಗಂಟೆಯಲ್ಲಿ** UPI ಗೆ\n✅ ಎಸ್ಕ್ರೋ ಭದ್ರತೆ — **ಮೋಸ ಇಲ್ಲ**\n\n📞 ಸಹಾಯಕ್ಕೆ: **1800-KISAN-AI** (ಉಚಿತ)`,
    pmKisan: `🏛️ **PM-ಕಿಸಾನ್ ಯೋಜನೆ**\n\n• ವರ್ಷಕ್ಕೆ **₹6,000** — 3 ಕಂತಿನಲ್ಲಿ\n• ನೇರ **ಬ್ಯಾಂಕ್ ಖಾತೆಗೆ**\n• ನೋಂದಣಿ: **pmkisan.gov.in**\n• ಬೇಕು: ಆಧಾರ್ + ಜಮೀನಿನ ದಾಖಲೆ\n\n✅ ಅರ್ಹತೆ: ಎಲ್ಲ ಸಣ್ಣ ರೈತರು`,
    fallback: `ಅರ್ಥವಾಗಲಿಲ್ಲ. ಇವುಗಳನ್ನು ಕೇಳಿ:\n• "_ಟೊಮೇಟೋ ಬೆಲೆ?_"\n• "_ಬೆಳೆ ಮಾರಾಟ?_"\n• "_PM-ಕಿಸಾನ್ ಯೋಜನೆ_"\n\nಕೆಳಗಿನ ಬಟನ್ ಒತ್ತಿ 👇`,
    nativePrefix: "📌 ಇಲ್ಲಿ ಮಾಹಿತಿ:\n\n",
  },
  gu: {
    greeting: `નમસ્તે! 🌾 હું કિસાનસેતુ AI છું.\n\n**ગુજરાતીમાં** મદદ કરીશ:\n• 📊 **પાકના ભાવ** — ટામેટા, ડુંગળી, ઘઉં અને 11 પાક\n• 🏛️ **સરકારી યોજનાઓ** — PM-કિસાન, KCC, વીમો\n• 🚛 **ટ્રક ટ્રેકિંગ**\n• ⚡ **ખરીદનાર સાથે જોડવા**\n• 🌤️ **હવામાન & જીવાત સલાહ**\n\nગમે તે પૂછો — સમજીશ!`,
    price: (crop, p, trend, mandi, conf, min, max) =>
      `📊 **${crop} — આજનો ભાવ**\n\n• આજ: **${p}** ${trend}\n• રેન્જ: ${min} – ${max} / કિલો\n• સારી મંડી: ${mandi}\n• AI ભરોસો: ${conf}%\n\n${trend.startsWith("↑")?"💡 ભાવ વધી રહ્યા છે — આજે જ વેચો!":trend.startsWith("↓")?"💡 ભાવ ઘટી રહ્યા છે — 1–2 અઠ્ઠવાડિયા ઠંડા ગોડાઉનમાં રાખો.":"💡 ભાવ સ્થિર — અત્યારે નોંધ કરો."}`,
    allPricesHeader: `📊 **આજના બધા મંડી ભાવ**\n\n`,
    howToList: `🌱 **પાક કેવી રીતે વેચવો?**\n\n1️⃣ **ખેડૂત ટૅબ** ખોલો\n2️⃣ **"+ નવો પાક"** દબાવો\n3️⃣ નામ, વજન, તારીખ ભરો\n4️⃣ FPO ચકાસણી (1–2 દિવસ)\n5️⃣ ખરીદનાર આપોઆપ મળશે!`,
    payment: `💰 **પૈસા ક્યારે આવશે?**\n\n✅ ટ્રક ભરવા પહેલાં ખરીદનાર પૈસા જમા કરે\n✅ ડિલિવરી પછી **48 કલાકમાં** UPI\n✅ એસ્ક્રો સુરક્ષા — **ઠગારી નહીં**\n\n📞 મદદ: **1800-KISAN-AI** (મફત)`,
    pmKisan: `🏛️ **PM-કિસાન યોજના**\n\n• વર્ષે **₹6,000** — 3 હપ્તામાં\n• સીધા **બૅન્ક ખાતામાં**\n• નોંધણી: **pmkisan.gov.in**\n• જરૂરી: આધાર + જમીનના દસ્તાવેજ\n\n✅ પાત્રતા: બધા નાના ખેડૂત`,
    fallback: `સમજ ન પડ્યો. આ પૂછો:\n• "_ટામેટાનો ભાવ?_"\n• "_પાક કેવી રીતે વેચવો?_"\n• "_PM-કિસાન_"\n\nનીચેના બટન દબાવો 👇`,
    nativePrefix: "📌 અહીં માહિતી:\n\n",
  },
  bn: {
    greeting: `নমস্কার! 🌾 আমি কিসানসেতু AI।\n\n**বাংলায়** সাহায্য করব:\n• 📊 **ফসলের দাম** — টমেটো, পেঁয়াজ, গম ও ১১টি ফসল\n• 🏛️ **সরকারি প্রকল্প** — PM-কিসান, KCC, বিমা\n• 🚛 **ট্রাক ট্র্যাকিং**\n• ⚡ **ক্রেতা খুঁজে দেওয়া**\n• 🌤️ **আবহাওয়া & পোকামাকড় পরামর্শ**\n\nযা খুশি জিজ্ঞেস করুন — বুঝব!`,
    price: (crop, p, trend, mandi, conf, min, max) =>
      `📊 **${crop} — আজকের দাম**\n\n• আজ: **${p}** ${trend}\n• পরিসর: ${min} – ${max} / কেজি\n• সেরা মান্ডি: ${mandi}\n• AI আস্থা: ${conf}%\n\n${trend.startsWith("↑")?"💡 দাম বাড়ছে — আজই বিক্রি করুন!":trend.startsWith("↓")?"💡 দাম কমছে — ১–২ সপ্তাহ ঠান্ডা গুদামে রাখুন।":"💡 দাম স্থিতিশীল — এখনই তালিকাভুক্ত করুন।"}`,
    allPricesHeader: `📊 **আজকের সব মান্ডি দাম**\n\n`,
    howToList: `🌱 **ফসল কীভাবে বিক্রি করবেন?**\n\n1️⃣ **কৃষক ট্যাব** খুলুন\n2️⃣ **"+ নতুন ফসল"** চাপুন\n3️⃣ নাম, ওজন, তারিখ পূরণ করুন\n4️⃣ FPO যাচাই করবে (১–২ দিন)\n5️⃣ ক্রেতা নিজেই আসবে!`,
    payment: `💰 **টাকা কখন পাব?**\n\n✅ ট্রাক লোডের আগেই ক্রেতা টাকা জমা দেয়\n✅ ডেলিভারির **৪৮ ঘণ্টার মধ্যে** UPI-তে\n✅ এসক্রো সুরক্ষা — **প্রতারণা নেই**\n\n📞 সাহায্য: **1800-KISAN-AI** (বিনামূল্যে)`,
    pmKisan: `🏛️ **PM-কিসান প্রকল্প**\n\n• বছরে **₹6,000** — ৩ কিস্তিতে\n• সরাসরি **ব্যাংক অ্যাকাউন্টে**\n• নিবন্ধন: **pmkisan.gov.in**\n• দরকার: আধার + জমির কাগজ\n\n✅ যোগ্যতা: সব ছোট কৃষক`,
    fallback: `বুঝতে পারিনি। জিজ্ঞেস করুন:\n• "_টমেটোর দাম?_"\n• "_ফসল কীভাবে বিক্রি?_"\n• "_PM-কিসান প্রকল্প_"\n\nনীচের বোতাম চাপুন 👇`,
    nativePrefix: "📌 এখানে তথ্য:\n\n",
  },
  pa: {
    greeting: `ਸਤਿ ਸ੍ਰੀ ਅਕਾਲ! 🌾 ਮੈਂ ਕਿਸਾਨਸੇਤੂ AI ਹਾਂ।\n\n**ਪੰਜਾਬੀ ਵਿੱਚ** ਮਦਦ ਕਰਾਂਗਾ:\n• 📊 **ਫਸਲ ਦੇ ਭਾਅ** — ਟਮਾਟਰ, ਪਿਆਜ਼, ਕਣਕ ਅਤੇ 11 ਫਸਲਾਂ\n• 🏛️ **ਸਰਕਾਰੀ ਯੋਜਨਾਵਾਂ** — PM-ਕਿਸਾਨ, KCC, ਬੀਮਾ\n• 🚛 **ਟਰੱਕ ਟਰੈਕਿੰਗ**\n• ⚡ **ਖਰੀਦਦਾਰ ਨਾਲ ਜੋੜਨਾ**\n• 🌤️ **ਮੌਸਮ & ਕੀੜੇ ਸਲਾਹ**\n\nਕੁਝ ਵੀ ਪੁੱਛੋ — ਸਮਝਾਂਗਾ!`,
    price: (crop, p, trend, mandi, conf, min, max) =>
      `📊 **${crop} — ਅੱਜ ਦਾ ਭਾਅ**\n\n• ਅੱਜ: **${p}** ${trend}\n• ਰੇਂਜ: ${min} – ${max} / ਕਿਲੋ\n• ਵਧੀਆ ਮੰਡੀ: ${mandi}\n• AI ਭਰੋਸਾ: ${conf}%\n\n${trend.startsWith("↑")?"💡 ਭਾਅ ਵੱਧ ਰਿਹਾ ਹੈ — ਅੱਜ ਹੀ ਵੇਚੋ!":trend.startsWith("↓")?"💡 ਭਾਅ ਘੱਟ ਰਿਹਾ ਹੈ — 1–2 ਹਫ਼ਤੇ ਠੰਡੇ ਗੁਦਾਮ ਵਿੱਚ ਰੱਖੋ।":"💡 ਭਾਅ ਸਥਿਰ — ਹੁਣੇ ਲਿਸਟ ਕਰੋ।"}`,
    allPricesHeader: `📊 **ਅੱਜ ਦੇ ਸਾਰੇ ਮੰਡੀ ਭਾਅ**\n\n`,
    howToList: `🌱 **ਫਸਲ ਕਿਵੇਂ ਵੇਚੀਏ?**\n\n1️⃣ **ਕਿਸਾਨ ਟੈਬ** ਖੋਲੋ\n2️⃣ **"+ ਨਵੀਂ ਫਸਲ"** ਦਬਾਓ\n3️⃣ ਨਾਮ, ਵਜ਼ਨ, ਤਾਰੀਖ਼ ਭਰੋ\n4️⃣ FPO ਜਾਂਚ ਕਰੇਗਾ (1–2 ਦਿਨ)\n5️⃣ ਖਰੀਦਦਾਰ ਆਪੇ ਮਿਲੇਗਾ!`,
    payment: `💰 **ਪੈਸੇ ਕਦੋਂ ਮਿਲਣਗੇ?**\n\n✅ ਟਰੱਕ ਭਰਨ ਤੋਂ ਪਹਿਲਾਂ ਖਰੀਦਦਾਰ ਪੈਸੇ ਦਿੰਦਾ ਹੈ\n✅ ਡਿਲੀਵਰੀ ਤੋਂ **48 ਘੰਟਿਆਂ ਵਿੱਚ** UPI\n✅ ਐਸਕ੍ਰੋ ਸੁਰੱਖਿਆ — **ਧੋਖਾ ਨਹੀਂ**\n\n📞 ਮਦਦ: **1800-KISAN-AI** (ਮੁਫ਼ਤ)`,
    pmKisan: `🏛️ **PM-ਕਿਸਾਨ ਯੋਜਨਾ**\n\n• ਸਾਲ ਵਿੱਚ **₹6,000** — 3 ਕਿਸ਼ਤਾਂ ਵਿੱਚ\n• ਸਿੱਧਾ **ਬੈਂਕ ਖਾਤੇ ਵਿੱਚ**\n• ਰਜਿਸਟ੍ਰੇਸ਼ਨ: **pmkisan.gov.in**\n• ਚਾਹੀਦਾ: ਆਧਾਰ + ਜ਼ਮੀਨ ਦੇ ਕਾਗਜ਼\n\n✅ ਯੋਗਤਾ: ਸਾਰੇ ਛੋਟੇ ਕਿਸਾਨ`,
    fallback: `ਸਮਝ ਨਹੀਂ ਆਇਆ। ਇਹ ਪੁੱਛੋ:\n• "_ਟਮਾਟਰ ਦਾ ਭਾਅ?_"\n• "_ਫਸਲ ਕਿਵੇਂ ਵੇਚੀਏ?_"\n• "_PM-ਕਿਸਾਨ ਯੋਜਨਾ_"\n\nਹੇਠਾਂ ਦੇ ਬਟਨ ਦਬਾਓ 👇`,
    nativePrefix: "📌 ਇੱਥੇ ਜਾਣਕਾਰੀ:\n\n",
  },
};;

// ─── Detect language from Unicode script ───────────────────────────────────
function detectInputLang(text: string): Lang | null {
  if (/[஀-௿]/.test(text)) return "ta";  // Tamil
  if (/[ఀ-౿]/.test(text)) return "te";  // Telugu
  if (/[ಀ-೿]/.test(text)) return "kn";  // Kannada
  if (/[઀-૿]/.test(text)) return "gu";  // Gujarati
  if (/[ঀ-৿]/.test(text)) return "bn";  // Bengali
  if (/[਀-੿]/.test(text)) return "pa";  // Gurmukhi/Punjabi
  if (/[ऀ-ॿ]/.test(text)) return "hi";  // Devanagari (Hindi/Marathi)
  return null;
}

// ─── Language-aware crop price lookup ─────────────────────────────────────
function findCropPriceLang(q: string, lang: Lang): string | null {
  const lower = q.toLowerCase();
  // English crop name check
  for (const [crop, data] of Object.entries(LIVE_PRICES)) {
    if (lower.includes(crop)) {
      return T[lang].price(crop.charAt(0).toUpperCase()+crop.slice(1), data.price, data.trend, data.mandi, data.conf, data.min, data.max);
    }
  }
  // Native language alias check
  for (const [alias, crop] of CROP_ALIASES) {
    if (q.includes(alias)) {
      const data = LIVE_PRICES[crop];
      if (data) return T[lang].price(crop.charAt(0).toUpperCase()+crop.slice(1), data.price, data.trend, data.mandi, data.conf, data.min, data.max);
    }
  }
  return null;
}

function findRouteLang(q: string, lang: Lang): string | null {
  if (!/route|truck|shipment|track|transport|logistics|delivery|cargo|transit|dispatch|ट्रक|ट्रैक|ट्रॅक|ট্রাক|ட்ரக்|ట్రక్|ಟ್ರಕ್|ਟਰੱਕ/i.test(q)) return null;
  const active = LIVE_ROUTES.filter(r=>r.status==="in-transit");
  const optimized = LIVE_ROUTES.filter(r=>r.status==="optimized");
  const routeMatch = q.match(/RT-\d+/i);
  if (routeMatch) {
    const r = LIVE_ROUTES.find(rt=>rt.id.toLowerCase()===routeMatch[0].toLowerCase());
    if (r) return (lang!=="en"?T[lang].nativePrefix:"") + `🚛 **Route ${r.id}**

• Status: ${r.status==="in-transit"?"🟢 In Transit":r.status==="optimized"?"🔵 Ready":"⏳ Pending"}
• ${getHub(r.fromId).name} → ${getHub(r.toId).name}
• Cargo: ${r.cargo} · ${r.distance}
• ETA: ${r.eta} · Driver: ${r.driver}`;
  }
  return (lang!=="en"?T[lang].nativePrefix:"") +
    `🚛 **Live Logistics**

🟢 In Transit (${active.length}):
` +
    active.map(r=>`• ${r.id}: ${getHub(r.fromId).name} → ${getHub(r.toId).name} | ETA ${r.eta}`).join("\n") +
    `

🔵 Ready to Dispatch (${optimized.length}):
` +
    optimized.map(r=>`• ${r.id}: ${getHub(r.fromId).name} → ${getHub(r.toId).name} | ${r.distance}`).join("\n") +
    `

View live GPS map in the **Logistics tab**.`;
}

function findSchemeLang(q: string, lang: Lang): string | null {
  const lower = q.toLowerCase();
  for (const s of GOVT_SCHEMES) {
    const key = s.name.toLowerCase().replace(/[^a-z]/g,"");
    if (lower.includes(key.slice(0,4)) || (lower.includes("kcc")&&s.name.includes("KCC")) ||
        (lower.includes("pmfby")&&s.name.includes("PMFBY")) || (/insurance|बीमा|विमा|காப்பீடு|బీమా|ವಿಮೆ|વીमो|বিমা|ਬੀਮਾ/i.test(q)&&s.name.includes("PMFBY")) ||
        (/pension|ਪੈਨਸ਼ਨ|पेंशन/i.test(q)&&s.name.includes("Maan")) || (/enam/i.test(q)&&s.name.includes("eNAM"))) {
      return (lang!=="en"?T[lang].nativePrefix:"") + `🏛️ **${s.name}**

${s.desc}

✅ ${s.eligibility}`;
    }
  }
  if (/scheme|yojana|subsidy|benefit|योजना|যোজনা|திட்டம்|పథకం|ಯೋಜನೆ|ਯੋਜਨਾ|yl|govt.*help/i.test(q)) {
    return (lang!=="en"?T[lang].nativePrefix:"") +
      `🏛️ **Government Schemes**

` +
      GOVT_SCHEMES.map((s,i)=>`${i+1}. **${s.name}** — ${s.desc.split(".")[0]}.`).join("\n") +
      `

Ask about any scheme by name for full details.`;
  }
  return null;
}

// ─── All intents (English patterns + native patterns) ──────────────────────
type BotIntent = { patterns: RegExp[]; respond: (q: string, lang: Lang) => string };

const BOT_INTENTS_LANG: BotIntent[] = [
  { patterns: [/weather|rain|rainfall|monsoon|barish|temperature|forecast.*weather|मौसम|हवामान|வானிலை|వాతావరణం|ಹವಾಮಾನ|ਮੌਸਮ|আবহাওয়া|ഹवাमान/i],
    respond: (_q, lang) => (lang!=="en"?T[lang].nativePrefix:"") +
      `🌤️ **Weather Forecast (7 days)**

• **Nashik/Pune**: Rain Thu–Fri. Harvest onion Mon–Wed.
• **Vidarbha**: Clear skies 5 days. Good for cotton picking.
• **UP/Bihar**: Mild fog mornings. Wheat ripening on track.
• **Karnataka**: Dry — high cold-chain demand.

⚠️ Nashik tomato growers: dispatch by Wednesday to avoid rain spoilage.

_Source: IMD + AI crop-impact model_` },

  { patterns: [/pest|disease|keet|bug|insect|blight|wilt|rot|कीट|रोग|कीड|পোকা|பூச்சி|తెగులు|ಕೀಟ|ਕੀੜ|ਰੋਗ/i],
    respond: (_q, lang) => (lang!=="en"?T[lang].nativePrefix:"") +
      `🔬 **Pest & Disease Alert (This Season)**

🍅 **Tomato**: Early blight HIGH risk in Nashik (humidity >70%). Spray Mancozeb 2g/L.
🧅 **Onion**: Thrips active. Use Spinosad or neem oil.
🌾 **Wheat**: Rust risk LOW — continue monitoring.
🫑 **Chilli**: Leaf curl virus — remove infected plants, spray imidacloprid.

💡 Upload a crop photo in the **Farmer tab → Pest & Disease** for instant AI diagnosis.` },

  { patterns: [/cold storage|cold chain|warehouse|store.*crop|ठंडा गोदाम|शीतगृह|ਠੰਡਾ ਗੁਦਾਮ|শীতল গুদাম|குளிர் சேமிப்பு|శీతల గిడ్డంగి|ಶೀತ ಗೋದಾಮ|ઠ.*ગ/i],
    respond: (_q, lang) => (lang!=="en"?T[lang].nativePrefix:"") +
      `🏭 **Cold Storage Network**

• **Nashik Cold Hub** — 12 km · ₹2.8/kg/week · 94% space available
• **Pune Agri Park** — 38 km · ₹3.2/kg/week · 78% available
• **Aurangabad Store** — 67 km · ₹2.4/kg/week · 82% available

💡 Storing onion now (₹22/kg) for 6–8 weeks could yield ₹32–38/kg based on seasonal patterns.

Book a slot from the **Logistics tab → Cold Storage**.` },

  { patterns: [/match|buyer|connect|find buyer|who.*buy|sell.*who|खरीदार|खरेदीदार|வாங்குபவர்|కొనుగోలుదారు|ಖರೀದಿದಾರ|ਖਰੀਦਦਾਰ|ক্রেতা/i],
    respond: (_q, lang) => {
      const top = PRODUCE_CATALOGUE.slice(0,3);
      return (lang!=="en"?T[lang].nativePrefix:"") +
        `⚡ **Smart Buyer Matching**

**Active buyer requirements now:**
` +
        top.map(p=>`• **${p.crop}** (${p.grade}): ${p.qty} @ ${p.price} — ${p.dist} away`).join("\n") +
        `

**Steps:**
1. List your crop (Farmer tab)
2. FPO verifies stock
3. AI matches you with top buyers
4. Confirm → escrow locks payment

Go to the **Matching tab** to see live matches.`;
    }},

  { patterns: [/fpo|verif|farmer producer|cooperative|सहकारी|FPO|ਐਫਪੀਓ/i],
    respond: (_q, lang) => (lang!=="en"?T[lang].nativePrefix:"") +
      `🏢 **FPO Verification**

1. Register at kisansetu.in/fpo
2. Upload: PAN, GST, Bank passbook, FPO certificate
3. Field officer visits within 3 days
4. Verified badge ✓ appears on all your listings

**Benefits of verification:**
• 2.3× higher buyer response rate
• Access to BigBasket, Reliance, Star buyers
• Escrow payment protection
• Warehouse financing eligibility` },

  { patterns: [/price share|farmer.*share|how much.*farmer|margin|middleman|मंडी.*कटौती|कमीशन/i],
    respond: (_q, lang) => (lang!=="en"?T[lang].nativePrefix:"") +
      `💡 **Price Transparency**

**Old mandi chain (Tomato ₹100 retail):**
• Farmer gets: ₹28–38 (28–38%)
• Traders + APMC: ₹14 · Wholesaler: ₹12 · Retailer: ₹30

**Kisansetu direct:**
• Farmer gets: **₹72–81** (72–81%)
• Platform fee: ₹4 · Retailer: ₹15–24

📈 Average extra income: **₹34,000/season per farmer**

See the full waterfall chart in the **Pricing tab**.` },

  { patterns: [/order|my order|order status|ऑर्डर|আদেশ|ఆర్డర్/i],
    respond: (_q, lang) => {
      const sample = orders.slice(0,3);
      return (lang!=="en"?T[lang].nativePrefix:"") +
        `📋 **Recent Orders**\n\n` +
        sample.map(o=>`• **${o.id}**: ${o.crop} ${o.qty} → ${o.buyer}\n  Status: ${o.status} · ${o.date}`).join("\n\n") +
        `\n\nView all in the **Orders tab** — tap any order for escrow status, GPS, and QR traceability.`;
    }},

  { patterns: [/qr|trace|traceability|farm.to|scan|origin/i],
    respond: (_q, lang) => (lang!=="en"?T[lang].nativePrefix:"") +
      `📱 **Farm-to-Consumer QR Traceability**

Each order gets a QR code showing:
🌱 Farm name & village · 👨‍🌾 Farmer / FPO · 📅 Harvest & dispatch date
🧪 Pesticide test results · 🚛 Cold-chain log · 💰 Price paid to farmer

Retailers using Kisansetu QR codes see **34% higher consumer trust**.

Generate from **Orders tab** → tap order → QR button.` },

  { patterns: [/contact|support|help|human|agent|toll free|call|phone|मदद|सहायता|ਮਦਦ|সাহায্য|உதவி|సహాయం|ಸಹಾಯ/i],
    respond: (_q, lang) => (lang!=="en"?T[lang].nativePrefix:"") +
      `📞 **Contact & Support**

• **Toll-free**: 1800-KISAN-AI · Mon–Sat 8am–8pm
• **WhatsApp**: +91 98765 43210
• **Email**: support@kisansetu.in

**Response times:**
• Chat (AI): Instant · Escalated: <4 hrs
• Phone: <2 min hold · Email: <24 hrs

For payment disputes or fraud — call immediately. Escrow funds are protected.` },

  { patterns: [/what is kisansetu|about|how.*work|platform|feature|app/i],
    respond: (_q, lang) => (lang!=="en"?T[lang].nativePrefix:"") +
      `🌾 **Kisansetu AI — Platform**

**Serving:** 12,400+ farmers & FPOs across India

✅ Live crop prices (14 crops)
✅ Smart buyer-farmer matching (94% accuracy)
✅ AI logistics route optimizer
✅ Escrow payments — zero fraud
✅ Cold storage network
✅ QR traceability per shipment
✅ FPO verification & portfolio
✅ Voice chatbot in 9 languages

Farmers earn **₹34,000 extra per season** vs traditional mandi.` },
];

const PROACTIVE_NUDGES = [
  "💡 Heads up: Tomato prices are peaking this week in Bengaluru — excellent time to list if you have stock.",
  "🌧️ Rain forecast in Nashik in 3 days. If you have Onion ready, consider dispatching early.",
  "📈 Demand alert: BigBasket posted a new requirement for 8 MT Tomato at ₹42/kg. Check Matching tab.",
];

const ESCALATION_TRIGGERS = /payment dispute|rejected|scam|fraud|cheat|not paid|money stuck|quality reject/i;

// ─── Main multilingual bot engine ──────────────────────────────────────────
function botReply(text: string, lang: Lang = "en"): string {
  const q = text.trim();
  if (!q) return T[lang].fallback;

  // 1. Greeting
  if (/^(hi|hello|hey|namaste|namaskar|jai kisan|hii|helo)|नमस्ते|नमस्कार|வணக்கம்|నమస్|ನಮಸ್|ਸਤਿ|নমস্|नमस्/i.test(q))
    return T[lang].greeting;

  // 2. Crop price — native aliases first, then English
  const priceHit = findCropPriceLang(q, lang);
  if (priceHit) return priceHit;

  // 3. All prices
  if (/all price|all crop|price list|mandi rate today|today.*(rate|price)|price.*today|सभी.*भाव|सब.*भाव|सर्व.*भाव|அனைத்து|అన్ని.*ధర|ಎಲ್ಲಾ.*ಬೆಲೆ|বধ.*ভাও|ਸਾਰ.*ਭਾਅ/i.test(q))
    return T[lang].allPricesHeader +
      Object.entries(LIVE_PRICES).map(([c,d])=>`• **${c.charAt(0).toUpperCase()+c.slice(1)}**: ${d.price} ${d.trend} _(${d.mandi})_`).join("\n") +
      `

_AGMARKNET · Updated every 6 hours · AI confidence 79–94%_`;

  // 4. How to sell/list
  if (/how.*list|list.*crop|add.*crop|new.*listing|how.*sell|sell.*crop|बेचें|बेचना|विकायचे|விற்|అమ్మ|ಮಾರಾಟ|వেচ|বিক্রি|ਵੇਚ|फसल.*बेच|पीक.*विक|crop.*sell/i.test(q))
    return T[lang].howToList;

  // 5. Payment
  if (/escrow|payment|paid|paise|paisa|money|settle|upi|पैसे|पेमेंट|ਪੈਸੇ|টাকা|பணம்|డబ్బు|ಹಣ|પૈસ/i.test(q))
    return T[lang].payment;

  // 6. PM-KISAN (before general schemes)
  if (/pm.kisan|pm-kisan|kisan samman|PM-किसान|PM-కిసాన్|PM-கிசான்|PM-ਕਿਸਾਨ|PM-কিসান|PM-ಕಿಸಾನ್|PM-કिसान/i.test(q))
    return T[lang].pmKisan;

  // 7. Route/logistics
  const routeHit = findRouteLang(q, lang);
  if (routeHit) return routeHit;

  // 8. Govt schemes
  const schemeHit = findSchemeLang(q, lang);
  if (schemeHit) return schemeHit;

  // 9. Intent matching (all with language prefix)
  for (const intent of BOT_INTENTS_LANG) {
    if (intent.patterns.some(p => p.test(q))) return intent.respond(q, lang);
  }

  // 10. Fuzzy crop mention fallback
  const words = q.toLowerCase().split(/\s+/);
  const cropMentioned = Object.keys(LIVE_PRICES).find(c => words.some(w => w.includes(c.slice(0,4))));
  if (cropMentioned) {
    const d = LIVE_PRICES[cropMentioned];
    return T[lang].price(cropMentioned.charAt(0).toUpperCase()+cropMentioned.slice(1), d.price, d.trend, d.mandi, d.conf, d.min, d.max);
  }

  return T[lang].fallback;
}


function VoiceChatBtn({ onVoice }: { onVoice: (t: string) => void }) {
  const [recording, setRecording] = useState(false);
  const SAMPLES = [
    "Today's tomato price in my area?",
    "How do I verify my FPO stock?",
    "Track my shipment status",
    "Help me register a new crop",
  ];
  function toggle() {
    if (recording) {
      setRecording(false);
      const s = SAMPLES[Math.floor(Math.random()*SAMPLES.length)];
      setTimeout(() => onVoice(s), 300);
    } else {
      setRecording(true);
      setTimeout(() => {
        const s = SAMPLES[Math.floor(Math.random()*SAMPLES.length)];
        setRecording(false);
        onVoice(s);
      }, 2500);
    }
  }
  return (
    <button onClick={toggle} title="Voice input"
      className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 transition-all ${recording ? "bg-red-100 animate-pulse" : "bg-[#f5f0e8] hover:bg-[#e8e3d8]"}`}>
      <svg width="14" height="14" fill="none" stroke={recording?"#dc2626":"#7c5c32"} strokeWidth="2" viewBox="0 0 24 24">
        <rect x="9" y="2" width="6" height="11" rx="3"/>
        <path d="M19 10a7 7 0 0 1-14 0"/>
        <line x1="12" y1="19" x2="12" y2="22"/>
        <line x1="8" y1="22" x2="16" y2="22"/>
      </svg>
    </button>
  );
}


function KisanChat() {
  const [open, setOpen] = useState(false);
  const [lang, setLang] = useState<Lang>(() => {
    const saved = localStorage.getItem("ks_lang") as Lang | null;
    return (saved && saved in LANG_META) ? saved : "en";
  });
  const [showLangPicker, setShowLangPicker] = useState(() => !localStorage.getItem("ks_lang"));
  const [langMenu, setLangMenu] = useState(false);
  const [autoDetected, setAutoDetected] = useState<Lang|null>(null);
  const [msgs, setMsgs] = useState<ChatMsg[]>([
    { from: "bot", text: T["en"].greeting, ts: nowTS() },
  ]);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const [unread, setUnread] = useState(0);
  const [escalated, setEscalated] = useState(false);
  const [speakingIdx, setSpeakingIdx] = useState<number|null>(null);
  const nudgeSentRef = useRef(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (open) { setUnread(0); setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: "smooth" }), 60); }
  }, [open, msgs]);

  useEffect(() => {
    if (open && !nudgeSentRef.current && msgs.length === 1) {
      nudgeSentRef.current = true;
      const nudge = PROACTIVE_NUDGES[Math.floor(Math.random()*PROACTIVE_NUDGES.length)];
      setTimeout(() => { setMsgs(prev => [...prev, { from:"bot", text: nudge, ts: nowTS() }]); }, 4500);
    }
  }, [open]);

  useEffect(() => {
    if (!open && window.speechSynthesis) { window.speechSynthesis.cancel(); setSpeakingIdx(null); }
  }, [open]);

  function chooseLang(l: Lang) {
    setLang(l);
    localStorage.setItem("ks_lang", l);
    setShowLangPicker(false);
    setLangMenu(false);
    setMsgs([{ from:"bot", text: T[l].greeting, ts: nowTS() }]);
  }

  function speak(text: string, idx: number) {
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    if (speakingIdx === idx) { setSpeakingIdx(null); return; }
    const clean = text.replace(/\*\*/g,"").replace(/_/g,"");
    const utt = new SpeechSynthesisUtterance(clean);
    const langMap: Record<Lang,string> = { en:"en-IN", hi:"hi-IN", mr:"mr-IN", ta:"ta-IN", te:"te-IN", kn:"kn-IN", gu:"gu-IN", bn:"bn-IN", pa:"pa-IN" };
    utt.lang = langMap[lang];
    utt.rate = 0.85;
    utt.onend = () => setSpeakingIdx(null);
    utt.onerror = () => setSpeakingIdx(null);
    setSpeakingIdx(idx);
    window.speechSynthesis.speak(utt);
  }

  const sendLockRef = useRef(false);
  function send(text: string, forceLang?: Lang) {
    const t = text.trim();
    if (!t || sendLockRef.current) return;
    sendLockRef.current = true;
    setInput("");
    const detected = detectInputLang(t);
    const activeLang = forceLang || (detected && detected !== lang ? detected : lang);
    if (detected && detected !== lang) {
      setLang(detected);
      localStorage.setItem("ks_lang", detected);
      setAutoDetected(detected);
      setTimeout(() => setAutoDetected(null), 4000);
    }
    const needsEscalation = ESCALATION_TRIGGERS.test(t);
    setMsgs(prev => [...prev, { from: "user", text: t, ts: nowTS() }]);
    setTyping(true);
    const delay = 380 + Math.min(t.length * 3, 460);
    const tid = setTimeout(() => {
      let reply: string;
      try { reply = botReply(t, activeLang); } catch { reply = "Sorry, something went wrong. Please try again or call 1800-KISAN-AI."; }
      const fullReply = needsEscalation
        ? reply + "\n\n⚠️ **Flagged for human support.** Our coordinator will reach you within 4 hours."
        : reply;
      setMsgs(prev => [...prev, { from: "bot", text: fullReply, ts: nowTS() }]);
      setTyping(false);
      if (needsEscalation) setEscalated(true);
      if (!open) setUnread(u => u + 1);
      sendLockRef.current = false;
    }, delay);
    setTimeout(() => { sendLockRef.current = false; setTyping(false); }, 3000);
    return () => clearTimeout(tid);
  }

  function handleKey(e: React.KeyboardEvent) {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(input); }
  }

  const placeholders: Record<Lang,string> = {
    en:"Ask about crops, prices, routes…", hi:"अपना सवाल पूछें…",
    mr:"प्रश्न विचारा…", ta:"கேள்வி கேளுங்கள்…",
    te:"అడగండ…", kn:"ಕೇಳಿ…",
    gu:"પ્રશ્ન પૂછો…", bn:"জিজ্ঞেস করুন…",
    pa:"ਪੁੱਛੋ…",
  };

  return (
    <>
      {/* Floating button */}
      <button
        onClick={() => setOpen(o => !o)}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full shadow-2xl flex items-center justify-center transition-all duration-300 hover:scale-105 active:scale-95"
        style={{ background: open ? "#1a3d22" : "linear-gradient(135deg,#1e4d2b 0%,#2d6b3e 100%)", boxShadow: "0 8px 32px rgba(30,77,43,0.45)" }}
      >
        {open ? (
          <svg width="20" height="20" fill="none" stroke="white" strokeWidth="2.5" viewBox="0 0 24 24">
            <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
        ) : <span className="text-2xl leading-none">&#127807;</span>}
        {unread > 0 && !open && (
          <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-[#c8941a] text-white text-[10px] font-bold flex items-center justify-center border-2 border-white">{unread}</span>
        )}
      </button>

      {/* Chat panel */}
      <div
        className="fixed bottom-24 right-6 z-50 flex flex-col rounded-2xl overflow-hidden shadow-2xl transition-all duration-300 origin-bottom-right"
        style={{ width:"360px", maxHeight:"580px", opacity: open?1:0, transform: open?"scale(1) translateY(0)":"scale(0.92) translateY(12px)", pointerEvents: open?"auto":"none", boxShadow:"0 24px 64px rgba(0,0,0,0.18),0 4px 16px rgba(30,77,43,0.12)" }}
      >

        {/* ── LANGUAGE PICKER OVERLAY ────────────────────────────────── */}
        {showLangPicker && (
          <div className="absolute inset-0 z-20 flex flex-col" style={{ background:"linear-gradient(160deg,#f0faf4 0%,#fff 100%)" }}>
            <div className="flex-shrink-0 px-4 py-5 text-center" style={{ background:"linear-gradient(135deg,#1e4d2b,#2a5e35)" }}>
              <p className="text-4xl mb-1">&#127807;</p>
              <p className="text-base font-bold text-white tracking-wide">Kisansetu AI</p>
              <p className="text-xs text-white/60 mt-1">Choose your language to get started</p>
            </div>
            <div className="flex-shrink-0 bg-[#f5f2ea] border-b border-[#e8e3d8] px-3 py-2 text-center">
              <p className="text-[10px] text-[#7c5c32] leading-relaxed">
                &#2309;&#2346;&#2344;&#2368; &#2349;&#2366;&#2359;&#2366; &#2330;&#2369;&#2344;&#2375;&#2306; &bull; &#2616;&#2660;&#2606;&#2622; &#2330;&#2625;&#2603;&#2578; &bull; &#2464;&#2478;&#2495;&#2494;&#2480; &#2477;&#2494;&#2487;&#2494; &bull; &#2990;&#3018;&#2996;&#3007; &#2980;&#3031;&#2992;&#3021;&#2997;&#3009; &bull; &#3118;&#3135; &#3092;&#3122;&#3137;&#3112;&#3137;&#3122;&#3137;
              </p>
            </div>
            <div className="flex-1 overflow-y-auto p-4 grid grid-cols-3 gap-3">
              {(Object.keys(LANG_META) as Lang[]).map(l => (
                <button key={l} onClick={() => chooseLang(l)}
                  className="flex flex-col items-center gap-1.5 p-3 rounded-2xl border-2 border-[#e8e3d8] bg-white hover:border-[#1e4d2b] hover:bg-[#d6f0de] active:scale-95 transition-all shadow-sm">
                  <span className="text-3xl leading-none">{LANG_META[l].flag}</span>
                  <span className="text-sm font-bold text-[#1e4d2b] leading-tight text-center">{LANG_META[l].native}</span>
                  <span className="text-[9px] text-[#7c5c32]">{LANG_META[l].label}</span>
                </button>
              ))}
            </div>
            <div className="flex-shrink-0 px-4 pb-4">
              <button onClick={() => chooseLang("en")} className="w-full py-2.5 rounded-xl border border-[#c8dfc8] text-[#1e4d2b] text-sm font-semibold hover:bg-[#d6f0de] transition-colors">
                Continue in English &#8594;
              </button>
            </div>
          </div>
        )}

        {/* Header */}
        <div className="flex-shrink-0" style={{ background:"linear-gradient(135deg,#1e4d2b 0%,#2a5e35 100%)" }}>
          <div className="flex items-center gap-2.5 px-4 py-3">
            <div className="w-8 h-8 rounded-full bg-white/15 flex items-center justify-center flex-shrink-0">
              <span className="text-base">&#127807;</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-white leading-tight">Kisansetu AI</p>
              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#4ade80] animate-pulse"/>
                <span className="text-[9px] text-white/55 font-mono">Online &middot; 9 languages</span>
              </div>
            </div>
            <div className="relative">
              <button onClick={() => setLangMenu(m=>!m)}
                className="flex items-center gap-1 px-2 py-1.5 rounded-lg bg-white/10 border border-white/20 hover:bg-white/20 transition-colors">
                <span className="text-base leading-none">{LANG_META[lang].flag}</span>
                <span className="text-[10px] font-bold text-white">{LANG_META[lang].native}</span>
                <svg width="8" height="8" fill="none" stroke="white" strokeWidth="2.5" viewBox="0 0 24 24" opacity="0.7"><path d="M6 9l6 6 6-6"/></svg>
              </button>
              {langMenu && (
                <div className="absolute right-0 top-9 bg-white rounded-2xl shadow-2xl border border-[#e8e3d8] z-50 overflow-hidden" style={{ width:"190px" }}>
                  <div className="px-3 py-2 border-b border-[#f0ebe0]">
                    <p className="text-[10px] font-bold text-[#1e4d2b] uppercase tracking-wider">&#127760; Switch Language</p>
                  </div>
                  <div style={{ maxHeight:"280px", overflowY:"auto" }}>
                    {(Object.keys(LANG_META) as Lang[]).map(l => (
                      <button key={l} onClick={() => chooseLang(l)}
                        className={"w-full flex items-center gap-2.5 px-3 py-2.5 hover:bg-[#f5f0e8] transition-colors text-left" + (lang===l?" bg-[#d6f0de]":"")}>
                        <span className="text-xl leading-none">{LANG_META[l].flag}</span>
                        <div className="flex-1">
                          <p className="text-sm font-bold text-[#1a1a0e]">{LANG_META[l].native}</p>
                          <p className="text-[9px] text-[#7c5c32]">{LANG_META[l].label}</p>
                        </div>
                        {lang===l && <span className="text-[#1e4d2b] font-bold">&#10003;</span>}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
            <button onClick={() => { setMsgs([{ from:"bot", text:T[lang].greeting, ts:nowTS() }]); if (window.speechSynthesis) window.speechSynthesis.cancel(); setSpeakingIdx(null); }}
              className="w-7 h-7 rounded-lg hover:bg-white/15 flex items-center justify-center transition-colors" title="Clear chat">
              <svg width="12" height="12" fill="none" stroke="white" strokeWidth="2" viewBox="0 0 24 24" opacity="0.7"><path d="M3 6h18M19 6l-1 14H6L5 6M10 11v6M14 11v6M9 6V4h6v2"/></svg>
            </button>
            <button onClick={() => { setOpen(false); setLangMenu(false); }}
              className="w-7 h-7 rounded-lg hover:bg-white/15 flex items-center justify-center transition-colors">
              <svg width="12" height="12" fill="none" stroke="white" strokeWidth="2.5" viewBox="0 0 24 24" opacity="0.7"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
          </div>
          {autoDetected && (
            <div className="px-4 pb-2.5">
              <div className="flex items-center gap-2 bg-white/10 rounded-xl px-3 py-2">
                <span className="text-base">{LANG_META[autoDetected].flag}</span>
                <p className="text-[10px] text-white/80 flex-1">Auto-detected <strong className="text-white">{LANG_META[autoDetected].label}</strong> &mdash; replying in {LANG_META[autoDetected].native}</p>
              </div>
            </div>
          )}
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-3" style={{ background:"#f9f7f2", minHeight:0 }} onClick={() => setLangMenu(false)}>
          {msgs.map((m, i) => (
            <div key={i} className={"flex gap-2 " + (m.from==="user"?"flex-row-reverse":"")}>
              {m.from==="bot" && (
                <div className="w-7 h-7 rounded-full bg-[#1e4d2b] flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-xs">&#127807;</span>
                </div>
              )}
              <div className={"max-w-[82%] flex flex-col gap-1 " + (m.from==="user"?"items-end":"items-start")}>
                <div className="px-3.5 py-2.5 text-sm leading-relaxed"
                  style={m.from==="bot"
                    ? { background:"white", color:"#1a1a0e", borderRadius:"4px 18px 18px 18px", boxShadow:"0 1px 4px rgba(0,0,0,0.07)" }
                    : { background:"linear-gradient(135deg,#1e4d2b,#2d6b3e)", color:"white", borderRadius:"18px 4px 18px 18px" }}>
                  {m.from==="bot" ? (
                    <span>
                      {m.text.split("\n").map((line, li) => {
                        const parts = line.split(/(\*\*[^*]+\*\*|_[^_]+_)/g);
                        return (
                          <span key={li}>
                            {parts.map((part, pi) => {
                              if (part.startsWith("**") && part.endsWith("**"))
                                return <strong key={pi} className="font-semibold">{part.slice(2,-2)}</strong>;
                              if (part.startsWith("_") && part.endsWith("_"))
                                return <em key={pi} className="italic text-[#7c5c32]">{part.slice(1,-1)}</em>;
                              return <span key={pi}>{part}</span>;
                            })}
                            {li < m.text.split("\n").length - 1 && <br/>}
                          </span>
                        );
                      })}
                    </span>
                  ) : m.text}
                </div>
                {/* timestamp + listen */}
                <div className={"flex items-center gap-2 px-1 " + (m.from==="user"?"flex-row-reverse":"")}>
                  <span className="text-[9px] font-mono text-[#a77c3e]">{m.ts}</span>
                  {m.from==="bot" && (
                    <button onClick={() => speak(m.text, i)}
                      className="flex items-center gap-1 text-[9px] font-mono text-[#4a7c59] hover:text-[#1e4d2b] rounded-full px-2 py-0.5 hover:bg-[#d6f0de] transition-colors">
                      {speakingIdx===i ? (
                        <><span className="inline-block w-2 h-2 rounded-full bg-[#1e4d2b] animate-pulse"/> Stop</>
                      ) : (
                        <><svg width="10" height="10" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/></svg> Listen</>
                      )}
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
          {typing && (
            <div className="flex gap-2">
              <div className="w-7 h-7 rounded-full bg-[#1e4d2b] flex items-center justify-center flex-shrink-0">
                <span className="text-xs">&#127807;</span>
              </div>
              <div className="bg-white px-4 py-3 flex items-center gap-1.5" style={{ borderRadius:"4px 18px 18px 18px", boxShadow:"0 1px 4px rgba(0,0,0,0.07)" }}>
                {[0,1,2].map(d => (
                  <span key={d} className="w-2 h-2 rounded-full bg-[#4a7c59] block"
                    style={{ animation:"bounce 1.2s infinite", animationDelay:`${d*0.2}s`, opacity:0.7 }}/>
                ))}
              </div>
            </div>
          )}
          <div ref={bottomRef}/>
        </div>

        {/* Quick chips */}
        <div className="px-3 py-2 flex gap-1.5 overflow-x-auto flex-shrink-0 border-t border-[#e8e3d8]" style={{ background:"#f5f2ea" }}>
          {LANG_CHIPS[lang].map(chip => (
            <button key={chip} onClick={() => { send(chip); setLangMenu(false); }} disabled={typing}
              className="flex-shrink-0 text-[10px] font-mono text-[#1e4d2b] bg-white border border-[#c8dfc8] hover:bg-[#d6f0de] active:scale-95 rounded-full px-3 py-1.5 transition-all whitespace-nowrap disabled:opacity-40">
              {chip}
            </button>
          ))}
        </div>

        {/* Input bar */}
        <div className="px-3 pt-2.5 pb-1 border-t border-[#e8e3d8] flex-shrink-0" style={{ background:"white" }}>
          <div className="flex items-center gap-2">
            <VoiceChatBtn onVoice={(text) => send(text)}/>
            <label className="w-9 h-9 rounded-xl bg-[#f5f0e8] flex items-center justify-center flex-shrink-0 cursor-pointer hover:bg-[#e8e3d8] transition-colors" title="Send photo">
              <svg width="14" height="14" fill="none" stroke="#7c5c32" strokeWidth="2" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
              <input type="file" accept="image/*" className="hidden" onChange={() => {
                setTimeout(() => setMsgs(prev => [...prev, { from:"bot", text:"Photo received! I can see what appears to be a crop field. To estimate quantity or detect issues, please also use the AI Estimator or Pest and Disease tabs in the Farmer section for a full analysis.", ts: nowTS() }]), 800);
              }}/>
            </label>
            <input
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKey}
              placeholder={placeholders[lang]}
              className="flex-1 text-sm bg-[#f5f0e8] border-0 rounded-xl px-3.5 py-2.5 focus:outline-none focus:ring-2 focus:ring-[#4a7c59]/30 text-[#1a1a0e] placeholder:text-[#c8b898]"
            />
            <button onClick={() => send(input)} disabled={!input.trim()||typing}
              className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 transition-all disabled:opacity-40"
              style={{ background: input.trim()?"linear-gradient(135deg,#1e4d2b,#2d6b3e)":"#e8e3d8" }}>
              <svg width="15" height="15" fill="none" stroke="white" strokeWidth="2.5" viewBox="0 0 24 24">
                <line x1="22" y1="2" x2="11" y2="13"/>
                <polygon points="22 2 15 22 11 13 2 9 22 2"/>
              </svg>
            </button>
          </div>
          <p className="text-[9px] font-mono text-center text-[#c8b898] py-1.5">&#127897; Voice &middot; &#128247; Photo &middot; &#128264; Listen &middot; &#9000; Text</p>
        </div>

        {escalated && (
          <div className="px-4 py-3 border-t border-[#e8e3d8] flex-shrink-0" style={{ background:"#fef9ec" }}>
            <p className="text-xs font-semibold text-[#92400e] mb-2">Need a human? Escalate to FPO staff</p>
            <div className="flex gap-2">
              <button className="flex-1 bg-[#c8941a] text-white py-2 rounded-lg text-xs font-semibold hover:bg-[#e8b535] transition-colors">Call FPO Coordinator</button>
              <button onClick={() => setEscalated(false)} className="px-3 py-2 rounded-lg border border-[#e8b535] text-[#92400e] text-xs hover:bg-[#fef3c7] transition-colors">Dismiss</button>
            </div>
          </div>
        )}
        <div className="px-4 py-2 text-center flex-shrink-0" style={{ background:"white", borderTop:"1px solid #f0ebe0" }}>
          <span className="text-[9px] font-mono text-[#c8b898]">Powered by Kisansetu AI &middot; Responses are AI-generated</span>
        </div>
      </div>

      <style>{`
        @keyframes bounce { 0%,80%,100% { transform:translateY(0); } 40% { transform:translateY(-5px); } }
      `}</style>
    </>
  );
}

// ─── App ──────────────────────────────────────────────────────────────────────

export default function App() {
  const [view, setView] = useState<View>("home");
  const [bellOpen, setBellOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#faf7f0]" style={{ fontFamily: "var(--font-sans)" }}>
      {/* Top Nav */}
      <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-[#e8e3d8]">
        <div className="max-w-6xl mx-auto px-4 flex items-center justify-between h-14">
          <button onClick={() => setView("home")} className="flex items-center gap-2">
            <span className="text-xl">🌾</span>
            <span className="font-bold text-[#1e4d2b]" style={{ fontFamily: "var(--font-display)" }}>
              Kisan<span className="text-[#c8941a]">setu</span> <span className="font-light text-sm text-[#7c5c32]">AI</span>
            </span>
          </button>

          <nav className="hidden md:flex items-center gap-1">
            {navItems.filter(n => n.id !== "home").map((n) => (
              <button
                key={n.id}
                onClick={() => setView(n.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm transition-colors ${view === n.id ? "bg-[#1e4d2b] text-white" : "text-[#7c5c32] hover:bg-[#f0ebe0] hover:text-[#1e4d2b]"}`}
              >
                <span>{n.icon}</span>
                <span>{n.label}</span>
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            {/* Offline indicator */}
            <div className="hidden sm:flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-[#4a7c59] animate-pulse"/>
              <span className="text-xs font-mono text-[#7c5c32]">Online</span>
            </div>
            {/* Profile avatar */}
            <button onClick={() => setView("profile")}
              className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors text-base ${view==="profile" ? "bg-[#1e4d2b] text-white" : "hover:bg-[#f0ebe0] text-[#7c5c32]"}`}
              title="My Profile">
              👤
            </button>
            {/* Notification bell */}
            <div className="relative">
              <button
                onClick={() => setBellOpen(b => !b)}
                className="relative w-8 h-8 rounded-lg flex items-center justify-center hover:bg-[#f0ebe0] transition-colors"
              >
                <svg width="16" height="16" fill="none" stroke="#7c5c32" strokeWidth="2" viewBox="0 0 24 24">
                  <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
                  <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
                </svg>
                {ALERTS.filter(a => a.urgent).length > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-red-500 text-white text-[9px] flex items-center justify-center font-bold">
                    {ALERTS.filter(a=>a.urgent).length}
                  </span>
                )}
              </button>
              {bellOpen && (
                <div className="absolute right-0 top-10 w-80 bg-white border border-[#e8e3d8] rounded-2xl shadow-2xl z-50 overflow-hidden">
                  <div className="px-4 py-3 border-b border-[#e8e3d8] flex items-center justify-between">
                    <span className="font-semibold text-sm">Alerts & Notifications</span>
                    <button onClick={() => setBellOpen(false)} className="text-[#7c5c32] text-sm hover:text-[#1a1a0e]">✕</button>
                  </div>
                  <div className="divide-y divide-[#f5f0e8] max-h-80 overflow-y-auto">
                    {ALERTS.map(a => (
                      <div key={a.id} className={`px-4 py-3 flex gap-3 hover:bg-[#faf9f5] cursor-pointer ${a.urgent ? "border-l-2 border-red-400" : ""}`}>
                        <span className="text-xl flex-shrink-0 mt-0.5">{a.icon}</span>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold text-[#1a1a0e]">{a.title}</p>
                          <p className="text-[10px] text-[#7c5c32] mt-0.5 leading-relaxed">{a.msg}</p>
                          <p className="text-[9px] font-mono text-[#a77c3e] mt-1">{a.time}</p>
                        </div>
                        {a.urgent && <span className="w-2 h-2 rounded-full bg-red-400 flex-shrink-0 mt-1.5"/>}
                      </div>
                    ))}
                  </div>
                  <div className="px-4 py-3 border-t border-[#e8e3d8] bg-[#f9f7f2]">
                    <p className="text-[9px] font-mono text-[#a77c3e] text-center">SMS fallback active · Critical alerts sent even when offline</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Mobile nav */}
        <div className="md:hidden flex gap-1 px-4 pb-2 overflow-x-auto">
          {navItems.filter(n => n.id !== "home").map((n) => (
            <button
              key={n.id}
              onClick={() => setView(n.id)}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs transition-colors whitespace-nowrap ${view === n.id ? "bg-[#1e4d2b] text-white" : "text-[#7c5c32] bg-[#f0ebe0]"}`}
            >
              {n.icon} {n.label}
            </button>
          ))}
        </div>
      </header>

      <main className={view === "home" ? "" : "max-w-6xl mx-auto px-4 py-8"}>
        {view === "home" && <HomeView setView={setView} />}
        {view === "farmer" && <FarmerView />}
        {view === "forecast" && <ForecastView />}
        {view === "matching" && <MatchingView />}
        {view === "buyer" && <BuyerView />}
        {view === "logistics" && <LogisticsView />}
        {view === "orders" && <OrdersView />}
        {view === "transparency" && <TransparencyView />}
        {view === "profile" && <ProfileView />}
      </main>

      {view !== "home" && (
        <footer className="max-w-6xl mx-auto px-4 py-6 mt-12 border-t border-[#e8e3d8] flex items-center justify-between flex-wrap gap-2">
          <span className="text-sm text-[#7c5c32] font-mono">Kisansetu AI · Prototype v0.1</span>
          <span className="text-xs text-[#a77c3e] font-mono">Empowering 12,400+ farmers across India</span>
        </footer>
      )}

      {/* Global AI chat — floats over all views */}
      <KisanChat />
    </div>
  );
}
